####################################################################################################
# Name:                 azuresession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/23/azuresession
# Command line usage:   N/A
# Purpose:              Class contains methods to call Azure API resources
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-02 J. Rominske (jesr114@kellyservices.com)      Original Author
####################################################################################################

# library imports
import json
import multiprocessing
from pathlib import Path
import requests
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to Azure Data Warehouse Automation  
class azureSession(session):
    # specific initialization method
    def _setup(self):
        self.directory = self.repoDirectory/'msazure'
        # load stored credentials from JSON file
        self.azureCreds = json.load(open(self.secureDirectory/(self.env+'_azurecreds.json')))
        # load config from JSON file
        self.azureConfig = json.load(open(self.configDirectory/(self.env+'_azureconfig.json')))
        # session variables for Azure API interface
        self.loginUrl = "https://login.microsoftonline.com/{}/oauth2/token".format(self.azureCreds['tenantId']) # login URL for the Azure API Service
        self.azureUrl = "https://management.azure.com" # URL for the Azure Portal
        self.subscriptionId = self.azureCreds['subscriptionId']
        self.hdrs = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        self.req = requests.Session()

    # method for logging into Azure Portal
    def login(self):
        # define login data
        loginData = {
            'grant_type': 'client_credentials',
            'client_id': self.azureCreds['clientId'],
            'client_secret': self.azureCreds['clientSecret'],
            'resource': self.azureUrl
        }
        response = self.req.post(self.loginUrl, headers=self.hdrs, data=loginData)
        if response.status_code == 200 : 
            self.log(text='Login Success')
            self.hdrs['Authorization'] = "Bearer "+response.json()['access_token']
            self.hdrs['Content-Type'] = 'application/json'
            return True
        else:
            self.log(text='Login Failed')
            self.log(text=response.text)
            return False

    # method for sending emails specific to Azure
    def azureEmail(self, body, color, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.secureDirectory/'config'/'emailTemplates'/'emailbody_dwscaling.html') as template:
            self.email(body=template.read().format(body), # replace "{}" in template file with values
                       color=color,
                       attachment=attachment,
                       recipients=recipients) # call basic email function

    # method for send error report email for Azure
    def azureError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.azureEmail(body='An error occurred with code: '+str(errorCode)+'<br>Please check the logs.',
                            color='red',
                            recipients=self.scriptConfig['emailRecipients']['error'])
        sys.exit(errorCode)
            
    # fundamental Azure API methods for syntactic sugar
    # method to list resources for the subscription (used as basic test)
    def resourceList(self):
        return self.req.get(self.azureUrl+self.uriPrefix+'/resources?api-version='+self.azureConfig['apiVersion']['resourceList'], headers=self.hdrs)
    # generic method for using Azure resource methods
    def _doAPI(self, reqType, resourceName, method, apiVersion, jsonData={}, headers=None):
        self.log(text='Checking existence of resource '+resourceName)
        # build prefix based on subscription ID
        self.uriPrefix = "/subscriptions/{}".format(self.subscriptionId)
        # find the resource ID with given name
        findResult = self.req.get(self.azureUrl+self.uriPrefix+"/resources?$filter=name eq '"+resourceName+"'&api-version="+self.azureConfig['apiVersion']['resourceList'], headers=self.hdrs).json()['value']
        # if resource found, execute API method as specified
        if len(findResult) == 1:
            self.log(text='Resource '+resourceName+' found')
            # build URL from arguments
            url = self.azureUrl+findResult[0]['id']+method+'?api-version='+apiVersion if '?' not in method else self.azureUrl+findResult[0]['id']+method+'&api-version='+apiVersion
            if not headers:
                headers = self.hdrs
            self.log(text='\tAccessing API resource at '+url)
            # switch method use based on request type
            if reqType == 'GET':
                # get initial result, ordered by display name
                result = self.req.get(url, headers=headers)
                resultJson = result.json()
                # toggle list behavior vs singleton behavior
                if 'value' in resultJson:
                    resultList = resultJson['value']
                    # loop using nextLink until results are exhausted
                    if 'nextLink' in resultJson and resultJson['nextLink'] is not None:
                        while len(resultJson['value']) > 0:
                            resultJson = self.req.get(resultJson['nextLink'], headers=headers).json()
                            resultList = resultList+resultJson['value']
                    return resultList
                else:
                    return resultJson
            # perform POST request
            if reqType == 'POST':
                return self.req.post(url, headers=headers, json=jsonData)
            # perform PATCH request
            elif reqType == 'PATCH':
                return self.req.patch(url, headers=headers, json=jsonData)
            # perform PUT request
            elif reqType == 'PUT':
                return self.req.put(url, headers=headers, json=jsonData)
            # perform DELETE request
            elif reqType == 'DELETE':
                return self.req.delete(url, headers=headers)
        # if more than one resource found with that name, report and terminate script
        elif len(findResult) > 1:
            for i in range(findResult):
                self.log(text='Result '+str(i)+': '+findResult[i]['id'])
            raise ValueError('More than one resource named '+resourceName+' found for subscription '+self.azureCreds['subscriptionId']+'! Terminating script...')
        # if no resource found with that name, terminate script
        else:
            raise ValueError('No resource named '+resourceName+' found for subscription '+self.azureCreds['subscriptionId']+'! Terminating script...')
    # method to check status of asynchronous operations given URL in call response headers
    def checkAsync(self, asyncOpUrl):
        return self.req.get(asyncOpUrl, headers=self.hdrs)
    # method to monitor aysnchronous operations
    def monitorAysnc(self, httpResponse, timeoutLimit):
        asyncOpUrl = httpResponse.headers['azure-asyncoperation']
        self.log(text='\nMonitoring asynchrounous operation '+asyncOpUrl.split('/')[-1].split('?')[0]+' with a '+str(timeoutLimit)+'-second timeout')
        timeoutProcess = multiprocessing.Process(target=self.timer, args=[timeoutLimit])
        timeoutProcess.start()
        # check operation until it finishes or timeout occurs
        while timeoutProcess.is_alive():
            asyncResponse = self.checkAsync(asyncOpUrl)
            if asyncResponse.json()['status'] == 'Succeeded':
                timeoutProcess.terminate()
                self.log(text='Asynchronous operation succeeded\n')
                return asyncResponse
            elif asyncResponse.json()['status'] in ('Failed', 'Canceled'):
                jsonFilePath = self.createJsonFile('json/'+self.logFileName.stem+'.json', asyncResponse.json())
                self.log(text='JSON response dumped to file at path: '+str(jsonFilePath))
                raise Exception('Asynchronous operation failed! Terminating script...\n')
            self.timer(self.azureConfig['asyncCheckPeriod'])
        timeoutProcess.terminate()
        jsonFilePath = self.createJsonFile('json/'+self.logFileName.stem+'.json', asyncResponse.json())
        self.log(text='JSON response dumped to file at path: '+str(jsonFilePath))
        raise TimeoutError('Asynchronous operation monitoring timed out after '+str(timeoutLimit)+' seconds. Terminating script...')
    
    # basic API methods

    # Database Methods
    # method to get details of the databases in a resource
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/databases/get
    def dbListGet(self, resourceName):
        return self._doAPI('GET', resourceName, '/databases', self.azureConfig['apiVersion']['dbListGet'])
    # method to get a list of operations active on a database
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/database-operations/list-by-database
    def dbOperationsGet(self, dbName):
        return self._doAPI('GET', dbName, '/operations', self.azureConfig['apiVersion']['dbOperationsGet'])
    # method to pause a database
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/databases/pause
    def dbPause(self, dbName):
        return self._doAPI('GET', dbName, '/pause', self.azureConfig['apiVersion']['dbPause'])
    # method to resume a database
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/databases/resume
    def dbResume(self, dbName):
        return self._doAPI('GET', dbName, '/resume', self.azureConfig['apiVersion']['dbResume'])
    # method to get details of a database
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/databases/get
    def dbStateGet(self, dbName):
        return self._doAPI('GET', dbName, '', self.azureConfig['apiVersion']['dbStateGet'])
    # method to update a database
    # https://learn.microsoft.com/en-us/rest/api/sql/2020-08-01-preview/databases/update
    def dbUpdate(self, dbName, updateJson):
        return self._doAPI('PATCH', dbName, '', self.azureConfig['apiVersion']['dbUpdate'], updateJson)

    # PBI Embedded Methods
    # method to get details of a PBI Embedded capacity
    # https://learn.microsoft.com/en-us/rest/api/power-bi-embedded/capacities/get-details
    def pbieCapacityDetailsGet(self, capacityName):
        return self._doAPI('GET', capacityName, '', self.azureConfig['apiVersion']['pbieCapacityDetailsGet'])
    # method to resume a PBI Embedded capacity
    # https://learn.microsoft.com/en-us/rest/api/power-bi-embedded/capacities/resume
    def pbieCapacityResume(self, capacityName):
        return self._doAPI('POST', capacityName, '/resume', self.azureConfig['apiVersion']['pbieCapacityResume'])
    # method to get available SKUs of a PBI Embedded capacity
    # https://learn.microsoft.com/en-us/rest/api/power-bi-embedded/capacities/list-skus-for-capacity
    def pbieCapacitySkusGet(self, capacityName):
        return self._doAPI('GET', capacityName, '/skus', self.azureConfig['apiVersion']['pbieCapacitySkusGet'])
    # method to suspend a PBI Embedded capacity
    # https://learn.microsoft.com/en-us/rest/api/power-bi-embedded/capacities/suspend
    def pbieCapacitySuspend(self, capacityName):
        return self._doAPI('POST', capacityName, '/suspend', self.azureConfig['apiVersion']['pbieCapacitySuspend'])
    # method to update a PBI Embedded capacity
    # https://learn.microsoft.com/en-us/rest/api/power-bi-embedded/capacities/update
    def pbieCapacityUpdate(self, capacityName, updateJson):
        return self._doAPI('PATCH', capacityName, '', self.azureConfig['apiVersion']['pbieCapacityUpdate'], updateJson)

    # Resource Metrics Methods
    # method to get a metric for a resource
    # https://learn.microsoft.com/en-us/rest/api/application-insights/metrics/get
    def resourceMetricGet(self, resourceName, metricName):
        return self._doAPI('GET', resourceName, '/providers/microsoft.insights/metrics/'+metricName, self.azureConfig['apiVersion']['resourceMetricGet'])
    # method to get a metric for a resource
    # https://learn.microsoft.com/en-us/rest/api/monitor/metrics/list
    def resourceMetricsGet(self, resourceName):
        return self._doAPI('GET', resourceName, '/providers/microsoft.insights/metrics', self.azureConfig['apiVersion']['resourceMetricsGet'])

    # VM Methods
    # method to run a command on a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/run-command
    def vmCmdRun(self, vmName, cmdJson):
        return self._doAPI('POST', vmName, '/runCommand', self.azureConfig['apiVersion']['vmCmdRun'], cmdJson)
    # method to deallocate a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/deallocate
    def vmDeallocate(self, vmName):
        return self._doAPI('POST', vmName, '/deallocate', self.azureConfig['apiVersion']['vmDeallocate'])
    # method to get details of a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/get
    def vmDetailsGet(self, vmName):
        return self._doAPI('GET', vmName, '', self.azureConfig['apiVersion']['vmDetailsGet'])
    # method to get details of a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/instance-view
    def vmInstanceGet(self, vmName):
        return self._doAPI('GET', vmName, '/instanceView', self.azureConfig['apiVersion']['vmInstanceGet'])
    # method to power off a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/power-off
    def vmPowerOff(self, vmName):
        return self._doAPI('POST', vmName, '/powerOff', self.azureConfig['apiVersion']['vmPowerOff'])
    # method to restart a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/restart
    def vmRestart(self, vmName):
        return self._doAPI('POST', vmName, '/restart', self.azureConfig['apiVersion']['vmRestart'])
    # method to get sizes a VM can be resized to
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/list-available-sizes
    def vmSizesGet(self, vmName):
        return self._doAPI('GET', vmName, '/vmSizes', self.azureConfig['apiVersion']['vmSizesGet'])
    # method to start up a VM
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/start
    def vmStart(self, vmName):
        return self._doAPI('POST', vmName, '/start', self.azureConfig['apiVersion']['vmStart'])
    # method to get details of a database
    # https://learn.microsoft.com/en-us/rest/api/compute/virtual-machines/update
    def vmUpdate(self, vmName, updateJson):
        return self._doAPI('PUT', vmName, '', self.azureConfig['apiVersion']['vmUpdate'], updateJson)

    # Web App Methods
    # method to list functions in a web app
    # https://learn.microsoft.com/en-us/rest/api/appservice/web-apps/list-functions
    def webAppFunctionsGet(self, appName):
        return self._doAPI('GET', appName, '/functions', self.azureConfig['apiVersion']['webAppFunctionsGet'])
    # method to start a web app
    # https://learn.microsoft.com/en-us/rest/api/appservice/web-apps/start
    def webAppStart(self, appName):
        return self._doAPI('POST', appName, '/start', self.azureConfig['apiVersion']['webAppStart'])


# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    A = azureSession(Path(__file__).stem, 'test')
    try:
        if not A.login():
            print('Login error - aborted')
            sys.exit(1)
        else: 
            A.log(text='Class compile test complete')
            print('Script execution complete')
    except Exception as e:
        A.error(e)