####################################################################################################
# Name:                 pbiecapacitypower.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/pbiecapacitypower.vsdx
# Command line usage:   python start.py pbiecapacitypower <-on/-off> <vmName> <timeoutPeriod>
# Purpose:              Start up or deallocate a PBI Embedded capacity hosted on Azure
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-12-02 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from pathlib import Path
import sys
# local module imports
from msazure.azuresession import azureSession

# function to power toggle a PBI Embadded Capacity
def pbieCapacityPower(session, desiredState, capacityName, monitorTimeout=None):
    # check VM current state
    capacityJson = session.pbieCapacityDetailsGet(capacityName)
    # if VM is stopped, report the status
    currentState = capacityJson['properties']['provisioningState']
    session.log(text='Capacity current state is: '+currentState+'\nCapacity Desired state is: '+desiredState)
    # if already in desired state, no need to toggle power
    if currentState == desiredState:
        session.log(text='No need to toggle power')
        return True
    # if capacity is undergoing a power operation, wait a little bit and check again
    elif currentState in ['Resuming', 'Pausing']:
        session.log(text='Capacity currently in transitional state '+currentState)
        session.log('Waiting for Capacity to finish...')
        session.timer(10)
        return pbieCapacityPower(session, desiredState, capacityName, monitorTimeout=monitorTimeout)
    # if not in starting state but also in not desired state, take appropriate action
    elif currentState in ['Succeeded', 'Paused'] and currentState != desiredState:
        powerResponse = None
        # if desired status is deallocated, turn VM off
        if desiredState == 'Paused':
            session.log('Pausing capacity...')
            powerResponse = session.pbieCapacitySuspend(capacityName)
        # if desired status is deallocated, turn VM off
        elif desiredState == 'Succeeded':
            session.log('Resuming capacity...')
            powerResponse = session.pbieCapacityResume(capacityName)
        # handle monitoring if applicable
        if monitorTimeout:
            # fail if update call response is not as expected (probably Azure error)
            if 'Azure-AsyncOperation' not in powerResponse.headers:
                session.log(text='Update operation failed! Check the resource '+capacityName+' in the Azure portal. Terminating script...')
                raise ValueError('No operation ID returned by Azure')
            if session.monitorAysnc(powerResponse, monitorTimeout):
                # send email
                session.azureEmail(
                    body='PBI Embedded Capacity '+capacityName+' has been switched to provisioning state '+desiredState.upper(),
                    color='green'
                )
            else:
                raise ValueError('Asynchronous operation failed! Terminating script...')
        else:
            return True
    # if state not recognized, error out and log
    else:
        raise ValueError('Capacity in currently in unrecognized state '+currentState)

# wrapper fucntion for toggling PBI Embadded Capacity power
def pbieCapacityPowerToggle(session, toggle, capacityName, monitorTimeout=None):
    # if toggle is "-on" set desired state
    if toggle == '-on':
        return pbieCapacityPower(session, 'Succeeded', capacityName, monitorTimeout=monitorTimeout)
    elif toggle == '-off':
        return pbieCapacityPower(session, 'Paused', capacityName, monitorTimeout=monitorTimeout)
    else:
        raise ValueError('Invalid power toggle option given! Expected -on or -off. Temrinating script...')

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, sys.argv[1]+'_'+sys.argv[2])
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # handle command line args
            if sys.argv[1].startswith('-o'):
                if len(sys.argv) <= 3:
                    pbieCapacityPowerToggle(sessionContainer['azure'], sys.argv[1], sys.argv[2])
                else:
                    pbieCapacityPowerToggle(sessionContainer['azure'], sys.argv[1], sys.argv[2], monitorTimeout=int(sys.argv[3])*60)
                sessionContainer['azure'].log(text='Script execution succeeded')
            else:
                raise ValueError('No toggle on/off option provided (i.e. -on or -off)')
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])