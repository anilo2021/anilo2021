####################################################################################################
# Name:                 azurevmpsscriptexecute.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azurevmpsscriptexecute.vsdx
# Command line usage:   python start.py azurevmpsscriptexecute <vmName> <fileName> <timeoutPeriod>
# Purpose:              Execute a given PowerShell script file on a given Azure VM
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-14 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import datetime
import json
import multiprocessing
from pathlib import Path
import sys
# local module imports
from msazure.azuresession import azureSession 

# function to run a repo-stored PowerShell script on a given VM
def azureVmPsScriptExecute(session, vmName, fileName, variables=[], monitorTimeout=None):
    # initialize variables
    scriptStartTime = datetime.datetime.today()
    cmdJson = None
    scriptResponse = None
    psOutputPath = session.directory/'logs'/'psOutput'/('azurevmpower_'+vmName+'_'+fileName[:-4]+session.fileTimestamp+'.log') # remove ".ps1" from file name
    # prepend PowerShell output path to the list of variables
    variables = [str(psOutputPath)] + variables
    # open file from sql directory and execute contents on cursor
    with open(session.directory/'ps'/fileName) as scriptFile:
        # get list of lines in file
        scriptLines = [l for l in scriptFile.readlines() if not l.startswith('#')] # excludes comments
        scriptString = ''.join(scriptLines)
        # fill in variable markers with values, unpacking lists if needed
        for v in variables:
            scriptString = scriptString.replace('{pyParam}', v, 1)
        #scriptString = scriptString.format(*variables) if isinstance(variables, (list, tuple)) else scriptString.format(variables)
        session.log(text='Executing following PowerShell script on VM '+vmName+':\n'+scriptString)
        # get applicable params
        params = []
        paramFilePath = session.configDirectory/'psParam'/(session.env+'_azure_ps_'+fileName[:-4]+'.param') # remove ".ps1" from file name
        if paramFilePath.exists():
            with open(paramFilePath) as paramFile:
                for line in paramFile:
                    param = {
                        'name': line[:line.find('=')], # text before the "="
                        'value': line[line.find('=')+1:] # text after the "="
                    }
                    params.append(param)
        # generate run-command JSON
        cmdJson = {
            'commandId': 'RunPowerShellScript',
            'script': [scriptString],
            'parameters': params
        }
        session.createJsonFile('json/'+session.logFileName.stem+'_PSScriptExecutePayload.json', cmdJson)
    scriptResponse = session.vmCmdRun(vmName, cmdJson)
    # if script executed successfully, continue to monitoring if applicable
    if scriptResponse.status_code != 200:
        # handle monitoring if applicable
        if monitorTimeout:
            # fail if update call response is not as expected (probably Azure error)
            if 'Azure-AsyncOperation' not in scriptResponse.headers:
                session.log(text='Update operation failed! Check the resource '+vmName+' in the Azure portal. Terminating script...')
                raise ValueError('No operation ID returned by Azure')
            asyncResponse = session.monitorAysnc(scriptResponse, monitorTimeout)
            with open(psOutputPath) as psOutputFile:
                # read datastamp in output file
                psOutputTime = datetime.datetime.strptime(psOutputFile.readlines()[0][:-1], '%Y/%m/%d %H:%M:%S')
                # check the asynhchronous operation for success
                if asyncResponse.json()['properties']['output']['value'][0]['code'] == 'ComponentStatus/StdOut/succeeded':
                    # check the output file wrote correctly, in case of permissions or connection issue with DFS
                    if scriptStartTime < psOutputTime:
                        session.log(text='PowerShell script execution successful')
                    else:
                        raise ValueError('PowerShell script output file write failed! Terminating script...')
                    return asyncResponse, psOutputPath
                # if the asynchronous operation failed, log it but return the response
                else:
                    session.log(text='PowerShell script execution error!')
                    session.log(text='Asynchronous operation response:\n'+str(asyncResponse.json()))
                    return asyncResponse, psOutputPath
    else:
        session.log(text=str(scriptResponse.headers)) # TEST
        session.log(text=scriptResponse.content.decode('utf-8')) # TEST
        session.log(text='VM Command Run API error! JSON sent was:\n'+str(cmdJson))
        return False, False


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, sys.argv[1].replace('/', '_'))
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # handle command line args
            if len(sys.argv) <= 3:
                azureVmPsScriptExecute(sessionContainer['azure'], sys.argv[1], sys.argv[2])
            else:
                azureVmPsScriptExecute(sessionContainer['azure'], sys.argv[1], sys.argv[2], int(sys.argv[3])*60)
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])