####################################################################################################
# Name:                 azurevmpower.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azurevmpower.vsdx
# Command line usage:   python start.py azurevmpower <-on/-off> <vmName> <checkService> <timeoutPeriod>
# Purpose:              Start up or deallocate a VM hosted on Azure
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-14 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from pathlib import Path
import sys
# local module imports
from msazure.azuresession import azureSession
from msazure.azurevmpsscriptexecute import azureVmPsScriptExecute

# function to power toggle an Azure VM
def azureVmPower(session, desiredState, vmName, checkService=None, monitorTimeout=None):
    poweredOff = False
    # check VM current state
    vmInstance = session.vmInstanceGet(vmName)
    # if VM is stopped, report the status
    currentState = vmInstance['statuses'][1]['code']
    session.log(text='VM current state is: '+currentState+'\nVM Desired state is: '+desiredState)
    # if already in desired state, no need to toggle power
    if currentState == desiredState:
        session.log(text='No need to toggle power')
        return True
    # if VM is undergoing a power operation, wait a little bit and check again
    elif currentState in ['PowerState/starting', 'PowerState/stopping', 'PowerState/deallocating']:
        session.log(text='VM currently in transitional state '+currentState)
        session.log('Waiting for VM to finish...')
        session.timer(10)
        return azureVmPower(session, desiredState, vmName, monitorTimeout=monitorTimeout)
    # if not in starting state but also in not desired state, take appropriate action
    elif currentState in ['PowerState/running', 'PowerState/stopped', 'PowerState/deallocated'] and currentState != desiredState:
        powerResponse = None
        # if desired status is deallocated, turn VM off
        if desiredState == 'PowerState/deallocated':
            session.log('Powering VM off...')
            powerResponse = session.vmDeallocate(vmName)
            # reset check flags since they're not applicable when the VM is powered off
            checkService = None
            poweredOff = True
        # if desired status is deallocated, turn VM off
        elif desiredState == 'PowerState/running':
            session.log('Powering VM on...')
            powerResponse = session.vmStart(vmName)
        # handle monitoring if applicable
        if monitorTimeout:
            # fail if update call response is not as expected (probably Azure error)
            if 'Azure-AsyncOperation' not in powerResponse.headers:
                session.log(text='Update operation failed! Check the resource '+vmName+' in the Azure portal. Terminating script...')
                raise ValueError('No operation ID returned by Azure')
            if session.monitorAysnc(powerResponse, monitorTimeout):
                # wait for Microsoft
                session.timer(5)
                # disable all checks if powered off
                if not poweredOff:
                    # perform OS response check using azurevmpsscriptexecute
                    systemDetailResponse, _ = azureVmPsScriptExecute(session, vmName, fileName='systemInfo.ps1', monitorTimeout=monitorTimeout)
                    if systemDetailResponse:
                        session.log(text=' Azure VM '+vmName+' OS response confirmed')
                    else:
                        raise ValueError('Azure VM '+vmName+' OS not responding! Terminating script...')
                    # if a service to check for on the VM is given, verify service is running
                    if checkService:
                        serviceRunning = False
                        serviceCheckCount = 0
                        while not serviceRunning and serviceCheckCount < session.scriptConfig['serviceCheckCount']:
                            serviceResponse, psOutputPath = azureVmPsScriptExecute(session, vmName, 'servicecheck.ps1', variables=[checkService], monitorTimeout=monitorTimeout)
                            if serviceResponse:
                                # open output file to read response
                                with open(psOutputPath) as outputFile:
                                    checkLine = outputFile.readlines()[-3] # the final two lines are always empty for servicecheck
                                    # if service check is successful, log confirmation
                                    if checkService in checkLine:
                                        session.log(text='Service '+checkService+' confirmed running')
                                        serviceRunning = True
                                    else:
                                        session.log(text='Service '+checkService+' not running - waiting '+str(session.scriptConfig['vmConfirmationWait'])+' seconds before trying again...\n')
                                        session.timer(session.scriptConfig['vmConfirmationWait'])
                                        serviceCheckCount += 1
                                        continue
                            else:
                                raise ValueError('Azure VM '+vmName+' service check failed! Terminating script...')
                    # if loop finished without confirmed success
                    if not serviceRunning:
                        raise ValueError('Azure VM '+vmName+' envrionment readiness validation failed! Terminating script...')
                # send email if enabled
                if session.scriptConfig['emailEnabled']:
                    session.azureEmail(
                        body='VM '+vmName+' has been switched to power state '+desiredState.split('/')[1].upper(),
                        color='green'
                    )
            else:
                return False
        else:
            return True
    # if state not recognized, error out and log
    else:
        raise ValueError('VM in currently in unrecognized state '+currentState)

# wrapper fucntion for toggling VM power
def azureVmPowerToggle(session, toggle, vmName, checkService=None, monitorTimeout=None):
    # if toggle is "-on" set desired state
    if toggle == '-on':
        return azureVmPower(session, 'PowerState/running', vmName, checkService=checkService, monitorTimeout=monitorTimeout)
    elif toggle == '-off':
        return azureVmPower(session, 'PowerState/deallocated', vmName, checkService=checkService, monitorTimeout=monitorTimeout)
    else:
        raise ValueError('Invalid power toggle option given! Expected -on or -off. Temrinating script...')


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, sys.argv[1]+'_'+sys.argv[2])
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # handle command line args
            if sys.argv[1].startswith('-o'):
                if len(sys.argv) <= 3:
                    azureVmPowerToggle(sessionContainer['azure'], sys.argv[1], sys.argv[2])
                elif len(sys.argv) <= 4:
                    azureVmPowerToggle(sessionContainer['azure'], sys.argv[1], sys.argv[2], monitorTimeout=int(sys.argv[3])*60)
                else:
                    azureVmPowerToggle(sessionContainer['azure'], sys.argv[1], sys.argv[2], checkService=sys.argv[3], monitorTimeout=int(sys.argv[4])*60)
                sessionContainer['azure'].log(text='Script execution succeeded')
            else:
                raise ValueError('No toggle on/off option provided (i.e. -on or -off)')
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])