####################################################################################################
# Name:                	azureappfunctionexecute.py
# Command line usage:  	python start.py azureappfunctionexecute appName functionName timeout period
# Flow diagram:        	AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azureappfunctionexecute.vsdx
# Python version:      	Python 3.6.4
# Purpose:             	Executes an Azure Function App of a given name.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2022-10-14 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import multiprocessing
from pathlib import Path
import sys

# local imports
from msazure.azuresession import azureSession

# example function for primary entry point logic
def azureAppFunctionExecute(session, appName, functionName, timeoutProcess, period):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        return False

    # read function key from creds
    functionKey = session.azureCreds['FunctionKey'][appName][functionName]
    # derive function URL from arguments
    functionUrl = f'https://{appName}.azurewebsites.net/api/orchestrators/{functionName}?code={functionKey}'
    # perform GET request on the Azure function
    session.log(text='Executing Azure function at URL '+functionUrl)
    responseStartFunction = session.req.get(functionUrl)
    responseStartFunctionDict = responseStartFunction.json()
    
    # prepare error variables
    errorMessage = 'Timeout subprocess already terminated!' # default error message is subprocess failure
    errorDict = {}
    # if valid response, proceed with status check loop
    if 'statusQueryGetUri' in responseStartFunctionDict:
        # status check loop
        while timeoutProcess.is_alive():
            session.log(text='Monitoring Azure function execution status...')
            responseFunctionStatus = session.req.get(responseStartFunctionDict['statusQueryGetUri'])
            responseFunctionStatusDict = responseFunctionStatus.json()
            # check status response
            if 'runtimeStatus' in responseFunctionStatusDict:
                session.log(text='Function status: '+responseFunctionStatusDict['runtimeStatus'])
                # if succeeded, mark success as True and end loop
                if responseFunctionStatusDict['runtimeStatus'] in ['Completed']:
                    session.log(text='Function completed')
                    return True
                # if failed, log and end loop
                elif responseFunctionStatusDict['runtimeStatus'] in ['Failed','Suspended','Terminated']:
                    errorMessage = 'Function failed!'
                    errorDict = responseFunctionStatusDict
                    break
                # if in progress, wait for next status check
                else:
                    session.log(text='Function in progress')
                    session.timer(period)
            # if invalid response JSON, save and raise error
            else:
                errorMessage = 'Function status returned invalid response!'
                errorDict = responseFunctionStatusDict
                break
        # catch timeout case
        if not timeoutProcess.is_alive() and errorDict != {}:
            errorMessage = 'Function monitor timed out!'
            errorDict = responseFunctionStatusDict
    # if invalid response JSON, save and raise error
    else:
        errorMessage = 'Function trigger returned invalid response!'
        errorDict = responseStartFunctionDict
    # record error and save JSON
    session.log(text=errorMessage+' Saving JSON...')
    session.createJsonFile('testJson/'+session.logFileName.stem+'_functionStatus.json', errorDict)
    raise Exception(errorMessage)
    

# main thread
if __name__ == '__main__':
    print('Running...')
	# instantiate dict of framework classes to pass all their capabilities into the entry point function
    sessionContainer = {} 
    sessionContainer['azure'] = azureSession(Path(__file__).stem, taskName=sys.argv[1]+'_'+sys.argv[2])
    try:
        # set timeout as secondary thread using second argument
        timeoutLimit = 300 if int(sys.argv[3]) < 5 else int(sys.argv[3])*60 # at least 5 minutes
        timeoutProcess = multiprocessing.Process(target=sessionContainer['azure'].timer, args=[timeoutLimit])
        timeoutProcess.start()
        # handle different cases of command line arguments
        period = 60 if int(sys.argv[4]) < 1 else int(sys.argv[4])*60 # at least one minute
        # execute logic function
        azureAppFunctionExecute(sessionContainer['azure'], sys.argv[1], sys.argv[2], timeoutProcess, period)
        sessionContainer['azure'].log(text='Script execution complete') # for log completeness
        print('Script execution complete') # for ease of understanding while testing
	# pass all otherwise uncaught exceptions to error handler method
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])
    # always kill timeout if needed
    finally:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()