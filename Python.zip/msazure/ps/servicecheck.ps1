# set output file path
$OutputFile = "{pyParam}"
# get current timestamp in correct format
(Get-Date).tostring('yyyy/MM/dd HH:mm:ss') | Out-File -FilePath $OutputFile -Encoding ascii
# get running processes
Get-Service | Where-Object {$_.Status -eq "Running" -and $_.DisplayName -eq "{pyParam}"} | Out-File -FilePath $OutputFile -Append -Encoding ascii