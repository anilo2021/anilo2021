# set output file path
$OutputFile = '{pyParam}'
# get current timestamp in correct format
(Get-Date).tostring('yyyy/MM/dd HH:mm:ss') | Out-File -FilePath $OutputFile -Encoding ascii
# get OS info
Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object -Property BuildNumber,BuildType,OSType,ServicePackMajorVersion,ServicePackMinorVersion | Out-File -FilePath $OutputFile -Append -Encoding ascii
# get Desktop info
Get-CimInstance -ClassName Win32_Desktop | Select-Object -ExcludeProperty 'CIM*' | Out-File -FilePath $OutputFile -Append -Encoding ascii
# get CPU info
Get-CimInstance -ClassName Win32_Processor | Select-Object -ExcludeProperty 'CIM*' | Out-File -FilePath $OutputFile -Append -Encoding ascii
# get Storage info
Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' | Out-File -FilePath $OutputFile -Append -Encoding ascii
