####################################################################################################
# Name:                 pbiecapacityresize.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azurevmpower.vsdx
# Command line usage:   python start.py pbiecapacityresize <capacityName> <newSize> <timeoutPeriod>
# Purpose:              Resize a PBI Embedded Capacity hosted on Azure
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-11-29 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
import multiprocessing
from pathlib import Path
import sys
# local module imports
from msazure.azuresession import azureSession

# main script logic
def pbieCapacityResize(session, capacityName, sizeOption, monitorTimeout=None):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        session.log(text='Script disabled in config file')
        return False
    # check capcity current state
    capacityJson = session.pbieCapacityDetailsGet(capacityName)
    session.createJsonFile('json/'+session.logFileName.stem+'_capacityInstance.json', capacityJson)
    # check if sizeOption is already current size 
    if capacityJson['sku']['name'] == sizeOption:
        session.log(text='Capacity SKU already as specified - no need to update')
        return True
    # grab sizing options
    sizes = session.pbieCapacitySkusGet(capacityName)
    newSize = None
    # search size options for provided size
    for size in sizes:
        if size['sku']['name'] == sizeOption:
            newSize = size['sku']
            break
    if not newSize:
        raise ValueError('Invalid capacity size option "'+sizeOption+'"! Terminating script...')
    # set update SKU to new SKU
    capacityJson['sku'] = newSize
    # send request to actually update
    session.log(text='Updating PBI Embedded capacity '+capacityName+' to SKU: '+newSize['name'])
    updateResponse = session.pbieCapacityUpdate(capacityName, capacityJson)
    # handle monitoring if applicable
    if monitorTimeout:
        # fail if update call response is not as expected (probably Azure error)
        if 'Azure-AsyncOperation' not in updateResponse.headers:
            session.log(text='No operation ID returned by Azure! Check the resource '+capacityName+' in the Azure portal. This error may be caused by the capacity being paused. Terminating script...')
            raise ValueError('No operation ID returned by Azure! Terminating script...')
        if session.monitorAysnc(updateResponse, monitorTimeout):
            # generate JSON file from resource
            capacityJsonFile = session.createJsonFile(
                'json/'+session.logFileName.stem+'_DetailsGet.json', 
                session.pbieCapacityDetailsGet(capacityName)
            )
            # send notification email with JSON file attached
            session.azureEmail(
                body='Capacity '+capacityName+' has been resized to Tier '+sizeOption.upper(),
                color='green',
                attachment=capacityJsonFile
            )
            return True
        else:
            raise ValueError('Asynchronous operation failed! Terminating script...')
    else:
        return True

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, sys.argv[1]+'_'+sys.argv[2])
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # handle command line args
            if len(sys.argv) <= 3:
                pbieCapacityResize(sessionContainer['azure'], sys.argv[1], sys.argv[2])
            else:
                pbieCapacityResize(sessionContainer['azure'], sys.argv[1], sys.argv[2], monitorTimeout=int(sys.argv[3])*60)
            sessionContainer['azure'].log(text='Script execution succeeded')
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])