####################################################################################################
# Name:                 azureresize.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azureresize.vsdx
# Command line usage:   python start.py azureresize <resourceType> <resourceName> <sizingOption> <timeoutPeriod>
# Purpose:              Resize either a Database or VM hosted on Azure
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-14 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
from pathlib import Path
import pyodbc
import sys
# local module imports
from msazure.azuresession import azureSession 
from dwops.dwopssession import dwopsSession

# function to resize a database
def azureDbResize(session, dbName, sizeOption, monitorTimeout=None):
    # load sizing options JSON
    sizes = session.scriptConfig['sizingOptions']['db']
    if sizeOption not in sizes:
        raise ValueError('Invalid database size option "'+sizeOption+'"! Terminating script...')
    newSize = sizes[sizeOption]
    # retrieve current database config info
    dbJson = session.dbStateGet(dbName)
    # return if no need to update
    if newSize == dbJson['properties']['currentSku']:
        session.log(text='Database SKU already as specified - no need to update')
    else:
        dbJson['sku'] = newSize
        # send request to actually update
        session.log(text='Updating database '+dbName+' to SKU:\n\tTier: '+newSize['tier']+'\n\tCapacity: '+str(newSize['capacity'])+' DTUs')
        updateResponse = session.dbUpdate(dbName, dbJson)
        # handle monitoring if applicable
        if monitorTimeout:
            # fail if update call response is not as expected (probably Azure error)
            if 'Azure-AsyncOperation' not in updateResponse.headers:
                session.log(text='Update operation failed! Check the resource '+dbName+' in the Azure portal. Terminating script...')
                raise ValueError('No operation ID returned by Azure')
            if session.monitorAysnc(updateResponse, monitorTimeout):
                # generate JSON file from resource
                dbJson = session.dbStateGet(dbName)
                dbJsonFile = session.createJsonFile('json/'+session.taskName+'_DetailsGet.json', dbJson)
                # send email with JSON file attached
                session.azureEmail(
                    body='Database '+dbName+' has been resized to '+sizeOption.upper()+' with:<br> - Tier: '+newSize['tier']+'<br> - Capacity: '+str(newSize['capacity'])+' DTUs',
                    color='green',
                    attachment=dbJsonFile
                )
                dbJsonFile.unlink()
                # wait enough time for internal system stats to refresh
                session.timer(30)
                # instantiate dwopsWrapper and manipulate members
                dwops = dwopsSession('', '', logFileName=session.logFileName)
                dwops.directory = session.directory
                dwops.connection = dwops.login(dbName.split('/')[-1])
                dwops.cursor = dwops.connection.cursor()
                # validate database successfully resized
                dwops.executeSqlFile('dbResourceStatsSel.sql')
                session.log(text='Query results:')
                result = dwops.cursor.fetchall()
                for row in result:
                    session.log(text=str(row))
                dwops.logout()
                if result[0].dtu_limit != newSize['capacity']: 
                    raise pyodbc.Error('Database '+dbName+' verification failed! Terminating script...')
            else:
                return False
    return True

# function to resize a database
def azureVmResize(session, vmName, sizeOption, monitorTimeout=None):
    # load sizing options JSON
    sizes = sizes = session.scriptConfig['sizingOptions']['vm']
    if sizeOption not in sizes:
        raise ValueError('Invalid database size option "'+sizeOption+'"! Terminating script...')
    newSize = sizes[sizeOption]
    # retrieve current virtual machine config info
    vmJson = session.vmDetailsGet(vmName)
    # return if no need to update
    if newSize == vmJson['properties']['hardwareProfile']:
        session.log(text='VM Size already as specified - no need to update')
        return True
    else:
        vmJson['properties']['hardwareProfile'] = newSize
        session.log(text='Updating virtual machine '+vmName+' to size '+newSize['vmSize'])
        session.createJsonFile('derp0.json', vmJson)
        # clean JSON before sending to avoid errors
        del vmJson['properties']['networkProfile']
        del vmJson['properties']['storageProfile']
        del vmJson['resources']
        # send request to actually update
        updateResponse = session.vmUpdate(vmName, vmJson)
        session.createJsonFile('derp1.json', updateResponse.json())
        if monitorTimeout:
            # fail if update call response is not as expected (probably Azure error)
            if 'Azure-AsyncOperation' not in updateResponse.headers:
                session.log(text='Update operation failed! Check the resource '+vmName+' in the Azure portal. Terminating script...')
                raise ValueError('No operation ID returned by Azure')
            if session.monitorAysnc(updateResponse, monitorTimeout):
                # generate JSON file from resource
                vmJson = session.vmDetailsGet(vmName)
                vmJsonFile = session.createJsonFile('json/'+session.taskName+'_DetailsGet.json', vmJson)
                # send email with JSON file attached
                session.azureEmail(
                    body='Virtual machine '+vmName+' has been resized to '+sizeOption.upper()+' with size '+newSize['vmSize'],
                    color='green',
                    attachment=vmJsonFile
                )
                vmJsonFile.unlink()
                # run confirmation command on VM
                cmdJson = json.load(open(session.directory/'json'/'ipconfigrequest.json'))
                session.createJsonFile('herp.json', session.monitorAysnc(session.vmCmdRun(vmName, cmdJson), monitorTimeout).json())
            else:
                return False
    return True


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, sys.argv[1].replace('/', '_'))
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # handle command line args
            if sys.argv[1] == 'db':
                azureDbResize(sessionContainer['azure'], sys.argv[2], sys.argv[3], int(sys.argv[4])*60)
            elif sys.argv[1] == 'vm':
                azureVmResize(sessionContainer['azure'], sys.argv[2], sys.argv[3], int(sys.argv[4])*60)
            else:
                raise ValueError('Resource type '+sys.argv[1]+' not supported')
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e)