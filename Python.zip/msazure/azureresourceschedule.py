####################################################################################################
# Name:                 azureresourceschedule.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msazure/azureresourceschedule.vsdx
# Command line usage:   python start.py azureresourceschedule
# Purpose:              Perform scheduled operations on Azure resources
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-14 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2021-12-08 J. Rominske (jesr114@kellyservices.com)       Reordered loop for efficiency and clarity
####################################################################################################

# library imports
import datetime
import json
from pathlib import Path
import sys
import time
# local module imports
from msazure.azuresession import azureSession
from msazure.azureresize import azureDbResize
from msazure.azurevmpower import azureVmPower
from msazure.pbiecapacitypower import pbieCapacityPowerToggle
from msazure.pbiecapacityresize import pbieCapacityResize

# main logic function
def azureResourceSchedule(session):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        return False
    # load schedule from config
    azureOperations = session.scriptConfig['schedule']
    timingWindow = session.scriptConfig['timingWindow']
    # generate a time based on this instant in the script
    now = datetime.datetime.today()
    session.log('Current time is : '+now.strftime('%Y-%m-%d %H:%M:%S'))
    # generate a time representing the beginning of the timing window, the provided number of minutes before the script ran
    earliest = now - datetime.timedelta(minutes=timingWindow)
    session.log('Start of timing window was : '+earliest.strftime('%Y-%m-%d %H:%M:%S'))
    # iterate through operations in schedule
    failedOperations = []
    session.log('Executing operations scheduled within time window...')
    # iterate through all types of operations
    for operationType in azureOperations:
        # iterate through the list of operations for each provided type
        for operation in azureOperations[operationType]:
            # if operation is disabled, skip
            if operation['disabled']:
                session.log('\tOperation '+operation['name']+' disabled - skipping')
                continue
            # get scheduled time from the operation data
            scheduleTime = operation['time']
            # generate a time representing the intended time for the given operation to happen
            intended = now.replace(hour=scheduleTime['hour'], minute=scheduleTime['minute'], second=scheduleTime['second'], microsecond=000000)
            session.log('\tTarget time for operation '+operation['name']+' is : '+intended.strftime('%Y-%m-%d %H:%M:%S'))
            # if time conditions fulfilled, proceed with operation
            if now >= intended and intended >= earliest:
                # check the day of the week is correct
                if now.weekday() in operation['days']:
                    try:
                        success = False
                        # switch behavior based on which script is being called
                        params = operation['params']
                        if operationType == 'azuredbresize':
                            success = azureDbResize(session, params['dbName'], params['sizeOption'], params['monitorTimeout'])
                        elif operationType == 'azurevmpower':
                            success = azureVmPower(session, params['desiredState'], params['vmName'], params['checkService'], params['monitorTimeout'])
                        elif operationType == 'pbiecapacitypower':
                            success = pbieCapacityPowerToggle(session, params['desiredState'], params['capacityName'], params['monitorTimeout'])
                        elif operationType == 'pbiecapacityresize':
                            success = pbieCapacityResize(session, params['capacityName'], params['sizeOption'], params['monitorTimeout'])
                        # add to failed list if the operation returns False
                        if not success:
                            failedOperations.append(operation['name'])
                    # add to failed list if the operation fails
                    except Exception as e:
                        session.error(e, exit=False)
                        failedOperations.append(operation['name'])
                # if day of week is incorrect, skip the operation
                else:
                    session.log('\tOperation '+operation['name']+' not scheduled for this day - skipping')
                    continue
            # if outside the time window for the script, skip the operation
            else:
                session.log('\tOperation '+operation['name']+' out of time window - skipping')
                continue
            session.log(text='\tExecuting operation '+operation['name'])
                
    # give a summary and choose whether to fail the overall script or not
    if len(failedOperations) > 0:
        session.log(text='Scheduled operation failure summary:')
        for operation in failedOperations:
            session.log(text='\tOperation failed: '+operation)
        sys.exit(1)
    else:
        session.log(text='All scheduled operations succeeded.')
        return True


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['azure'] = azureSession(Path(__file__).stem, 'run')
    try:
        if not sessionContainer['azure'].login():
            sessionContainer['azure'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            azureResourceSchedule(sessionContainer['azure'])
            print('Script execution complete')
    except Exception as e:
        sessionContainer['azure'].azureError(e, email=sessionContainer['azure'].scriptConfig['errorNotification'])