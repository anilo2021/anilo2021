import time
import sys
from json import load as jsonLoad
from pathlib import Path

# local module imports
from databricks.databrickssession import databricksSession

def logMessage(session, message):
  session.log(text=message)

def cancelRun(session, workspaceName, jobId, runId):
  cancelRunResponse = session.cancelRun(workspaceName, runId)
  if cancelRunResponse.status_code == 200:
    logMessage(session, 'requested successfully to cancel run id:{0} of job id: {1}'.format(runId, jobId))
  else:
    logMessage(session, 'received error response while cancelling run id:{0} of job id: {1}. Error code: {2} and response: {3}'.format(runId, jobId, cancelRunResponse.status_code, cancelRunResponse.content))
    
def monitorStatus(session, workspaceName, jobId, runId, jobParams, maxRetries, checkInterval, timeOutArg, cancelJobWhenTimeoutOrExceedRetry, emailRecipients):
  state = ''
  jobName = ''
  jobPageUrl = ''
  repairId = ''  
  runCounter = 1 
  startTime = time.time()

  while (state != 'SUCCESS') and (runCounter <= (maxRetries+1)):
    #checks for timeout
    if (time.time() - startTime) > timeOutArg:
      errorMessage ='timed out while monitoring job status but job state is "{0}", hence terminating this process.'.format(state)
      logMessage(session, errorMessage)
      if cancelJobWhenTimeoutOrExceedRetry and (state == 'RUNNING'):
        cancelRun(session, workspaceName, jobId, runId)
      session.databricksError(errorMessage, True, emailRecipients)
    
    time.sleep(checkInterval)
    getJobStatusResponse = session.getJobStatus(workspaceName, runId)
    logMessage(session, 'received "getJobStatus" REST API response with status code: {0} and content: {1}'.format(getJobStatusResponse.status_code, getJobStatusResponse.content))
    
    if getJobStatusResponse.status_code == 200:      
      getJobStatusJsonObject = getJobStatusResponse.json()
      jobState = getJobStatusJsonObject['state']
      jobName = getJobStatusJsonObject['run_name']
      jobPageUrl = getJobStatusJsonObject['run_page_url']

      if jobState['life_cycle_state'] in ['TERMINATED','INTERNAL_ERROR']:
         state = jobState['result_state']
      else:
        state = jobState['life_cycle_state']
      
      logMessage(session, 'found job status: {0}'.format(state))  
     
      if (state == 'FAILED'):
        if (runCounter <= maxRetries):
          logMessage(session, '\nnumber of retry: '+ str(runCounter))
          if repairId == '':
            jsonRequestObject = {"run_id": runId, "rerun_all_failed_tasks": True}
          else:
            jsonRequestObject = {"run_id": runId, "rerun_all_failed_tasks": True, 'latest_repair_id': repairId}
          jsonRequestObject['notebook_params'] = jobParams
          repairRunResponse = session.repairRun(workspaceName, jsonRequestObject)
          logMessage(session, 'received "repairRun" REST API response with status code: {0} and content: {1}'.format(repairRunResponse.status_code, repairRunResponse.content))

          if repairRunResponse.status_code == 200:
            repairRunJsonObject = repairRunResponse.json()
            repairId = repairRunJsonObject['repair_id']
          else:
            errorMessage = 'error occured while calling "repairRun" REST api, error response: {0}'.format(repairRunResponse)
            logMessage(session, errorMessage)
            session.databricksError(errorMessage, True, emailRecipients)  
        runCounter = runCounter + 1
      elif state == 'CANCELED' or state == 'SKIPPED':
        errorMessage = 'job was "{0}".'.format(state)
        logMessage(session, errorMessage)
        session.databricksError(errorMessage, True, emailRecipients)
    else:            
      errorMessage = 'error occured while calling "getJobStatus" REST api, error response: {0}'.format(getJobStatusResponse)
      logMessage(session, errorMessage)
      session.databricksError(errorMessage, True, emailRecipients)

  if (state != 'SUCCESS') and (runCounter >= (maxRetries+1)):
    errorMessage =('exceeded maximum retry attempts of {0} but job status still in "{1}" state, hence terminating this process.'.format(maxRetries, state))
    if state == 'RUNNING':
      logMessage(session, 'job status is in "{0}" state, hence cancelling job...'.format(state))
      cancelRun(session, workspaceName, jobId, runId)
    logMessage(session, errorMessage)
 
  return state, jobName, jobPageUrl

def executeWorkflow(session, caseNumber, workspaceName, jobId):
  jobParams = None
  cancelJobWhenTimeoutOrExceedRetry = True

  configFileName = session.env+'_databricksworkflowtriggerconfig.json'
  databrickJobConfig = jsonLoad(open(session.configDirectory/(configFileName)))
  if caseNumber in databrickJobConfig["workflowSettings"]:
    session.config = databrickJobConfig["workflowSettings"][caseNumber]
    del databrickJobConfig
  else:
    errorMessage = 'provided "caseNumber" config values are missing in {0} file.'.format(configFileName)
    logMessage(session, errorMessage)
    session.databricksError(errorMessage, True)

  maxRetries = session.config["maxRetries"]
  checkIntervalInSec = session.config["checkIntervalInSec"]
  timeoutInSec = session.config["timeoutInSec"]
  emailRecipients = session.config["emailRecipients"]
  if "cancelJobWhenTimeoutOrExceedRetry" in session.config:
    cancelJobWhenTimeoutOrExceedRetry = session.config["cancelJobWhenTimeoutOrExceedRetry"]
  else:
    errorMessage = '"cancelJobWhenTimeoutOrExceedRetry" is missing for caseNumber: {0}, hence assigning default value as "True"'.format(caseNumber)
    logMessage(session, errorMessage)

  logMessage(session, 'maxRetries: {0}'.format(maxRetries))
  logMessage(session, 'checkInterval (in seconds): {0}'.format(checkIntervalInSec))
  logMessage(session, 'timeoutInSec (in seconds): {0}'.format(timeoutInSec))
  logMessage(session, 'cancelJobWhenTimeoutOrExceedRetry: {0}'.format(cancelJobWhenTimeoutOrExceedRetry))

  if 'emailRecipients' in session.config:
    if type(emailRecipients) == list:
      if len(emailRecipients) > 0:
        logMessage(session, 'emailRecipients: {0}'.format(emailRecipients))
      else:
        errorMessage = '"emailRecipients" argument is empty for caseNumber: {0}'.format(caseNumber)
        logMessage(session, errorMessage)
        session.databricksError(errorMessage, True)
    else:
      errorMessage = 'emailRecipients: argument should be a list object type'
      logMessage(session, errorMessage)
      session.databricksError(errorMessage, True)
  else:
    errorMessage = '"emailRecipients" is missing for caseNumber: {0}'.format(caseNumber)
    logMessage(session, errorMessage)
    session.databricksError(errorMessage, True)

  if 'jobParams' in session.config:
    jobParams = session.config["jobParams"]
    if type(jobParams) == dict:
      if not bool(jobParams):
        logMessage(session, 'jobParams: argument provided with empty value')
      else:
        logMessage(session, 'jobParams: {0}'.format(jobParams))
  else:
    logMessage(session, 'jobParams: no argument is not available')

  logMessage(session, '\ncalling startJob REST api...')
  startJobResponse = session.startJob(workspaceName, jobId, jobParams)
  logMessage(session, 'received "startJob" REST API response with status code: {0} and content: {1}'.format(startJobResponse.status_code, startJobResponse.content))

  if startJobResponse.status_code == 200:
    startJobJsonObject = startJobResponse.json()
    runId = startJobJsonObject['run_id']
    logMessage(session, 'start job ran successfully with runid: {0}'.format(runId))
    logMessage(session, 'calling monitorstatus REST api...')
    jobStatus, jobName, jobPageUrl = monitorStatus(session, workspaceName, jobId, runId, jobParams, maxRetries, checkIntervalInSec, timeoutInSec, cancelJobWhenTimeoutOrExceedRetry, emailRecipients)
    
    if jobStatus == 'SUCCESS':
      notificationMessage = 'job "{0}[{1}]" has been completed successfully.'.format(jobName, jobId)
      logMessage(session, notificationMessage)
      notificationMessage += '<br/>URL: {0}'.format(jobPageUrl)
      session.databricksSuccess(notificationMessage, email=True, recipients=emailRecipients)
    else:
      notificationMessage = 'job "{0}[{1}]" has been completed with "{2}" status.'.format(jobName, jobId, jobStatus)
      logMessage(session, notificationMessage)
      notificationMessage += '<br/>URL: {0}'.format(jobPageUrl)
      session.databricksError(notificationMessage, True, emailRecipients)

  else:
    errorMessage = 'error occured while calling "startJob" REST api, error response: {0}'.format(startJobResponse.text)
    logMessage(session, errorMessage)
    session.databricksError(errorMessage, True, emailRecipients)

# main thread
if __name__ == "__main__":
    print('Running...')

    caseNumber = ''
    workspaceName = ''
    jobId = ''

    if len(sys.argv) >= 2:
      caseNumber = sys.argv[1]

    if len(sys.argv) >= 3:
      workspaceName = sys.argv[2]

    if len(sys.argv) >= 4:
      jobId = sys.argv[3]

    sessionContainer = {}
    sessionContainer['databricks'] = databricksSession(baseName=Path(__file__).stem, taskName=jobId)
    
    if caseNumber != '':
      logMessage(sessionContainer['databricks'], 'received caseNumber: {0}'.format(caseNumber))
    else:
      errorMessage = 'missing "caseNumber" parameter'
      logMessage(sessionContainer['databricks'], errorMessage)
      sessionContainer['databricks'].databricksError(errorMessage, True)

    if workspaceName != '':
      logMessage(sessionContainer['databricks'], 'received workspaceName: {0}'.format(workspaceName))
    else:
      errorMessage = 'missing "workspaceName" parameter'
      logMessage(sessionContainer['databricks'], errorMessage)
      sessionContainer['databricks'].databricksError(errorMessage, True)

    if jobId != '':
      logMessage(sessionContainer['databricks'], 'received jobId: {0}'.format(jobId))
    else:
      errorMessage = 'missing "jobId" parameter'
      logMessage(sessionContainer['databricks'], errorMessage)
      sessionContainer['databricks'].databricksError(errorMessage, True)

    try:
      executeWorkflow(sessionContainer['databricks'], caseNumber, workspaceName, jobId)
      print('script execution complete')         
    except Exception as e:
      sessionContainer['databricks'].databricksError(e)      
