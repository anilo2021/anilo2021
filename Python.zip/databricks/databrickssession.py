# library imports
import requests
from json import load as jsonLoad
import os
import sys
from datetime import datetime, timedelta

# local module imports
from common.session import session

class databricksSession(session):
    def _setup(self):        
        self.directory = self.repoDirectory/'databricks'
        self.config = {}   
        self.hdrs = {}
        self.lastLogin = None
        self.basehdrs = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        self.databricksCreds = jsonLoad(open(self.secureDirectory/(self.env+'_databrickscreds.json')))
        self.loginUrl = 'https://login.microsoftonline.com/{0}/oauth2/v2.0/token'
        self.databricksUrl = 'https://{0}.azuredatabricks.net'
        self.envType = 'prod' if self.env in ('prd') else 'nonProd'
        self.req = requests.Session()        

    # method for logging into Azure Portal
    def login(self, workspaceName):
        workspaceCreds = self.databricksCreds['databricksInstance'][self.envType][workspaceName]
        loginData = {
                'grant_type': self.databricksCreds['grantType'],
                'client_id': workspaceCreds['clientId'],
                'client_secret': workspaceCreds['clientSecret'],
                'scope': self.databricksCreds['scope']
            }
        maskClientId = workspaceCreds['clientId']
        if len(maskClientId) > 8:
            maskClientId = maskClientId[:8]+'-****-****-****-************'
        self.log(text='login with id: '+ maskClientId)

        self.loginUrl = self.loginUrl.format(self.databricksCreds['tenantId'])
        response = self.req.post(self.loginUrl, headers={'Content-Type':'application/x-www-form-urlencoded'}, data=loginData)
        if response.status_code == 200 : 
            self.log(text='login success')
            # add token to headers
            self.hdrs['Authorization'] = "Bearer "+response.json()['access_token']
            self.lastLogin = datetime.now()
            return True
        else:
            self.log(text='login failed')
            self.log(text=response.text)
            return False

    def databricksEmail(self, subject, body, color, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName

        # send email with generic method
        with open(self.secureDirectory/'config'/'emailTemplates'/'emailbody_databricks.html') as template:
            self.email(subject=subject,
                       body=template.read().format(body), # replace "{}" in template file with values
                       color=color,
                       attachment=attachment, recipients=recipients) # call basic email function

    def databricksError(self, error, email=True, recipients=None):
        errorCode = self.error(error, exit=False)

        if recipients:
            recipients.extend(self.scriptConfig['emailRecipients']['error']['html'])
        else:
            recipients = self.scriptConfig['emailRecipients']['error']['html']

        if email:
            self.log(text='sending error notification email...')
            self.databricksEmail('Notification from ACE Databricks Automation System', 'An error occurred with code: '+str(errorCode)+'<br>Please check the logs.', color='red', recipients=recipients)
        sys.exit(errorCode)

    def databricksSuccess(self, body, email=False, recipients=None):
        if recipients:
            recipients.extend(self.scriptConfig['emailRecipients']['notification']['html'])
        else:
            recipients = self.scriptConfig['emailRecipients']['notification']['html']

        if email:
            self.log(text='sending success notification email...')
            self.databricksEmail('Notification from ACE Databricks Automation System', body, color='green', recipients=recipients)
        
    def _callAPI(self, reqType, url, workspaceName, headers=None, jsonData=None):        
        if not headers:
            headers = self.basehdrs.copy()

        if self.lastLogin:
            if (datetime.now() - self.lastLogin)/timedelta(minutes=1) > self.scriptConfig['loginTimeout']:
                self.login(workspaceName)
        else:
            self.login(workspaceName)

        headers['Authorization'] = self.hdrs['Authorization']        
        
        if reqType == 'GET':
            self.log(text='accessing GET API resource at '+url)
            return self.req.get(url, headers=headers)            
        elif reqType == 'POST':
            self.log(text='accessing POST API resource at '+url)            
            return requests.post(url, json=jsonData, headers=headers)         
        else:
            raise Exception('invaild reqType: ' + reqType)

    def startJob(self, workspaceName, jobId, jobParams=None):
        endpoint = self.databricksUrl.format(workspaceName) + '/api/2.1/jobs/run-now'
        jsonRequestObject = {"job_id": jobId}
        if jobParams:
            jsonRequestObject['notebook_params'] = jobParams
        self.log(text='startJob request object: '+ str(jsonRequestObject))  
        response = self._callAPI('POST', endpoint, workspaceName, jsonData=jsonRequestObject)        
        return response

    def getJobStatus(self, workspaceName, runId):        
        endpoint = self.databricksUrl.format(workspaceName) + '/api/2.1/jobs/runs/get?run_id={0}'.format(runId)
        response = self._callAPI('GET', endpoint, workspaceName)
        return response

    def repairRun(self, workspaceName, jsonRequestObject):        
        endpoint = self.databricksUrl.format(workspaceName) + '/api/2.1/jobs/runs/repair'
        response = self._callAPI('POST', endpoint, workspaceName, jsonData=jsonRequestObject)        
        return response
    
    def cancelRun(self, workspaceName, runId):        
        endpoint = self.databricksUrl.format(workspaceName) + '/api/2.1/jobs/runs/cancel'
        jsonRequestObject = {"run_id": runId}
        response = self._callAPI('POST', endpoint, workspaceName, jsonData=jsonRequestObject)        
        return response

# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    try:        
        session = databricksSession(os.path.basename(__file__)[:-3], 'test')
        print('script execution complete')
    except Exception as e:        
        session.databricksError(e)
        print('error occured:', e)
        