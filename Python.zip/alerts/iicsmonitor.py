####################################################################################################
# Name:                 iicsmonitor.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/iicsmonitor.vsdx
# Command line usage:   python start.py pwxchecklogsdetail --objecttype [-a]
# Purpose:              Test all the connections within an IICS org arranging the tests by runtime environment
#                       and sends eMail alerts when issues are detected/resolved.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-09-16 C. Bravo (carb755@kellyservices.com)          Original Author
# 2018-11-06 J. Rominske (jesr114@kellyservices.com)       Combined iicsMonitorOrgConns.py and iicsMonitorOrgRunEnvironments.py 
#                                                          to iicsmonitor.py, cleaned up and reorganized file
####################################################################################################

# library imports
import json
from pathlib import Path
import sys

# local module imports
from alerts.alertssession import alertsSession 
from iics.iicssession import iicsSession

# function to monitor objects in IICS org (wrapper of session monitor function)
def monitorOrg(session, typeFlag, activeFlag):
    session['alerts'].log(text='Retrieving org details...')
    orgJsonData = session['iics'].orgGet('').json()
    orgName = orgJsonData[0]['name']+ ' '+ orgJsonData[0]['orgId']
    session['alerts'].log(text='IICS Org = '+orgName)
    # get runtimeEnvironment data
    session['alerts'].log(text='Retrieving runtimeEnvironments details...')
    rEnvJsonData = session['iics'].runtimeEnvironmentGet('').json()
    session['alerts'].log(text='IICS Org '+ orgName+ ' contains '+ str(len(rEnvJsonData))+ ' runtimeEnvironments:')   
    # toggle object type to monitor
    if typeFlag == '--environment':
        rEnvCount = 0
        conflictCnt = 0
        # loop runtimeEnvironments>>Agents>>agentEngines to evaluate status
        for item in rEnvJsonData:
            rEnvCount +=1
            session['alerts'].log(text='\n'+str(rEnvCount)+') '+item['@type']+' '+item['name']+' ['+item['id']+'] '+'contains '+str(len(item['agents']))+' agents.')
            for agentItem in item['agents']:
                # if activeOnly filter enabled, skip elements that are not active
                if activeFlag and not agentItem['active']:
                    continue
                #get agents detail data
                agentdetJsonData = session['iics'].agentDetailsGet(agentItem['id']).json()
                session['alerts'].log(text='  ~ checking agentEngines for '+agentdetJsonData['agentHost']+' | host: '+agentdetJsonData['name']+' | upgradeStatus = '+agentdetJsonData['upgradeStatus'])
                for agentEngineItem in agentdetJsonData['agentEngines']:
                    xenginesData = agentEngineItem['agentEngineStatus']
                    #if the agent is upgrading: do not check the engines and do not alert. 
                    if agentdetJsonData['upgradeStatus'] == "NotUpgrading":
                        if xenginesData['status'] == xenginesData['desiredStatus']:
                            session['alerts'].log(text='    > '+xenginesData['appDisplayName']+' is '+xenginesData['status'])
                        else: 
                            conflictCnt +=1
                            session['alerts'].log(text='[error]... '+xenginesData['appDisplayName']+' status is '+ xenginesData['status']+', desired status is '+xenginesData['desiredStatus'])
                    else:
                        session['alerts'].log(text=('    ***Not checking agentEngynes: '+ agentdetJsonData['agentHost']+ ' | host: '+ agentdetJsonData['name']+ ' | upgradeStatus = '+ agentdetJsonData['upgradeStatus']))
    elif typeFlag == '--connection':
        session['alerts'].log(text='Retrieving connections details...')
        connResponse = session['iics'].connectionGet('').json() 
        session['alerts'].log(text='Total connections within the IICS Org = '+ str(len(connResponse)))
        rEnvCount = 0
        conflictCnt = 0
        # loop runtimeEnvironments and test the connections
        for item in rEnvJsonData:
            rEnvCount +=1
            session['alerts'].log(text='\n'+ str(rEnvCount) +') Executing tests for connections within the '+ item['@type']+' '+ item['name']+ ' ['+ item['id']+ ']:') 
            connItemcount = 0
            for connitem in connResponse:
                if connitem['runtimeEnvironmentId'] == item['id'] and connitem['name'] not in session.config['iics'][session.env]['connExceptions']:
                    connItemcount +=1
                    session['alerts'].log(text='\n> Testing connection: '+connitem['name']+'...')
                    connTestResponse = session['iics'].connectionTest(connitem['id'])
                    connTestJson = connTestResponse.json()
                    if connTestResponse.status_code == 200:
                        session['alerts'].log(text="SUCCESS - Connection: "+connitem["name"]+" --"+connTestJson["description"])
                    else:
                        conflictCnt +=1 
                        session['alerts'].log(text="ERROR - Connection:"+connitem["name"]+" --"+connTestJson["description"])      
            session['alerts'].log(text='  *'+str(connItemcount) +' connection tests for the '+ item['@type']+' '+ item['name']+ ' ['+ item['id']+ '] complete\nfailures = '+str(conflictCnt)) 
    alertData = [conflictCnt, 0, 'IICS Org = '+orgName+'.<br><br>', 'IICS']
    session['alerts'].alertNotification(alertData, 'IICS {} monitor | {} | {}')        

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName=sys.argv[1])
    sessionContainer['iics'] = iicsSession('', '', logFileName=sessionContainer['alerts'].logFileName)
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            sessionContainer['alerts'].log(text='IICS login Success')
            if sys.argv[2].startswith('-t'):
                sessionContainer['alerts'].alertNotification([0, 'IICS'],'IICS {} monitor | Alert test confirmation | {}')
            else:
                # handle command line args
                activeFlag = True if '-a' in sys.argv[3] else False
                monitorOrg(sessionContainer, sys.argv[2], activeFlag)
                sessionContainer['iics'].logout()
                print('Script execution complete')
                sessionContainer['alerts'].log(text='Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].error(e)