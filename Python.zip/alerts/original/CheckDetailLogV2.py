#####################################################################################################################
###  Script Name: checkDetail.py
###
###
###  Description: Check PowerExchange logs for errors and inactivity
###
###  Input parameters are as follows:
###	
###
###
#####################################################################################################################
###
###  Maintenance Log:
###
###  Date          Author             Description
###  ====          ==============     ===========
###
###  2018-08-14    Jeff Harrington    Original
###
#####################################################################################################################


import os 
import sys
import glob
import datetime
from datetime import timedelta
from optparse import OptionParser


def checkAll():
    sendMessage = 'N'
    errorOut = 'N'
    warningOut = 'N'
    foundError = 'N'
    foundWarning = 'N'
    curTime = str(datetime.datetime.now())
    # 2018-08-13 19:06:53.058000
    curTime2 = curTime[2:4]+curTime[5:7]+curTime[8:10]+curTime[11:13]+curTime[14:16]+curTime[17:19]
    print('--------------------------------- ' + curTime2)
    print('\n--------------------------------- ' + curTime)
    #checkTime = long(curTime2)
    checkTime = datetime.datetime.now()
    
    listString = ['error ']
    logString = ['error ','gap ']
    utilString = ['command ok!','time of next file switch']
    tomcatString = ['failed to send heartbeat','dtm process terminated unexpectedly']
        
    fnListFileType = 'FN Listener'
    hrListFileType = 'HR Listener'
    fnLogFileType = 'FN Logger'
    hrLogFileType = 'HR Logger'
    tomcatFileType = 'Tomcat Log'
    fnListFileName = "//amchwinfprd02/amchwinfprd02/informatica/pwxconfig/prd_fn/listlog/detail.log"
    hrListFileName = "//amchwinfprd02/amchwinfprd02/informatica/pwxconfig/prd_hr/listlog/detail.log"
    fnLogFileName = "//amchwinfprd02/amchwinfprd02/informatica/pwxconfig/prd_fn/ccllog/detail.log"
    hrLogFileName = "//amchwinfprd02/amchwinfprd02/informatica/pwxconfig/prd_hr/ccllog/detail.log"
    fnListCheckFileName = "//amchwinfprd02/amchwinfprd02/Monitor/fnListCheck.log"
    hrListCheckFileName = "//amchwinfprd02/amchwinfprd02/Monitor/hrListCheck.log"
    fnLoggerCheckFileName = "//amchwinfprd02/amchwinfprd02/Monitor/fnLoggerCheck.log"
    hrLoggerCheckFileName = "//amchwinfprd02/amchwinfprd02/Monitor/hrLoggerCheck.log"
    tomcat01Folder = "//amchwinfprd01/amchwinfprd01/Informatica Cloud Secure Agent/apps/Data_Integration_Server/logs/tomcat/*"
    tomcat03Folder = "//amchwinfprd03/amchwinfprd03/Informatica Cloud Secure Agent/apps/Data_Integration_Server/logs/tomcat/*"


    list_of_files = glob.glob(tomcat01Folder) 
    print ('############'+str(list_of_files)+'\n\n\n')
    latest_file = max(list_of_files, key=os.path.getctime)
    tomcat01FileName = latest_file
    
    list_of_files = glob.glob(tomcat03Folder) 
    latest_file = max(list_of_files, key=os.path.getctime)
    tomcat03FileName = latest_file

    print('\n----tomcat01FileName: ' + tomcat01FileName)
    print('\n----tomcat03FileName: ' + tomcat03FileName)
    
    errorOut, warningOut = checkFile(fnListFileName,fnListFileType,listString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'
    if warningOut =='Y':
        sendMessage = 'Y'
        foundWarning = 'Y'
    errorOut, warningOut = checkFile(hrListFileName,hrListFileType,listString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'
    if warningOut =='Y':
        sendMessage = 'Y'
        foundWarning = 'Y'
    errorOut, warningOut = checkFile(fnLogFileName,fnLogFileType,logString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'
    if warningOut =='Y':
        sendMessage = 'Y'
        foundWarning = 'Y'
    errorOut, warningOut = checkFile(hrLogFileName,hrLogFileType,logString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'
    if warningOut =='Y':
        sendMessage = 'Y'
        foundWarning = 'Y'
    errorOut = checkUtil(fnListCheckFileName,utilString)
    if errorOut == 'Y':
        print('FN Listener is Down, see log ' + fnListCheckFileName)
        sendMessage = 'Y'
        foundError = 'Y'
    errorOut = checkUtil(hrListCheckFileName,utilString)
    if errorOut == 'Y':
        print('HR Listener is Down, see log ' + hrListCheckFileName)
        sendMessage = 'Y'
        foundError = 'Y'
    errorOut = checkUtil(fnLoggerCheckFileName,utilString)
    if errorOut == 'Y':
        print('FN Logger is Down, see log ' + fnLoggerCheckFileName)
        sendMessage = 'Y'
        foundError = 'Y'
    errorOut = checkUtil(hrLoggerCheckFileName,utilString)
    if errorOut == 'Y':
        print('HR Logger is Down, see log ' + hrLoggerCheckFileName)
        sendMessage = 'Y'
        foundError = 'Y'        
    errorOut = checkTomcat(tomcat01FileName,tomcatFileType,tomcatString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'

    errorOut = checkTomcat(tomcat03FileName,tomcatFileType,tomcatString,checkTime)
    if errorOut == 'Y': 
        sendMessage = 'Y'
        foundError = 'Y'
    
    # print 'Error Found = '+ sendMessage
    
    if sendMessage == 'N':
        raise SystemExit(0)
    else:
        if foundError == 'Y':
            raise SystemExit(12)
        else:
            raise SystemExit(8)


def checkFile(fileName,fileType,searchString,checkTime):

    errorOut = 'N'
    warningOut = 'N'
    file=open(fileName, "r") 
    print('\n\n----ckecking file :') 
    print(fileName,fileType,searchString,checkTime) 
    print('===============------------------ ')



    lastLog = datetime.datetime.strptime('2011-08-13 19:06:53.058000',"%Y-%m-%d %H:%M:%S.%f")
    for line in  file:
        if line[0:2]!= '  ':
            logTime = '20'+str(line[0:2])+'-'+str(line[2:4])+'-'+str(line[4:6])+' '+str(line[7:9])+':'+str(line[9:11])+':'+str(line[11:13])+'.000000'
            # print 'current time: '+str(checkTime) +  '    Log Time: '+ logTime
            logTime2 = datetime.datetime.strptime(logTime,"%Y-%m-%d %H:%M:%S.%f")
            # print 'Current Time to Log Time difference: '+str(((checkTime-logTime2).seconds/60))
            if logTime2 > lastLog:
                lastLog = logTime2
    file.close()
                
    if ((((checkTime-logTime2).days * 86400) + (checkTime-logTime2).seconds)/60) > 30:
        print("Warning No Activity for 30 minutes in " + fileType + ", log File " + fileName)
        # print(line)
        warningOut = 'Y'
      
    file=open(fileName, "r")        
    lineNum = 0
    for line in file:
        lineNum = lineNum + 1
        logTime = '20'+str(line[0:2])+'-'+str(line[2:4])+'-'+str(line[4:6])+' '+str(line[7:9])+':'+str(line[9:11])+':'+str(line[11:13])+'.000000'
        # print 'current time: '+str(checkTime) +  '    Log Time: '+ logTime
        if line[0:2] == '  ':
            logTime2 = logTime2
        else:
            logTime2 = datetime.datetime.strptime(logTime,"%Y-%m-%d %H:%M:%S.%f")
        # print 'CheckTime '+str(checkTime)+'    LastLog   '+str(lastLog)
        if ((((checkTime-logTime2).days * 86400) + (checkTime-logTime2).seconds)/60) < 20:
            # print 'CheckTime '+str(checkTime)+'    LastLog   '+str(lastLog)
            # print 'last error within 35 minutes'
            if any (x in line.lower() for x in searchString):
                print("Error in " + fileType + ", log File " + fileName + " line number " + str(lineNum) + ':')
                print(line)
                errorOut = 'Y'
    file.close()
                
    return errorOut, warningOut
    
def checkUtil(fileName, searchString):
    errorOut = 'Y'
    file=open(fileName, "r")        
    #line=file.readlines()
    #file.close()
    
    for line in file:
        if any (x in line.lower() for x in searchString):
            # print(line)
            errorOut = 'N'
            
    file.close()
	
    return errorOut
    
    
def checkTomcat(fileName,fileType,searchString,checkTime):

    errorOut = 'N'
    file=open(fileName, "r")        

    lineNum = 0
    for line in file:
        lineNum = lineNum + 1
        logTime = str(line[0:19])+'.000000'
        # print 'current time: '+str(checkTime) +  '    Log Time: '+ logTime
        if line[0:2] != '20':
            logTime2 = logTime2
        else:
            logTime2 = datetime.datetime.strptime(logTime,"%Y-%m-%d %H:%M:%S.%f")
        # print 'CheckTime '+str(checkTime)+'    LastLog   '+str(lastLog)
        if ((((checkTime-logTime2).days * 86400) + (checkTime-logTime2).seconds)/60) < 20:
            # print 'CheckTime '+str(checkTime)+'    LastLog   '+str(lastLog)
            # print 'last error within 35 minutes'
            if any (x in line.lower() for x in searchString):
                print("Error in " + fileType + ", log File " + fileName + " line number " + str(lineNum) + ':')
                print(line)
                errorOut = 'Y'
    file.close()
                
    return errorOut
    
def main():
    usage = "usage: %prog [options] logonFile"
    version = "%prog 1.0.0"
    description = \
        "Show All Objects on the System and write to a file"
    parser = OptionParser(usage=usage, version=version, description=description)

    (options, args) = parser.parse_args()
    
    checkAll()
 
if __name__ == '__main__':
    main()

