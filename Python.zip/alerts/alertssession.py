####################################################################################################
# Name:                 alertssession.py
# Python version:       Python 3.6.4
# Wiki path:            
# Command line usage:   N/A
# Purpose:              Class contains methods for "grunt work" of Python automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-09-16 C. Bravo (carb755@kellyservices.com)          Original Author [as cogAlertsWrapper and iicsalrtswrapper]
# 2019-01-02 J. Rominske (jesr114@kellyservices.com)       Consoldated into alertssession
####################################################################################################

# library imports
import datetime
import json
import multiprocessing
from pathlib import Path
import platform
import requests
import ssl
import subprocess
import sys
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

# local module imports
from common.session import session

# wrapper subclass with methods relevant to Infrastructure alerts
class alertsSession(session):
    # overloaded setup function
    def _setup(self):
        self.directory = self.repoDirectory/'alerts'
        # load stored credentials from JSON file
        self.alertsDbCreds = json.load(open(self.secureDirectory/(self.env+'_alertsdbcreds.json')))[self.args[0]]
        # load session config file
        self.config = json.load(open(self.configDirectory/(self.env+'_alertsconfig.json')))
        # instantiate container for status data
        self.statData = {}
        # requests session instantiation
        self.req = requests.Session()

    # method for sending emails specific to IICS
    def alertsEmail(self, body, color, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # by default, use the notification recipients
        if recipients is None:
            recipients = self.scriptConfig['emailRecipients']['notification']
        # send email with generic method
        self.email(body=body, # replace "{}" in template file with values
                   color=color,
                   attachment=attachment,
                   recipients=recipients) # call basic email function

    # method for send error report email for IICS
    def alertsError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.alertsEmail(body='An error occurred with code: '+str(errorCode)+'<br>Please check the logs.',
                             color='red',
                             recipients=self.scriptConfig['emailRecipients']['error'])
        sys.exit(errorCode)

    # function to pin a given URL
    def getUrl(self, url, prevError=0):
        conflictCnt = 0
        if prevError < self.config['retry']['urlGetRetry']:
            try:
                self.log(text='\tPerforming GET respest on URL '+ url+ '...')
                serverResponse = self.req.get(url, timeout=self.config['retry']['urlGetTimeout'])
                if serverResponse.status_code != 200:
                    conflictCnt = 1
            except requests.exceptions.RequestException as e:
                self.error(e, exit=False)
                self.log(text='Server URL check exception caught')
                conflictCnt = 1
            if conflictCnt != 0:
                return self.getUrl(url, prevError=prevError+1) # tail recursion with incremented prevError
            else:
                return conflictCnt
        else:
            conflictCnt = 1
            return conflictCnt

    # function to open a given URL
    def pingServer(self, hostname, prevError=0):
        conflictCnt = 0
        if prevError < self.config['retry']['pingRetry']:
            pingOutput = b''
            try:
                self.log(text='\tPinging server '+ hostname+ '...')
                pingOutput = subprocess.check_output('ping -c 1 '+hostname, shell=True, stderr=subprocess.STDOUT, timeout=self.config['retry']['pingTimeout'])
            except subprocess.CalledProcessError as e:
                self.error(e, exit=False)
                self.log(text='Ping process exception caught')
                conflictCnt = 1
            self.log(text=pingOutput.decode('utf-8'))
            if conflictCnt != 0:
                return self.pingServer(hostname, prevError=prevError+1) # tail recursion with incremented prevError
            else:
                return conflictCnt
        else:
            conflictCnt = 1
            return conflictCnt

    # check weekly maintenance window
    def weekMaintWindow(self, force=False): # specify force=True to force maintenance window
        maintWindowList = self.scriptConfig['maintWindows']
        now = datetime.datetime.today()
        self.log(text='Current time is : '+now.strftime('%Y-%m-%d %H:%M:%S'))
        if not force:
            # checks server maintenance schedule provided
            for maintWindow in maintWindowList:
                # skip maintenance window if disabled
                if not maintWindow['disabled']:
                    # get scheduled time from the list entry
                    startTime = maintWindow['startTime']
                    endTime = maintWindow['endTime']
                    # generate times representing the start and end times of the window
                    start = now.replace(hour=startTime['hour'], minute=startTime['minute'], second=startTime['second'], microsecond=000000)
                    end = now.replace(hour=endTime['hour'], minute=endTime['minute'], second=endTime['second'], microsecond=000000)
                    session.log('\t"'+maintWindow['name']+'" time window is : '+start.strftime('%Y-%m-%d %H:%M:%S')+'-'+end.strftime('%Y-%m-%d %H:%M:%S'))
                    # if day and time conditions fulfilled, set maintenance window as active
                    if end >= now and now >= start and now.weekday() in maintWindow['weekdays']:
                        self.log(text='Script execution suspended due to the ongoing maintenance window.')
                        return True
            self.log(text='No maintenance window - executing script...\n')
            return False
        else:
            self.log(text='Maintenance window forced = "'+str(force)+'"\n')
            return force

    # update SUCCESS/ERROR status for alerts
    def statusUpdated(self):
        self.log(text='Checking for last execution status for script '+ self.scriptName+ '...')
        statFile = 'alertStatus_'+self.scriptName+'.json'
        statFileName = self.directory/'alertStatus'/statFile
        fileTimestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')              
        # create file if does not exist
        if not Path.is_file(statFileName):
            # create subfolder if needed
            if not Path.is_dir(statFileName.parent):
                statFileName.parent.mkdir(parents=True, exist_ok=True)
            # add starter data to file
            with open(statFileName, 'w+') as Nwf:  
                createFileData = {
                    'overall' : 'UNKNOWN',
                    'lastdate' : fileTimestamp,
                    'errorCnt': 0,
                    'warningCnt': 0}
                json.dump(createFileData, Nwf)
                self.log('Created file '+str(statFileName))
        # read last status data
        with open(statFileName, 'r') as rf:
            oldStat = json.load(rf)
            self.log(text=self.scriptName+' last execution status was "'+oldStat['overall']+'", recorded on '+oldStat['lastdate']+'.')
            del oldStat['lastdate']
        # evauluate desired overall status
        if self.statData['errorCnt'] != 0:
            self.statData['overall'] = 'ERROR'
        elif self.statData['warningCnt'] != 0:
            self.statData['overall'] = 'WARNING'
        else:
            self.statData['overall'] = 'SUCCESS'
        self.emailStatus = self.statData['overall'].lower()
        if oldStat != self.statData:
            statChanged = True
            self.log(text=self.scriptName+' execution status changed from the previous execution - statChanged set to "True".')
        else:
            statChanged = False
            self.log(text=self.scriptName+' current execution status is the same as the previous execution - statChanged set to "False".')
            if not self.config['notificationForced']:
                self.log(text='WARNING - Alert not sent due to the previous execution status "'+oldStat['overall']+'" matching the current execution status "'+self.statData['overall']+'".')
        self.statData['lastdate'] = fileTimestamp
        # dump new status data
        with open(statFileName, 'w+') as wf:
            json.dump(self.statData, wf)
            self.log(text=self.scriptName+' execution status has been updated to "'+self.statData['overall']+'", recorded on '+fileTimestamp+' into the file '+str(statFileName))
        # add resolved errors to statData after dump to prevent recording in the status JSON
        self.statData['resolvedErrors'] = max(0, oldStat['errorCnt']-self.statData['errorCnt'])
        self.statData['resolvedWarnings'] = max(0, oldStat['warningCnt']-self.statData['warningCnt'])
        return statChanged
        
    # method to monitor various web services or resources
    def alertNotification(self, test=False):
        # send alert email if enabled in config
        if self.config['notificationEnabled']:
            timestamp = datetime.datetime.today().strftime('%Y-%m-%d at %H:%M:%S')
            # send email if appropriate
            if test or self.statusUpdated() or self.config['notificationForced']:
                # if test email, simply send notification
                if test:
                    self.emailStatus = 'test'
                    recipients = self.scriptConfig['emailRecipients']['notification']
                    with open(self.repoDirectory/'common'/'emailTemplates'/('emailbody_alertsTest.html')) as template:
                        bodyInsert = template.read().format(self.scriptConfig['scriptTitle'])
                # if error, log and send notification
                else:
                    recipients = self.scriptConfig['emailRecipients']['error']
                    with open(self.repoDirectory/'common'/'emailTemplates'/('emailbody_alertsIssue.html')) as template:
                        bodyInsert = template.read().format(
                                         self.scriptConfig['scriptTitle'],
                                         timestamp,
                                         self.statData['errorCnt'],
                                         self.statData['resolvedErrors'],
                                         self.statData['warningCnt'],
                                         self.statData['resolvedWarnings'],
                                         str(self.logFileName))
                # list values that need to be inserted into body
                self.alertsEmail(
                    body=bodyInsert, 
                    color=self.config['statusColors'][self.emailStatus],
                    recipients=recipients,
                    attachment=self.logFileName)
        else: 
            self.log(text='Notifications disabled - no email generated.')

    

if __name__ == '__main__': # main method
    print('Running...')
    # perform unit test
    try:
        A = alertsSession(Path(__file__).stem, taskName='test') # remove ".py" from script name
        if A.weekMaintWindow():
            A.log(text='Currently within weekly maintenance window!')
        else:
            A.log(text='Not currently within weekly maintenance window!')
        print('Script execution complete')
        A.log(doPrint=True)
    except Exception as e:
        A.error(e)