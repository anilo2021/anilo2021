####################################################################################################
# Name:                 mdmservicesmonitor.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/mdmservicesmonitor.vsdx
# Command line usage:   python start.py mdmservicesmonitor
# Purpose:              Evaluates status for MDM-relevant services and endpoints; sends eMail alerts when issues are detected/resolved.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2020-06-22 J. Rominske (jesr114@kellyservices.com)       Initial version
####################################################################################################

# library imports
import datetime
from influxdb import InfluxDBClient
import json
from pathlib import Path
import sys
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

# local module imports
from alerts.alertssession import alertsSession

# main script logic
def mdmServicesMonitor(session):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        session.log(text='Script run disabled in config file')
        return False
    # disable if during maintenance window
    if not session.weekMaintWindow():
        # start counters
        session.statData = {
            'errorCnt': 0,
            'warningCnt': 0,
            'urlErrors': [],
            'processErrors': []
        }
        # iterate through list of servers for the environment and report ping results
        session.log(text='Testing servers...')
        serverList = session.scriptConfig['mdmServers']
        for entry in serverList:
            session.log(text='\nPinging '+entry+'...')
            conflictInd = session.pingServer(entry)
            if conflictInd == 0:
                session.log(text='SUCCESS: '+entry+' pinged')
            else:
                session.log(text='ERROR: '+entry+' ping failed')
                session.statData['errorCnt'] += 1
                session.statData['urlErrors'].append(entry)

        # iterate through list of MDM URLs for the environment and report results
        session.log(text='Testing URLs...')
        serverList = session.scriptConfig['mdmServiceUrls']
        for entry in serverList:
            session.log(text='\nPinging '+entry['name']+' server...')
            conflictInd = session.getUrl(entry['address'])
            if conflictInd == 0:
                session.log(text='SUCCESS: '+entry['name']+' status 200')
            else:
                session.log(text='ERROR: '+entry['name']+' status not 200')
                session.statData['errorCnt'] += 1
                session.statData['urlErrors'].append(entry['address'])
        
        # check the JBoss monitor log for errant statuses
        session.log(text='\nChecking custom JBoss status files...')
        # check all script paths specified in the config file
        for customLogPathString in session.scriptConfig['customLogPaths']:
            nodeName = customLogPathString.split('\\')[2]
            customLogPath = Path(customLogPathString)
            # check if file exists and raise alert if not
            if not customLogPath.exists():
                session.log(text='ERROR: Log file '+str(customLogPath)+' not found')
                session.statData['errorCnt'] += 1
                continue
            else:
                with open(customLogPath, 'r') as statusFile:
                    session.log(text='Status file '+str(customLogPath)+' loaded')
                    # load status file as list of lines
                    statusList = statusFile.readlines()
                    # check if file conatains more than the header and raise alert if not
                    if len(statusList) <= 2:
                        session.log(text='ERROR: Log file '+str(customLogPath)+' error - no statuses found')
                        session.statData['errorCnt'] += 1
                        continue
                    # raise alert if log is behind by more than 15 minutes
                    now = datetime.datetime.today()
                    customLogTime = datetime.datetime.strptime(statusList[0].split(' ')[0], '%Y%m%d_%H%M%S')
                    warningTime = session.scriptConfig['customLogTimeAllowance']['warning'] # number of minutes before warning
                    errorTime = session.scriptConfig['customLogTimeAllowance']['error'] # number of minutes before error
                    # check if error time elapsed
                    if now - datetime.timedelta(minutes=errorTime) >= customLogTime:
                        session.log(text='ERROR: Log last updated more than '+str(errorTime)+' minutes ago')
                        session.statData['errorCnt'] += 1
                    # check if warning time elapsed
                    elif now - datetime.timedelta(minutes=warningTime) >= customLogTime:
                        session.log(text='WARNING: Log last updated more than '+str(warningTime)+' minutes ago')
                        session.statData['warningCnt'] += 1
                    # parse each line of the log file (except the header) into a list
                    for i in range(len(statusList)):
                        # skip the first two lines
                        if i < 2: 
                            continue
                        # split by spaces, then remove nulls and newlines
                        statusList[i] = [j for j in statusList[i].split(' ') if j not in ('', '\n')]
                    # iterate through list of expected processes to check against statusList
                    for process in session.scriptConfig['expectedRunningProcesses']:
                        foundProcesses = [s[0] for s in statusList[2:]]
                        # report the status of the expected services as recorded by JBoss
                        if process in foundProcesses:
                            statusLine = statusList[foundProcesses.index(process)+2]
                            # if error, add to statusData
                            if statusLine[-1] != 'OK':
                                session.log(text='ERROR: '+nodeName+' - '+process+' status is '+statusLine[-1]+' - expected status is OK')
                                session.statData['errorCnt'] += 1
                                session.statData['processErrors'].append(nodeName+' - '+process+': '+statusLine[-1])
                            # if OK, report success
                            else:
                                session.log(text='SUCCESS: '+nodeName+' - '+process+' status: OK')
                        # if process not found in status, add to statusData
                        else:
                            session.log(text='ERROR: '+nodeName+' - '+process+' status is missing')
                            session.statData['errorCnt'] += 1
                            session.statData['processErrors'].append(nodeName+' - '+process+': MISSING')
        
        # insert results into Grafana database
        client = InfluxDBClient(host=session.alertsDbCreds['host'],
                                port=session.alertsDbCreds['port'], 
                                username=session.alertsDbCreds['username'],
                                password=session.alertsDbCreds['password'])
        session.log(text='Inserting results into Grafana DB '+session.alertsDbCreds['serverName']+'/'+session.alertsDbCreds['applicationName']+' at '+session.alertsDbCreds['host']+':'+str(session.alertsDbCreds['port'])+'...')
        try:
            client.write_points(session.alertsDbCreds['applicationName']
                                +",host="+session.alertsDbCreds['serverName']
                                +" maxNotRunningServicesNode1="+str(len([p for p in session.statData['processErrors'] if p.startswith('AMDCWMDMSQA02')]))
                                +",maxNotRunningServicesNode2="+str(len([p for p in session.statData['processErrors'] if p.startswith('AMDCWMDMSQA03')]))
                                +",maxNotRunningUrls="+str(len(session.statData['urlErrors'])),
                                protocol='line',database='telegraf')
            session.log(text='Gafana DB insert succeeded')
        # log error, but only increase warning count if axon fails
        except Exception as e:
            session.error(e, exit=False)
            session.log(text='WARNING: Grafana DB insert failed')
            session.statData['warningCnt'] += 1
        
        # run alert notification logic from session class and announce script success
        session.alertNotification()
        session.log(text='MDM monitoring script execution complete')


# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName='', args=['mdm'])
    try:
        if len(sys.argv) > 1 and sys.argv[1].startswith('-t'):
            sessionContainer['alerts'].alertNotification(test=True)
        else:
            mdmServicesMonitor(sessionContainer['alerts'])
        print('Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].alertsError(e, email=sessionContainer['alerts'].scriptConfig['errorNotification'])