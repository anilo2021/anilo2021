####################################################################################################
# Name:                 pwxchecklogs.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/pwxchecklogs.vsdx
# Command line usage:   python start.py pwxchecklogs
# Purpose:              Check PowerExchange logs for errors and inactivity
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-14 J. Harrington (harrijn@kellyservices.com)     Original Author
# 2018-10-01 C. Bravo (carb755@kellyservices.com)          Adapted for Python 3 and PWX AIM infra deployment + add alerts framework. 
# 2018-11-28 J. Rominske (jesr114@kellyservices.com)       Moved service data into JSON, cleaned up and reorganized file
####################################################################################################

# library imports
import datetime
import json
from pathlib import Path
import sys
import time

# local module imports
from alerts.alertssession import alertsSession
from fileoperation.fileoperationwrapper import fileOperationWrapper

# check log files
def checkFile(session, filePath, fileType, searchString, checkTime):
    session.log(text='\nChecking '+fileType+' log '+filePath)
    errorOut = 0
    warningOut = 0
    # scan file for relevant log entries
    with open(filePath, "r") as file:
        # instantiate log time check starting point
        lastLogTime = datetime.datetime.strptime('2011-08-13 19:06:53.058000',"%Y-%m-%d %H:%M:%S.%f")
        for line in file:
            if line[14:18] == 'WIN6':
                # extract log time string from current line
                logTimeString = '20'+str(line[0:2])+'-'+str(line[2:4])+'-'+str(line[4:6])+' '+str(line[7:9])+':'+str(line[9:11])+':'+str(line[11:13])+'.000000'
                logTime = datetime.datetime.strptime(logTimeString,"%Y-%m-%d %H:%M:%S.%f")
                # replace last log time if necessary
                if logTime > lastLogTime:
                    lastLogTime = logTime
                # if log within the last 20 minutes, check for error keywords and raise error flag if necessary
                if time.mktime(checkTime.timetuple()) - time.mktime(logTime.timetuple()) < 1200:
                    if any (x in line.lower() for x in searchString):
                        session.log(text=line)
                        errorOut = 1
        session.log(text='*** lastLogEntry= '+str(lastLogTime))
        # checks last log entry vs execution time and raise warning if 30 mins elapsed since last log entry            
        if time.mktime(checkTime.timetuple()) - time.mktime(lastLogTime.timetuple()) > 1800:
            session.log(text="\n Warning No Activity for 30 minutes in " + fileType + ", log file: " + filePath.replace("/","\\"))
            warningOut = 1
    return errorOut, warningOut
    
# scan iics tomcat files looking for error keywords and raises error flag   
def checkTomcat(session, filePath, fileType, searchString, checkTime):
    session.log(text='\nChecking '+fileType+' log '+filePath)
    errorOut = 0
    # scan file for relevant log entries
    with open(filePath, "r") as file:
        for line in file:
            if line[0:2] == '20':
                # extract log time string from current line
                logTimeString = str(line[0:19])+'.000000'
                logTime = datetime.datetime.strptime(logTimeString,"%Y-%m-%d %H:%M:%S.%f")
                # if log within the last 20 minutes, check for error keywords and raise error flag if necessary
                if time.mktime(checkTime.timetuple()) - time.mktime(logTime.timetuple()) < 1200:
                    if any (x in line.lower() for x in searchString):
                        session.log(text=line)
                        errorOut = 1
    return errorOut

# scan pwx cmd generated files looking for success keywords and raises error flag    
def checkUtil(session, filePath, searchString):
    session.log(text='\nChecking utility file '+filePath)
    errorOut = 1
    # scan file for relevant log entries
    with open(filePath, "r") as file:
        for line in file:
            if any (x in line.lower() for x in searchString):
                errorOut = 0
    return errorOut

# main log check logic
def pwxCheckLogs(session):
    errorCnt = 0
    warningCnt = 0
    checkTime = datetime.datetime.now()
    # check all services in pwxcheckparams dictionary
    services = json.load(open(session['alerts'].configDirectory/(session.env+'_pxcheckparams.json')))
    for service in services:
        filePath = session['fileops'].getLatestFile(service['directory'])
        # if Listener or Logger type, use generic file check
        if any(x in service['type'] for x in ['Listener', 'Logger']):
            # check service log
            errorOut, warningOut = checkFile(session['alerts'], filePath, service['type'], service['searchString'], checkTime)
            errorCnt += errorOut
            warningCnt += warningOut
        # if Tomcat, use Tomcat-specific check
        elif 'Tomcat' in service['type']:
            errorCnt += checkTomcat(session['alerts'], filePath, service['type'], service['searchString'], checkTime)
        # check errors and set flags
        if errorCnt > 0:
            utilError = checkUtil(session['alerts'], service['checkFile'], services['Util']['checkString'])
            # if utility is down, log record of it
            if utilError:
                session['alerts'].log(text=service['type']+' is Down, see log: \n'+service['checkFile'].replace("/","\\"))
    # deal with error vs warnings
    alertData = [errorCnt, warningCnt, '']
    session.alertNotification(alertData, 'PWX {} monitor | {} | {}')

# main thread
if __name__ == '__main__':
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName=sys.argv[1])
    sessionContainer['fileops'] = fileOperationWrapper('', '', logFileName=sessionContainer['alerts'].logFileName)
    try:
        if sys.argv[2].startswith('-t'):
            sessionContainer['alerts'].alertNotification([0, 'PWX'],'PWX {} monitor | Alert test confirmation | {}')
        else: 
            sessionContainer['alerts'].log(text='Checking PWX Logs Detail...\n')
            pwxCheckLogs(sessionContainer)
            sessionContainer['alerts'].log(text='\n Script execution complete.')  
        print('Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].error(e)