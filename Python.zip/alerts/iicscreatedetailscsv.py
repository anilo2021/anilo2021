####################################################################################################
# Name:                 iicscreatedetailscsv.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/iicscreatedetailscsv.vsdx
# Command line usage:   python start.py iicscreatedetailscsv
# Purpose:              Creates a CSV file with all the object details of the IICS org the user belongs to.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-09-16 C. Bravo (carb755@kellyservices.com)          Original Author
# 2018-11-09 J. Rominske (jesr114@kellyservices.com)       Combined getConnectionsCSV.py and getRunEnvironmentsCSV.py
#                                                          into iicscreatedetailscsv.py, cleaned up and reorganized file
####################################################################################################

# library imports
import datetime
import json
from pathlib import Path
import pandas
import sys

# local module imports
from alerts.alertssession import alertsSession
from iics.iicswrapper import iicsWrapper

#get a CSV file with all the connections data from the IICS org the user belongs to
def createDetailsCSV(session, objectType):
    # get org details
    session['alerts'].log(text='Retrieving org details...')
    orgJsonData = json.loads(session['iics'].getOrg('').text)
    orgName = orgJsonData[0]['name']+ ' '+ orgJsonData[0]['orgId']
    orgFname = orgName.replace(' ', '')
    session['alerts'].log(text='[success]... IICS Org = '+orgName)
    # get connection details
    session['alerts'].log(text='Retrieving connection(s) data...')
    if objectType == 'connection':
        response = session['iics'].getConnection('').json()
        objectTypeString = 'connections'
    elif objectType == 'environment':
        response = session['iics'].getRuntimeEnvironment('').json()
        objectTypeString = 'runtime environments'
    jsonFile = session['alerts'].scriptName+'.json'
    jsonFileName = session['alerts'].directory/'json'/jsonFile
    session['alerts'].createJsonFile(jsonFileName, response)
    # generate CSV file from JSON 
    session['alerts'].log(text='[success]... reading data from '+ str(len(response))+' '+objectTypeString+' within the IICS Org.')
    now = datetime.datetime.today()
    fileTimestamp = now.strftime('%Y-%m-%d_%H-%M-%S')
    csvFile = session['alerts'].scriptName+'_'+fileTimestamp+orgFname+'.csv'
    csvFileName = session['alerts'].directory/'files'/'csv'/csvFile
    #read in the json
    df = pandas.read_json(jsonFileName)
    # write the csv
    session['alerts'].log(text='Generating CSV file from JSON data...')
    df.to_csv(csvFileName)
    session['alerts'].log(text='Connections data written to CSV file '+csvFileName)

# main thread    
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName=sys.argv[1])
    sessionContainer['iics'] = iicsWrapper('', '', logFileName=sessionContainer['alerts'].logFileName)
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            sessionContainer['alerts'].log(text='IICS login Success')
            createDetailsCSV(sessionContainer, sys) 
            sessionContainer['iics'].logout()
            sessionContainer['alerts'].log(text='Script execution complete.')
            print('Script execution complete.')
            sessionContainer['alerts'].log(doPrint=True)
    except Exception as e:
        sessionContainer['alerts'].error(e)