####################################################################################################
# Name:                 cognosmonitor.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/cognosmonitor.vsdx
# Command line usage:   python start.py cognosmonitor
# Purpose:              Evaluates status for Cognos application components and endpoints; sends eMail alerts when issues are detected/resolved.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-09-16 C. Bravo (carb755@kellyservices.com)          Original Author
# 2018-11-06 J. Rominske (jesr114@kellyservices.com)       Renamed cognosMonitorPRD.py to cognosmonitor.py, cleaned up and reorganized file
####################################################################################################

# library imports
import json
from pathlib import Path
import sys

# local module imports
from alerts.alertssession import alertsSession
        
# function to monitor objects in IICS org (wrapper of session monitor function)
def cognosMonitor(session):
    session.log(text='Testing Cognos servers...')
    conflictCnt = 0
    with open(session.configDirectory/(session.env+'_cognos-servers.json'), 'r') as serverListFile:
        serverList = json.load(serverListFile)
        session.log(text='Loaded server list from file '+str(serverListFile))
        for serverName in serverList:
            conflictCnt += session.pingServer(session, serverName)
        alertData = [conflictCnt, 0, '', 'Cognos']
        session.alertNotification(alertData, 'Cognos {} monitor | {} | {}')

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName='')
    try:
        if sys.argv[2].startswith('-t'):
            sessionContainer['alerts'].alertNotification([0, 'Cognos'], 'Cognos {} monitor | Alert test confirmation | {}')
        else:
            cognosMonitor(sessionContainer['alerts'])
        print('Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].error(e)