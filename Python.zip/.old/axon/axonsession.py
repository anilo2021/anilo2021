####################################################################################################
# Name:                 iicssession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/7/iicssession
# Command line usage:   N/A
# Purpose:              Class contains methods for IICS API automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)      Original Author
####################################################################################################

# library imports
import requests
import json
from pathlib import Path
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to IICS Automation
class axonSession(session):
    # overloaded setup method
    def _setup(self):
        self.directory = self.repoDirectory/'axon'
        # load stored credentials from JSON file
        self.axonCreds = json.load(open(self.secureDirectory/(self.env+'_axoncreds.json')))
        self.req = requests.Session()
        self.basehdrs = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        self.refreshToken = ''
    
    # logs user in and adds an authenticated session id to header              
    def login(self):
        self.log(text='Authenticating with Axon using refresh token...')
        loginData = {'username': self.axonCreds['username'],
                     'password': self.axonCreds['password']}
        self.hdrs = self.basehdrs.copy()
        response = self.req.post(self.axonCreds['url']+'/api/login_check', headers=self.hdrs, json=loginData)
        if response.status_code == 200: 
            self.log(text='Login Success')
            self.hdrs['token'] = response.json()['token']
            self.refreshToken = response.json()['refresh_token']
            return True
        else:
            self.log(text='Login Failed')
            return False
    
    # logs user out to end session (best practice)
    def logout(self): 
        logoutData = {'username': self.axonCreds['username'],
                      'password': self.axonCreds['password']}
        response = self.req.post(self.axonCreds['url']+'/logout', headers=self.hdrs, json=logoutData)
        if response.status_code == 200: 
            self.log(text='\nSession ended')
        else:
            self.error(response.text)

    # method for sending emails specific to IICS
    def axonEmail(self, subject, body, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_secureagent.html') as template:
            self.email(subject=subject,
                       body=template.read().format(body), # replace "{}" in template file with values
                       attachment=attachment, recipients=recipients) # call basic email function

    # method for send error report email for IICS
    def axonError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.axonEmail('Notification from DA&I Axon Automation System',
                        'An error occurred with code: '+str(errorCode)+'<br>Please check the logs.')
        sys.exit(errorCode)

    # generic API Resource method (private)
    def _doAPI(self, reqType, uri, postObject=None, fullUpdate=True, data=None):
        # validate session ID
        self.log(text='Refreshing session...')
        tokenData = {'refresh_token': self.refreshToken}
        axonToken = self.req.post(self.axonCreds['url']+'/api/v1/token/refresh', headers=self.hdrs, json=tokenData).json()
        self.hdrs['token'] = axonToken['token']
        self.refreshToken = axonToken['refresh_token']
        # prepare to access API resource
        url = self.axonCreds['url']+uri
        self.log(text='Accessing API resource at '+url)
        # switch method use based on request type
        # simply get if method is GET
        if reqType == 'GET':
            return self.req.get(url, headers=self.hdrs)
        # just do normal request call on POST
        if reqType == 'POST':
            return self.req.post(url, headers=self.hdrs, json=postObject)
        # extra logic for handling headers for UPDATE modes
        elif reqType == 'UPDATE':
            # copy normal header and add update mode flag
            updateHeaders = self.hdrs.copy()
            updateHeaders['Update-Mode'] = 'FULL' if fullUpdate else 'PARTIAL'
            # call API resource
            return self.req.post(url, headers=updateHeaders, json=postObject)
        # simply delete if method is DELETE
        elif reqType == 'DELETE':
            return self.req.delete(url, headers=self.hdrs)
        
# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    try:
        A = axonSession(Path(__file__).stem, 'test') # remove ".py" from script name
        if not A.login():
            print('Login error - aborted')
        else:
            A.logout()
            print('Script execution complete')
    except Exception as e:
        A.axonError(e, email=False)