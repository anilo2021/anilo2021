#!/usr/bin/env python

# Script Name:  extrLoad.py  
# Date Written: 04/02/15
# Description:  This script extracts data from PeopleSoft and loads
#     it into the Teradata staging area.

# Modification Log:

# Date   Name           Comments 
# -------- ------------ -----------------------------------------------  
# 04/02/15 B. Hull      Original.
# 10/01/15 B. Hull      Modified to make sure the job is not already 
#                       running before starting. CR-080674.

import os,sys
import subprocess
import shlex
import time
import datetime
import glob
from optparse import OptionParser
import pyodbc 
import smtplib
from email.mime.text import MIMEText
import replMod


def extrLoad(options):

    # Get the environment setup variables
    env = replMod.Env()
    
    # Get current time object
    ct = replMod.CurrTime()    
    
    # Format the file name for the output file
    outFileName = env.kdwHome + "/logs/" + options.jobName.lower() + "_" + ct.logTime + ".log"

    sys.stdout = open(outFileName, 'a')
    sys.stderr = open(outFileName, 'a')

    # Check to see if the job is already running
    # The "reverse = True" gets the files in descending order (based on the key of modification date/time)
    for fileName in sorted(glob.glob(env.kdwHome + "/logs/" + options.jobName.lower() + "_*.log"), 
            key = os.path.getmtime, reverse = True):
        # If the file was created by this process, skip over it
        if fileName.split("\\")[-1] == options.jobName.lower() + "_" + ct.logTime + ".log":
            continue
        # The time delta is in days, seconds, microseconds, so 300 seconds is 5 minutes
        if datetime.datetime.now() - datetime.datetime.fromtimestamp(os.path.getmtime(fileName)) < \
                datetime.timedelta(0, 300, 0):
            replMod.printMsg(options.jobName + " could not start because it detected another " + \
                options.jobName + " job writing to log file " + fileName + " in the last 5 minutes.")
            replMod.printMsg("If this is a restart, wait 5 minutes before restarting the job.")
            raise SystemExit(12)
        else:
            # Since the rows are in descending order based on modification date/time, we can break
            # out of this loop as soon as the first file is not within 5 minutes.
            break
                    
    # Connect to the database and create the cursor
    pyodbc.pooling = False
    
    # Connect to the database and create the cursor
    connStr = "DRIVER={Teradata};DBCNAME=" + env.tdp + ";UID=" + env.dbPrefix + "ETL;PWD=$tdwallet(" + env.dbPrefix + "ETL_PWD);"
    conn = pyodbc.connect(connStr, ANSI=True, autocommit=True)
    cursor = conn.cursor()
    
    procIdList = []
    jobInfoList = []
    lastTime = str(datetime.datetime.now())[11:16]
    
    # Update the RUNFLAG to 1 and any table in RUNNING status back to ACTIVE for this job name.
    replMod.printMsg("Setting RUNFLAG to 1 and tables in 'RUNNING' status to 'ACTIVE'.")
    sqlStmt = """
        UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.CDC_RUNSTATUS
          SET RUNFLAG = 1
          WHERE JOBNAME = '""" + options.jobName + """';
        UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
          SET STATUS = 'ACTIVE'
          WHERE JOB_NAME = '""" + options.jobName + """'
            AND STATUS = 'RUNNING';"""
    cursor.execute(sqlStmt)
    
    # Set up a continuous loop until the job the RUNFLAG = 0 or the STOPTIME has been hit
    while True:
    
        sqlStmt = """
            SELECT RUNFLAG
                  ,COALESCE(RUNTYPE,'')
                  ,CAST(STOPTIME AS CHAR(5))
                  ,COALESCE(CYCLETIME, 1)
              FROM """ + env.dbPrefix + """_TBLS_EVNT_STATS.CDC_RUNSTATUS 
              WHERE JOBNAME = '""" + options.jobName + """';"""
        rowCount = cursor.execute(sqlStmt).rowcount
        
        # We need to have a row in CDC_RUNSTATUS for the job name or else we can't go on.
        if rowCount == 0:
            replMod.printMsg("No row found for job name '" + options.jobName + "' in CDC_RUNSTATS. Terminating script.")
            raise SystemExit(12)
            
        runFlag, runType, stopTime, cycleTime = cursor.fetchone()
        # If the RUNFLAG has been changed to zero, exit the loop.
        if runFlag == 0:
            replMod.printMsg("RUNFLAG has been set to 0. Terminating script gracefully.")
            break
        
        # Get all tables associated with this job that have a status of ACTIVE and are either one-time 
        # jobs (runType = '1') or where the last update timestamp was more than the cycle time ago.
        replMod.printMsg("Selecting tables to update.")
        sqlStmt = """
            SELECT DB_NAME
                ,TBL_NAME
                ,COALESCE(AUD_DB_NAME, '')
                ,COALESCE(AUD_TBL_NAME, '')
                ,UPD_MODE
                ,COALESCE(EXCL_LOCK, 'N')
                ,COALESCE(TBL_KEY, '')
                ,COALESCE(COLUMN_LITERALS, '')
                ,COALESCE(LOGGING_INTERVAL_MIN, 1)
                ,PACK_FACTOR
                ,COLUMN_LITERAL_DELIMITER
                ,COALESCE(PURGE_MODE, '')
                ,COALESCE(PURGE_SET, '')
                ,COALESCE(PURGE_WHERE, '')
                ,COALESCE(WHERE_CLAUSE, '')
                ,COALESCE(REFRESH_IND, '')
                ,COALESCE(QUERY_BAND, '')
            FROM """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
            WHERE JOB_NAME = '""" + options.jobName + """'
              AND STATUS = 'ACTIVE'
              AND ('""" + runType + """' = '1'
               OR  LAST_UPD_TMSTMP + CAST(CYCLE_TM_MIN AS INTERVAL MINUTE) < CURRENT_TIMESTAMP)
            ORDER BY 1,2;
            """
        rows = cursor.execute(sqlStmt).fetchall()
        
        if len(rows) == 0:
            replMod.printMsg("No tables selected.")
        else:
            # Update all of the rows that we're going to kick off to a 'RUNNING' status.
            updateList = [("(DB_NAME = '" + row[0] + "' AND TBL_NAME = '" + row[1] + "')") for row in rows]
            sqlStmt = """
                UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
                SET STATUS = 'RUNNING'
                WHERE JOB_NAME = '""" + options.jobName + """'
                    AND (""" + "\nOR ".join(updateList) + """);"""
            cursor.execute(sqlStmt)
        
        for row in rows:
            dbName, tblName, audDbName, audTblName, updMode, exclLock, \
                tblKey, columnLiterals, loggingIntervalMin, packFactor, columnLiteralDelimiter, \
                purgeMode, purgeSet, purgeWhere, whereClause, refreshInd, queryBand = row 
            
            # Format the execution string based on the values in APPLY_REPL_TABLE for this table.
            tblKeyClause = '-k "' + tblKey + '"'
            
            if whereClause > "":
                whereClause = '-w "' + whereClause + '"'
            else:
                whereClause = ""
                
            if purgeMode.upper() == "Y":
                purgeModeClause = "-u"
            else:
                purgeModeClause = ""
                
            if purgeSet > "":
                purgeSetClause = '-s "' + purgeSet + '"'
            else:
                purgeSetClause = ""
                
            if purgeWhere > "":
                purgeWhereClause = '-g "' + purgeWhere + '"'
            else:
                purgeWhereClause = ""

            if columnLiteralDelimiter > "":
                columnDelimiterClause = "-d " + columnLiteralDelimiter
            else:
                columnDelimiterClause = ""
                
            if columnLiterals > "":
                columnLiteralsClause = '-c "' + columnLiterals + '"'
            else:
                columnLiteralsClause = ""
            
            audTblClause = "-a " + audDbName + "." + audTblName
                
            if exclLock.upper() == "Y":
                exclLockClause = "-e"
            else:
                exclLockClause = ""

            if refreshInd.upper() == "Y":
                refreshClause = " -r"
            else:
                refreshClause = ""
                
            if loggingIntervalMin > 1:
                loggingIntervalClause = '-l "' + str(loggingIntervalMin) + '"'
            else:
                loggingIntervalClause = ""
               
            if packFactor == None:
                packFactorClause = ""
            else:
                packFactorClause = "-p " + str(packFactor)
                
            if queryBand > "":
                queryBandClause = " -q " + queryBand
            else:
                queryBandClause = ""                
                
            # Create the execnStrng
            execnStrng = "python " + env.kdwHome.replace("\\","/") + "/scripts/applyRepl.py -t " + '"' + \
                dbName + "." + tblName + '" -j "' + options.jobName + '" -m ' + updMode + " " +  \
                audTblClause + " " + tblKeyClause + " " + columnLiteralsClause + " " + \
                exclLockClause + " " + loggingIntervalClause + " " + packFactorClause + " " + columnDelimiterClause + \
                " " + purgeModeClause + " " + purgeSetClause + " " + purgeWhereClause + " " + whereClause + \
                refreshClause + queryBandClause
            
            # This use the shlex module to split the execution string into a list of arguments that will be passed
            # to the subprocess.Popen call. This is how it needs to be set up to work.
            args = shlex.split(execnStrng)
            # Sleep for one second between submitting jobs so that we don't use all the resources at once.
            time.sleep(1)    
            # This kicks the job off and appends the process ID to the procIdList, which we'll use to monitor
            # the process.
            procIdList.append(subprocess.Popen(args, close_fds=True))
            # We also add the database name and table name to a list so that we know which database name and table
            # name goes with each process.
            jobInfoList.append(dbName + "." + tblName)
            
            replMod.printMsg("Submitted " + dbName + "." + tblName + ": " + execnStrng)
            
        # See if any processes have completed and indicate errors if they did not process successfully.
        updProcIdList(procIdList, jobInfoList, options.jobName, cursor, env)

        # If this is a one-time job, we can exit the loop at this point since we've kicked off all the jobs.
        if runType == "1":
            break
        elif runType == "C":
            # For continuous jobs, see if a STOPTIME was specified, and if so, monitor to see if we've passed it.
            if stopTime != None:
                currTime = str(datetime.datetime.now())[11:16]
                adjustCurrTime = False
                # If the lastTime is > currTime, it means we've gone over midnight so add 24 hours to currTime
                if lastTime > currTime:
                    adjustCurrTime = True
                    currTime = str(int(currTime[0:2]) + 24) + currTime[2:5]
                if currTime >= stopTime and lastTime < stopTime:
                    # If we've passed the STOPTIME, break out of the loop.
                    replMod.printMsg("Stop time has been passed. Terminating script gracefully.")
                    break
                else:
                    # Adjust the currTime back by subtracting 24 hours if we added 24 hours above.
                    if adjustCurrTime == True:
                        currTime = str(int(currTime[0:2]) - 24).zfill(2) + currTime[2:5]
                    lastTime = currTime
        else:
            replMod.printMsg("Invalid RUNTYPE found for job '" + options.jobName + "'. Must be C or 1.")
            raise SystemExit(12)  
            
        replMod.printMsg("Sleeping for " + str(cycleTime) + " minute(s) until next cycle.")
        time.sleep(int(cycleTime) * 60)
    
    # Set the RUNFLAG on the CDC_RUNSTATUS to 0 so that the child processes that we've kicked off can see
    # that we need to end. 
    if runFlag != 0:
        replMod.printMsg("Setting the RUNFLAG to 0 to end the process.")
        sqlStmt = """
            UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.CDC_RUNSTATUS
            SET RUNFLAG = 0
            WHERE JOBNAME = '""" + options.jobName + """';"""
        cursor.execute(sqlStmt)
    
    # This loop is to monitor the child processes until they have all completed.
    while True:
        replMod.printMsg("Checking to make sure all processes are complete.")
        
        # Update the procIdList to indicate which jobs have completed and put an error out for any child
        # jobs that failed.
        updProcIdList(procIdList, jobInfoList, options.jobName, cursor, env)
        
        # If the procIdList contains items, then we still have children processes.
        if len(procIdList) > 0:
            replMod.printMsg("The following tables are still processing:")
            # Print a message indicating which tables are still processing.
            for jobInfo in jobInfoList:
                replMod.printMsg("  " + jobInfo)
        else:
            break
        
        # Sleep for one minute in between checking to see if child processes are complete.
        time.sleep(60)

    # Now that all child processes are complete, we can set the RUNFLAG back to 1 and end this process.
    replMod.printMsg("Processes complete. Setting the RUNFLAG back to 1.")
    
    cursor.close()
    conn.close()
    
    replMod.printMsg("Process complete.")


def updProcIdList(procIdList, jobInfoList, jobName, cursor, env):

    # Get the number of process ID's in the list and set "x" to zero to start our loop.
    procIds = len(procIdList)
    x = 0
    
    # This loop goes through the process ID's and if they are no longer running, it deletes them from the procIdList
    # and from the jobInfoList.
    for _ in range(procIds):
        # This checks to see if the child job is done, and if so, the return code from it.
        # If the child job is still running, the retCd will be None.
        retCd = procIdList[x].poll()
        if retCd != None:
            # If we have a return code > 0 from the child process, update the status to FAILED on the APPLY_REPL_TABLE.
            if retCd > 0:
                replMod.printMsg("*** Error in applyRepl.py for " + jobInfoList[x] + ", sending email and updating APPLY_REPL_TABLE.")
                # Send an email indicating that there is an error
                emailFile = open(env.kdwHome + os.path.join("parms", "extrLoadEmail.prm"), "r")
                for line in emailFile:
                    execnStrng = "blat -to " + line[:-1] + ' -s "Error in applyRepl.py - ' + \
                        jobInfoList[x].split(".")[0] + "." + jobInfoList[x].split(".")[1] + \
                        '" -body "Error in applyRepl.py - ' + \
                        jobInfoList[x].split(".")[0] + "." + jobInfoList[x].split(".")[1] + '" -q'
                    args = shlex.split(execnStrng)
                    subprocess.Popen(args, close_fds=True)
                emailFile.close()
                # Update the APPLY_REPL_TABLE to set the status to 'FAILED'
                sqlStmt = """
                    UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
                      SET STATUS = 'FAILED'
                      WHERE JOB_NAME = '""" + jobName + """'
                        AND DB_NAME = '""" + jobInfoList[x].split(".")[0] + """'
                        AND TBL_NAME = '""" + jobInfoList[x].split(".")[1] + """';"""
                cursor.execute(sqlStmt)
            # Delete process ID's and tables from the lists if they are done.
            del procIdList[x]
            del jobInfoList[x]
            # We don't need to increment "x" in this case because deleting an item from the list will move all items in the 
            # list from that point on back one slot.
        else:
            # If the child process is still running, increment "x" to go to the next child process.
            x += 1
            

def main():

    usage = "usage: %prog [options]"
    version = "%prog 1.0.0"
    description = \
        "Extract and load the data from PeopleSoft."
    parser = OptionParser(usage=usage, version=version, description=description)

    parser.add_option("-j", "--jobName",
        action="store",
        default="",
        help="Specify the job name [default: %default]")   

    (options, args) = parser.parse_args()
    
    if len(args) == 0 and options.jobName > "":
        extrLoad(options)
    else:
        parser.print_help()
        raise SystemExit(12)
    

if __name__ == '__main__':
    main()
    
