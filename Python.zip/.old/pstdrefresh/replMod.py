#!/usr/bin/env python

# Script Name:  replMod.py 
# Date Written: 04/29/15 
# Description:  This script contains common classes and functions for replication.

# Modification Log:
    
# Date   Name         Comments 
# -------- ------------ -----------------------------------------------  
# 04/29/15 B. Hull      Original.
# 06/12/18 J. Rominske  Updated to Python 3 standard (print statement)

import os
import sys
import datetime


class CtlFile:

    def __init__(self, env, fileName):
    
        file = open(os.environ['KDW_HOME'] + "/ctl/" + fileName, "r")
        
        self.hostName = ""
        self.userName = ""
        self.password = ""
        
        for i, line in enumerate(file):
            if i == 0:
                self.hostName = line[0:-1]
            elif i == 1:
                self.userName = line[0:-1]
            elif i == 2:
                self.password = line[0:-1]
                
        file.close()

class CurrTime:

    def __init__(self):
    
        self.startTime = str(datetime.datetime.now())[0:19]
        self.logTime = self.startTime[0:4] + self.startTime[5:7] + self.startTime[8:10] + self.startTime[11:13] + \
            self.startTime[14:16] + self.startTime[17:19]
        

class Env:

    def __init__(self):
    
        self.tdp = os.environ['TDP']
        self.dbPrefix = os.environ['DB_PREFIX']
        self.kdwHome = os.environ['KDW_HOME']

            
def printMsg(msg):
    
    logTime = str(datetime.datetime.now())[0:19]
    
    logTimePrefix = logTime[0:4] + "-" + logTime[5:7] + "-" + logTime[8:10] + " " + logTime[11:13] + ":" + logTime[14:16] + \
        ":" + logTime[17:19] + ": "

    print(logTimePrefix + msg)
    sys.stdout.flush()
                
