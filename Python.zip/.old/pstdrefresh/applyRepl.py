#!/bin/env python

# Script Name:  applyRepl.py
# Date Written: 03/19/15
# Description:  This script processes the audit and refresh rows from Infosphere
#     for a table.   

# Usage example:
# python applyRepl.py -t dev_tbls_kdw_ps.PS_BUS_UNIT_TBL_HR_PY ^
#     -a dev_tbls_stg_ksn.PS_BUS_UNIT_TBL_HR_PY_A ^
#     -e -c "SOURCEID = 2, TRANSCODE = 'I', TRANSDATE = CURRENT_TIMESTAMP(0)" ^
#     -k "SOURCEID,BUSINESS_UNIT" 

# Modification Log:

# Date     Name           Comments 
# -------- ------------ -----------------------------------------------  
# 03/19/15 B. Hull      Original.
# 08/03/16 B. Hull      Modified to find row for each key with the maximum
#                       line number and no longer use the insert timestamp
#                       since it is unreliable and is not needed anyway.
# 06/12/18 J. Rominske  Updated to Python 3 standard (lines 553, 554)

import os
import sys
from optparse import OptionParser
import pyodbc
import ceODBC # TODO: Resolve import issue with this module
import datetime
import time
import replMod
import glob
import subprocess

def applyRepl(options):
    
    # Get the environment variables 
    env = replMod.Env()
    
    # Get current time object
    ct = replMod.CurrTime()

    # Determine the output file name
    if options.jobName > "":
        outFileName = env.kdwHome + "/logs/repl/" + options.jobName.lower() + "_" + options.targetTbl.split(".")[1].lower() + \
            "_" + ct.logTime + ".log"
    else:
        outFileName = env.kdwHome + "/logs/repl/" + options.targetTbl.split(".")[1].lower() + \
            "_" + ct.logTime + ".log"

    # Open the output file and point the std out and std err to it.
    sys.stdout = open(outFileName, 'a')
    sys.stderr = open(outFileName, 'a')

    # This needs to be set to False in Linux
    pyodbc.pooling = False
    
    # Connect to the database and create the cursor
    connStr = "DRIVER={Teradata};DBCNAME=" + env.tdp + ";UID=" + env.dbPrefix + "ETL;PWD=$tdwallet(" + env.dbPrefix + "ETL_PWD);"
    connType = "pyodbc"
    conn = connect(connType, connStr)
    cursor = conn.cursor()
    
    # Set the query_band for pyodbc
    cursor.execute("SET QUERY_BAND = 'JOBNAME=" + options.targetTbl.split(".")[1].upper() + ";' UPDATE FOR SESSION;")
    
    # Format and print informational messages to the log file
    modeClause = "batch"
    packFactorClause = ""

    replMod.printMsg("Processing " + options.targetTbl + " using " + modeClause + " mode.")
    replMod.printMsg("Using key of '" + options.keyColumns + "'" + packFactorClause + ".")
    
    if options.purgeMode:
        replMod.printMsg("Running in purge mode - rows will be logically deleted using " + options.purgeSet)
        
    if options.where > "":
        replMod.printMsg("Using a filter of " + options.where)
    
    if options.mode.upper() == "B" and options.exclusiveLock:
        replMod.printMsg("Exclusive locking will be used on updates to the target table.")
        
    # Get the hard-coded variables into an object
    hc = HardCode(options)

    # Get the table info variables into an object
    tbl = TableInfo(hc, env, options, conn, cursor)
    
    # Load the audit table from the flat files
    fileExists = loadStageTbl(env, tbl, options, conn, cursor)

    # Check to see if a refresh needs to be applied and apply it
    if options.refreshInd and fileExists:
        refreshInserts, refreshTs = applyRefresh(tbl, hc, env, options, conn, cursor)
    else:
        refreshInserts, refreshTs = "NULL", "NULL"
    
    # Get the maximum DM_INSERT_TIMESTAMP from the audit table
    dmInsertTimestamp = getMaxTs(conn, cursor, env, options)
    
    # If we didn't get a row back, indicate that we have no rows to process
    if dmInsertTimestamp == None:
        replMod.printMsg("No transactions to process.")
        inserts, updates, deletes = 0, 0, 0
    else:
        inserts, updates, deletes = applyBatch(tbl, hc, env, options, conn, cursor, dmInsertTimestamp)
        # Delete the audit rows
        sqlStmt = """
            DELETE FROM """ + options.auditTbl + """;"""
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)                
        
    # Record the end time of the script
    endTime = str(datetime.datetime.now())[0:19]

    # Insert into the APPLY_REPL_LOG table
    sqlStmt = """
        INSERT INTO """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_LOG
          (TABLE_NAME, START_TIME, END_TIME, EXEC_MODE, KEY_COLUMNS, REFRESH_INSERTS, REFRESH_TIMESTAMP,
           INSERTS, UPDATES, DELETES)
        VALUES
          ('""" + options.targetTbl.split(".")[1].strip().upper() + """'
          ,'""" + ct.startTime + """'
          ,'""" + endTime + """'
          ,'""" + options.mode.upper() + """'
          ,'""" + options.keyColumns.upper() + """'
          ,""" + str(refreshInserts) + """
          ,""" + refreshTs + """
          ,""" + str(inserts) + """
          ,""" + str(updates) + """
          ,""" + str(deletes) + """);"""
    rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
    
    if options.jobName > "":
        # Update the control table to indicate that we are done
        sqlStmt = """
            UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
            SET STATUS = 'ACTIVE'
               ,LAST_UPD_TMSTMP = CURRENT_TIMESTAMP(0)
            WHERE JOB_NAME = ?
              AND DB_NAME = ?
              AND TBL_NAME = ?;"""
        parms = (options.jobName, options.targetTbl.split(".")[0], options.targetTbl.split(".")[1])
        rowCount = execSql(conn, cursor, env, sqlStmt, parms, options)
        
        if rowCount == 0:
            replMod.printMsg(env.dbPrefix + "_TBLS_EVNT_STATS.APPLY_REPL_TABLE was not updated because no row was found") 
            replMod.printMsg("for " + options.jobName)
    
    cursor.close()
    conn.close()
        
    replMod.printMsg("Process complete.")
    
    # If we didn't do anything, remove the output log
    if inserts == 0 and updates == 0 and deletes == 0 and refreshTs == "NULL":
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        os.remove(outFileName)
    else:
        # Combine the file for this run with a file for the day 
        with open(outFileName, "r") as oldOutFile, open(outFileName[:-10] + ".log", "a") as outFile:
            contents = oldOutFile.read()
            execTime = ct.logTime[0:4] + "-" + ct.logTime[4:6] + "-" + ct.logTime[6:8] + " " + \
                ct.logTime[8:10] + ":" + ct.logTime[10:12] + ":" + ct.logTime[12:14]
            outFile.write("********** Execution timestamp: " + execTime + " **********\n")
            outFile.write(contents)
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__            
        os.remove(outFileName)        


# This class allows us to create a "HardCode" object that will hold all of the variables related to hard-coding, so
# that we can just pass the object to the various routines.
class HardCode:

    def __init__(self, options):

        self.hardCodeCol = ""
        self.hardCodeVal = ""  
        self.hardCodeColList = []
        self.hardCodeValList = []  
        
        if options.hardCoding > "":
            hardCodeList = options.hardCoding.split(options.delimiter)
            for hardCodePair in hardCodeList:
                self.hardCodeColList.append('"' + hardCodePair[:hardCodePair.index("=")].strip() + '"')
                self.hardCodeValList.append(hardCodePair[hardCodePair.index("=") + 1:].strip())
            self.hardCodeCol = "\n," + "\n,".join(self.hardCodeColList)
            self.hardCodeVal = "\n," + "\n,".join(self.hardCodeValList)
            
        
# This class allows us to create a "TableInfo" object that holds all variables and lists related to the table, so 
# that we can just pass the object to the various routines.
class TableInfo:
    
    def __init__(self, hc, env, options, conn, cursor):

        self.columnList = []         # List of columns (all columns)
        self.columnListIncHc = []    # List of columns including the hard-coded columns
        self.selectColumnList = []   # List of columns to be used in SELECT when in transaction mode (all columns)
                                       # - needed for TIMESTAMP and DECIMAL columns
        self.nullList = []           # List of null indicators (all columns)
        self.piList = []             # List of primary index columns
        self.keyWhereList = []       # List of where clauses for the key columns
        self.updateSetList = []      # List of set clauses for the batch update statement
        self.keyColumnListNoHc = []  # List of key columns not including hard-coded columns
        self.keyList = []            # List of key column clauses for transactional statements
        self.setList = []            # List of non-key column clauses for transactional statements
        self.insertSetList = []      # List of all columns set clauses for transactional statements
        self.columnDefaultList = []  # List of default values for the columns
        self.tptColumnList = []
        self.tptInsertList = []       
        self.keyColumnList = ('"' + options.keyColumns.replace(" ","").replace(",",'","') + '"').split(",") # List of key columns
        
        auditDbName, auditTblName = options.auditTbl.replace(" ","").split(".")
        targetDbName, targetTblName = options.targetTbl.replace(" ","").split(".")
        
        sqlStmt = """
            SELECT '"' || TRIM(UPPER(A.ColumnName)) || '"'
                ,COALESCE(A.Nullable, 'Y') AS Nullable
                ,CASE WHEN B.ColumnName IS NOT NULL THEN 'Y' ELSE 'N' END AS piInd
                ,TRIM(A.ColumnType)
                ,A.ColumnLength
              FROM DBC.ColumnsV A
                  LEFT OUTER JOIN DBC.IndicesV B
                      ON B.DatabaseName = A.DatabaseName
                      AND B.TableName = A.TableName
                      AND B.ColumnName = A.ColumnName
                      AND B.IndexType IN ('P','Q','K') /* Non-partitioned PI, Partition PI, and PK */
              WHERE A.DatabaseName = ?
                AND A.TableName = ?
                AND A.ColumnName NOT IN ('DM_INSERT_TIMESTAMP','DM_OPERATION_TYPE','DM_TXID','DM_LINE_NUMBER')
                AND A.ColumnName IN 
                    (SELECT ColumnName
                       FROM DBC.ColumnsV
                       WHERE DatabaseName = ?
                         AND TableName = ?)
              ORDER BY A.ColumnId;"""
        parms = (auditDbName, auditTblName, targetDbName, targetTblName) 
        _ = execSql(conn, cursor, env, sqlStmt, parms, options)
        
        rows = cursor.fetchall()
        
        for row in rows:
            column, nullable, piInd, columnType, columnLength = row
            self.columnList.append(column)
            self.columnListIncHc.append(column)
            self.nullList.append(nullable)
            if piInd == "Y":                     
                self.piList.append(column)
            if columnType == "TS":
                selectColumn = "CAST(B." + column + " AS VARCHAR(26))"
            elif columnType == "D":
                selectColumn = "TRIM(B." + column + ")"                
            else:
                selectColumn = "B." + column
            self.selectColumnList.append(selectColumn)                

            # Create the column WHERE criteria for the key columns and the SET clauses for the non-key columns
            self.insertSetList.append(column + "=?")
            if column in self.keyColumnList:
                self.keyList.append(column + "=?")
                self.keyWhereList.append("A." + column + " = B." + column)
                self.keyColumnListNoHc.append(column)
            else:
                self.setList.append(column + "=?")
                self.updateSetList.append(column + " = B." + column)
            
            # Set up the loadList values
            if columnType in ("CV","CF"):
                self.tptColumnList.append(".FIELD " + column + " * VARCHAR(" + str(columnLength) + ");")
                self.tptInsertList.append(column + " = OREPLACE(:" + column + ",x'1E',x'0A')")
            else:
                self.tptColumnList.append(".FIELD " + column + " * VARCHAR(30);")
                self.tptInsertList.append(column + " = :" + column)
                
            # Set up the default values for the columns for the audit log rows
            if columnType in ("CV","CF"):
                self.columnDefaultList.append(column + "=''")
            elif columnType == "DA":
                self.columnDefaultList.append(column + "=DATE '0001-01-01'")
            elif columnType == "TS":
                self.columnDefaultList.append(column + "=TIMESTAMP '0001-01-01 00:00:00'")
            else:
                self.columnDefaultList.append(column + "=0")                      

        # Add the hard-coded columns to the appropriate lists
        for column in hc.hardCodeColList:
            if column in self.keyColumnList:
                self.keyWhereList.append("A." + column + " = " + hc.hardCodeValList[hc.hardCodeColList.index(column)])
                self.keyList.append(column + "=" + hc.hardCodeValList[hc.hardCodeColList.index(column)])
                self.insertSetList.append(column + "=" + hc.hardCodeValList[hc.hardCodeColList.index(column)])
            else:
                # If there is an @ALIAS, we need to add the hard-coding to the SELECT statement
                if options.mode.upper() == "T" and "@ALIAS" in hc.hardCodeValList[hc.hardCodeColList.index(column)]:
                    self.selectColumnList.append(hc.hardCodeValList[hc.hardCodeColList.index(column)].replace("@ALIAS.","B.")) 
                    self.setList.append(column + "=?")
                    self.insertSetList.append(column + "=?")
                    self.columnListIncHc.append(column)
                else:
                    self.setList.append(column + "=" + hc.hardCodeValList[hc.hardCodeColList.index(column)])
                    self.insertSetList.append(column + "=" + hc.hardCodeValList[hc.hardCodeColList.index(column)])
                # For the batch update, simply replace the "@ALIAS." with "B."
                self.updateSetList.append(column + "=" + hc.hardCodeValList[hc.hardCodeColList.index(column)].replace("@ALIAS.","B."))
            
            
def applyBatch(tbl, hc, env, options, conn, cursor, dmInsertTimestamp):

    replMod.printMsg("Selecting the maximum row for each key from the audit table.")
    
    if options.where > "":
        whereClause = "  AND " + options.where
    else:
        whereClause = ""
        
    # Create a volatile table containing the max row (based on DM_INSERT_TIMESTAMP and DM_LINE_NUMBER) per key columns.
    # Note that this logic assumes that the primary index will be the same as or a subset of the key columns.
    sqlStmt = """
        LOCKING """ + options.auditTbl + """ FOR ACCESS
        CREATE VOLATILE TABLE MAX_ROW_PER_KEY AS 
          (SELECT B.""" + "\n,B.".join(tbl.columnList) + """
                 ,CASE WHEN B.DM_OPERATION_TYPE IN ('B','D') THEN 'D'
                       ELSE CASE WHEN A.""" +  tbl.keyColumnListNoHc[0] + """ IS NOT NULL THEN 'U'
                                 ELSE 'I'
                            END
                  END AS DM_OPERATION_TYPE
             FROM """ + options.auditTbl + """ B 
             LEFT OUTER JOIN """ + options.targetTbl + """ A
               ON """ + "\nAND ".join(tbl.keyWhereList) + """
             WHERE B.DM_OPERATION_TYPE IN ('B','D','I','A')
             """ + whereClause + """
             QUALIFY ROW_NUMBER() OVER (PARTITION BY B.""" + ",B.".join(tbl.keyColumnListNoHc) + """
                                        ORDER BY B.DM_LINE_NUMBER DESC) = 1) 
          WITH DATA
          PRIMARY INDEX(""" + ",".join(tbl.piList) + """)
          ON COMMIT PRESERVE ROWS;"""
    _ = execSql(conn, cursor, env, sqlStmt, tuple(), options)

    replMod.printMsg("Applying updates to the target table.")

    # If the exclusive option was used, lock the target table with an exclusive lock while we're updating it.
    if options.exclusiveLock:
        exclusiveClause = "LOCKING " + options.targetTbl + " FOR EXCLUSIVE"
        cursor.execute("BEGIN TRANSACTION;")
    else:
        exclusiveClause = ""

    # If an purgeMode was specified, do an update instead of a physical delete.
    # We need to lock the audit table for WRITE so that we can delete the rows later.
    if options.purgeMode:
        # Do an update rather than a physical delete
        sqlStmt = exclusiveClause + """
            UPDATE A
            FROM """ + options.targetTbl + """ A 
                ,MAX_ROW_PER_KEY B
            SET """ + options.purgeSet + """
            WHERE """ + "\nAND ".join(tbl.keyWhereList) + """
                AND B.DM_OPERATION_TYPE IN ('B','D');"""
    else:
        # Delete any rows with keys that exists in the MAX_ROW_PER_KEY table and are a "B" or "D" operation type.
        sqlStmt = exclusiveClause + """
            DELETE FROM """ + options.targetTbl + """ A
            WHERE EXISTS 
                (SELECT 1
                    FROM MAX_ROW_PER_KEY B
                    WHERE """ + "\nAND ".join(tbl.keyWhereList) + """
                        AND B.DM_OPERATION_TYPE IN ('B','D'));"""
    deletes = cursor.execute(sqlStmt).rowcount
    
    # Update any rows where the key exists on both the target and the MAX_ROW_PER_KEY table as an "I" or "A" operation type.
    sqlStmt = """
        UPDATE A
          FROM """ + options.targetTbl + """ A 
              ,MAX_ROW_PER_KEY B
          SET """ + "\n,".join(tbl.updateSetList) + """
          WHERE """ + "\nAND ".join(tbl.keyWhereList) + """
            AND B.DM_OPERATION_TYPE = 'U';"""
    updates = cursor.execute(sqlStmt).rowcount

    # Insert any rows where the key does not exists on the target table and it's an "I" or "A" operation type.
    sqlStmt = """
        INSERT INTO """ + options.targetTbl + """
          (""" + ",".join(tbl.columnList) + hc.hardCodeCol + """)
        SELECT """ + ",".join(tbl.columnList) + hc.hardCodeVal.replace("@ALIAS.","")+ """
          FROM MAX_ROW_PER_KEY B
          WHERE DM_OPERATION_TYPE = 'I';"""
    inserts = cursor.execute(sqlStmt).rowcount

    if options.exclusiveLock:
        cursor.execute("END TRANSACTION;")
    
    replMod.printMsg("Final Totals:")
    
    if options.purgeMode:
        purgeClause = "  Logical Deletes: "
    else:
        purgeClause = "  Deletes: "
        
    replMod.printMsg("  Inserts: " + str(inserts) + "  Updates: " + str(updates) + purgeClause + str(deletes))

    return inserts, updates, deletes

    
def applyRefresh(tbl, hc, env, options, conn, cursor):

    replMod.printMsg("Target table is being refreshed.")

    sqlStmt = """
        SELECT CAST(CURRENT_TIMESTAMP(0) AS VARCHAR(19));"""
    rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
    
    refreshTs = cursor.fetchone()[0]
    
    # Let's check to make sure that we have all "I" transactions on the staging table at this point
    sqlStmt = """
        SELECT COUNT(*)
          FROM """ + options.auditTbl + """
          WHERE DM_OPERATION_TYPE <> 'I';"""
    rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)   
    
    count = cursor.fetchone()[0]
    
    # We should only have 'I' rows on the staging table. If we have anything else, stop the process.
    if count > 0:
        replMod.printMsg("Staging table contains rows with a DM_OPERATION_TYPE other than 'I'.")
        replMod.printMsg("Stopping the process.")
        raise SystemExit(12)
    
    if options.purgeWhere > "":
        # Create a volatile table of the rows that have been logically deleted
        sqlStmt = """
            CREATE VOLATILE TABLE PURGED_ROWS AS 
            (SELECT *
               FROM """ + options.targetTbl + """)
            WITH NO DATA
            PRIMARY INDEX(""" + ",".join(tbl.piList) + """)
            ON COMMIT PRESERVE ROWS;"""
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
    
    purgedRows = False
    
    if options.purgeWhere > "":
        # Create a volatile table of the rows that have been logically deleted
        sqlStmt = """
            INSERT INTO PURGED_ROWS 
            SELECT *
              FROM """ + options.targetTbl + """
              WHERE """ + options.purgeWhere + """;"""
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
        if rowCount > 0:
            replMod.printMsg(str(rowCount) + " logical deletes were saved before refresh.")
            purgedRows = True
            # Lock the table before we do the refresh
            sqlStmt = "BEGIN TRANSACTION;"
            rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)

    # Delete the rows from the target table. Take an exclusive lock on the table while we do the refresh.
    sqlStmt = """
        LOCKING """ + options.targetTbl + """ FOR EXCLUSIVE
        DELETE FROM """ + options.targetTbl + """;"""
    rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
    
    if options.purgeWhere > "":
        sqlStmt = """
            INSERT INTO """ + options.targetTbl + """
            SELECT *
              FROM PURGED_ROWS B;"""
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
        if rowCount > 0:
            replMod.printMsg(str(rowCount) + " logical deletes were inserted back into the target table.")
    
    if options.where > "":
        whereClause = "  AND " + options.where
    else:
        whereClause = ""
        
    # We should only have 'I' transactions at this point since we only loaded the first file.
    sqlStmt = """
        INSERT INTO """ + options.targetTbl + """
          (""" + ",".join(tbl.columnList) + hc.hardCodeCol + """)
        SELECT """ + ",".join(tbl.columnList) + hc.hardCodeVal.replace("@ALIAS.","")+ """
          FROM """ + options.auditTbl + """ B
          WHERE DM_OPERATION_TYPE = 'I'
          """ + whereClause + """;"""
    refreshInserts = cursor.execute(sqlStmt).rowcount

    if purgedRows:
        # Release the exclusive lock
        sqlStmt = "END TRANSACTION;"
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)

    # Now, delete the rows from the staging table.
    sqlStmt = """
        DELETE FROM """ + options.auditTbl + """;"""
    refreshInserts = cursor.execute(sqlStmt).rowcount
    
    targetDbName, targetTblName = options.targetTbl.split(".")
    
    sqlStmt = """
        UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
          SET REFRESH_IND = 'N'
          WHERE DB_NAME = '""" + targetDbName + """'
            AND TBL_NAME = '""" + targetTblName + """';"""
    rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)        
    
    replMod.printMsg("Refresh is complete. Table was refreshed with " + str(refreshInserts) + " rows.")
    
    return refreshInserts, "'" + refreshTs + "'"

    
def connect(connType, connStr):   
       
    # This tries to connect 5 times with a 10 second pause in between
    connected = False
    for i in range(5):       
        if connType == "ceODBC":
            try:
                conn = ceODBC.connect(connStr, autocommit=True)
            except:
                if i < 4:
                    replMod.printMsg("ceODBC connect failed. Retrying in 10 seconds...")
                    time.sleep(10)
            else:
                connected = True
                break
        else:
            try:
                conn = pyodbc.connect(connStr, ANSI=True, autocommit=True)
            except:
                if i < 4:
                    replMod.printMsg("pyodbc connect failed. Retrying in 10 seconds...")
                    time.sleep(10)
            else:
                connected = True
                break
    
    if connected == False:
        replMod.printMsg(connType + " connection failed after trying 5 times, shutting down.")
        raise SystemExit(12)
    
    return conn

    
def execSql(conn, cursor, env, sqlStmt, parmList, options):

    # We will try this 5 times before we fail if we get a deadlock.
    for i in range(5):
        try:
            rowCount = cursor.execute(sqlStmt, tuple(parmList)).rowcount
        except pyodbc.Error as e:
            (_, errorText) = e.args
            # If it's a deadlock, don't abend unless it's the fifth time through
            if "(-2631)" in errorText and i < 4:
                replMod.printMsg("Teradata deadlock error 2631, retrying (up to 5 times)")
            else:
                # This will give us standard output when we get an SQL error and will also update the APPLY_REPL_TABLE
                # to indicate that the table failed.
                replMod.printMsg("***** Unexpected Teradata error: " + errorText)
                replMod.printMsg("***** SQL = \n" + sqlStmt)
                replMod.printMsg("***** Parm List = \n" + str(parmList))
                replMod.printMsg("***** Terminating script.")
                if options.jobName > "":
                    # Update the control table to indicate that this has failed
                    sqlStmt = """
                        UPDATE """ + env.dbPrefix + """_TBLS_EVNT_STATS.APPLY_REPL_TABLE
                        SET STATUS = 'FAILED'
                        WHERE JOB_NAME = ?
                        AND DB_NAME = ?
                        AND TBL_NAME = ?;"""  
                    parms = (options.jobName, options.targetTbl.split(".")[0], options.targetTbl.split(".")[1])
                    cursor.execute(sqlStmt, parms)                
                cursor.close()
                conn.close()
                raise SystemExit(12)
        else:
            # Break out of the loop if we no longer have an error.
            break
        
    return rowCount
    

def genLoad(env, tbl, options, genTpump):

    targetTbl = options.auditTbl.split(".")[1]
    oraTbl = "_".join(targetTbl.split("_")[:-1])
    suffix = targetTbl.split("_")[-1]
    
    loadList = []
    loadList.append(".LOGTABLE " + options.auditTbl + "_LG;")
    loadList.append(".LOGON " + env.tdp + "/" + env.dbPrefix + "ETL,$tdwallet(" + env.dbPrefix + "ETL_PWD);\n")
    
    # Set the UtilityDataSize of the query band based on the size of the file so that we get more sessions for 
    # larger files.
    fileSize = os.stat(env.kdwHome + "\\inbound\\repl\\" + suffix + "\\" + oraTbl + ".inprocess").st_size
    if fileSize < 10000000:
        utilityDataSize = "SMALL"
    elif fileSize < 10000000000:
        utilityDataSize = "MEDIUM"
    else:
        utilityDataSize = "LARGE"
    
    loadList.append("SET QUERY_BAND='UTILITYDATASIZE=" + utilityDataSize + ";JOBNAME=" + targetTbl + ";' UPDATE FOR SESSION;\n") 
    if genTpump:
        loadList.append(".BEGIN LOAD")
        loadList.append(" SESSIONS 1")
        loadList.append(" ERRORTABLE " + options.auditTbl + "_ET")
        loadList.append(" PACKMAXIMUM")
        loadList.append(" ARRAYSUPPORT ON")
        loadList.append(" ROBUST ON;\n")
    else:
        loadList.append(".BEGIN IMPORT MLOAD")
        loadList.append(" AMPCHECK NONE")
        loadList.append(" TABLES       " + options.auditTbl)
        loadList.append(" WORKTABLES   " + options.auditTbl + "_WT")
        loadList.append(" ERRORTABLES  " + options.auditTbl + "_ET")
        loadList.append("              " + options.auditTbl + "_UV")
        loadList.append(";\n")
    loadList.append(".LAYOUT INPUT_RECORD;")
    loadList.append(".FIELD DM_LINE_NUMBER * VARCHAR(30);")
    loadList.append(".FIELD DM_INSERT_TIMESTAMP * VARCHAR(30);")
    loadList.append(".FIELD DM_TXID * VARCHAR(30);")
    loadList.append(".FIELD DM_OPERATION_TYPE * VARCHAR(3);")
    loadList.append("\n".join(tbl.tptColumnList))
    loadList.append(".DML LABEL INSERT_ROW")
    loadList.append(" IGNORE DUPLICATE ROWS;")
    loadList.append("INSERT INTO " + options.auditTbl)
    loadList.append(" (DM_LINE_NUMBER = :DM_LINE_NUMBER")
    loadList.append(" ,DM_INSERT_TIMESTAMP = :DM_INSERT_TIMESTAMP")
    loadList.append(" ,DM_TXID = :DM_TXID")
    loadList.append(" ,DM_OPERATION_TYPE = :DM_OPERATION_TYPE")    
    loadList.append(" ," + "\n ,".join(tbl.tptInsertList) + ");\n")
    loadList.append(".IMPORT INFILE " + env.kdwHome + "\\inbound\\repl\\" + suffix + "\\" + oraTbl + ".inprocess")
    loadList.append(" FORMAT VARTEXT '\x1F'")
    loadList.append(" LAYOUT INPUT_RECORD")
    loadList.append(" APPLY INSERT_ROW;\n")
    if genTpump:
        loadList.append(".END LOAD;")
    else:
        loadList.append(".END MLOAD;")
    loadList.append(".LOGOFF;")
      
    loadFile = open(env.kdwHome + "/scratch/" + targetTbl + ".load", "w")
    loadFile.write("\n".join(loadList))
    loadFile.close()
    
    return utilityDataSize

        
def getMaxTs(conn, cursor, env, options):

    # Get the maximum DM_INSERT_TIMESTAMP as a VARCHAR(26). This will be used to drive the rows that we're 
    # going to update.
    replMod.printMsg("Selecting the maximum DM_INSERT_TIMESTAMP from the audit table.")
    # Only select the rows that have a DM_INSERT_TIMESTAMP and DM_LINE_NUMBER greater than the log row.
    sqlStmt = """
        LOCKING ROW FOR ACCESS
        SELECT CAST(MAX(DM_INSERT_TIMESTAMP) AS VARCHAR(26))
          FROM """ + options.auditTbl + """;"""
    _ = execSql(conn, cursor, env, sqlStmt, tuple(), options)
    
    return cursor.fetchone()[0]
    

def getStmt(actionCd, insertStmt, updateStmt, deleteStmt):

    if actionCd == "I":
        sqlStmt = insertStmt
    elif actionCd == "U":
        sqlStmt = updateStmt
    else:
        sqlStmt = deleteStmt

    return sqlStmt

    
def insertList(list1, list2):

    for i,x in enumerate(list2):
        list1.insert(i,x)
        

def loadStageTbl(env, tbl, options, conn, cursor):

    # Check to see if in process file exists
    auditDb, auditTbl = options.auditTbl.split(".")
    oraTbl = "_".join(auditTbl.split("_")[:-1])
    suffix = auditTbl.split("_")[-1]
    fileExists = False
    if len(glob.glob(env.kdwHome + "/inbound/repl/" + suffix + "/" + oraTbl + ".inprocess")) > 0:
        replMod.printMsg("Restarting the load (Mload or Tpump).")
        fileExists = True
    else:
        # Rename each of the hardened files to indicate that we're processing
        for i, fileName in enumerate(glob.glob(env.kdwHome + "/inbound/repl/" + suffix + "/" + oraTbl + ".D*.T*")):
            os.rename(fileName, env.kdwHome + "/inbound/repl/" + suffix + "/" + \
                oraTbl + ".inprocess." + fileName[-19:])
            fileExists = True
            if options.refreshInd and i == 0:
                # Stop at the first file if this is a refresh
                replMod.printMsg("Refresh detected. Only the first file will be loaded into the staging table.")
                break
        if fileExists:
            # Run the Python pre-process script to replace the line feeds, unicode, and hex characters
            execnStrng = 'python prepFileCdc.py -s "' + env.kdwHome + "\\inbound\\repl\\" + suffix + "\\" + oraTbl + \
                '.inprocess.D*.T*"' + ' -t "' + env.kdwHome + "\\inbound\\repl\\" + suffix + "\\" + oraTbl + \
                '.inprocess" -f ' + str(len(tbl.tptColumnList) + 3)
            replMod.printMsg("Running prepFileCdc script to prepare/consolidate file(s).")
            retCd = subprocess.call(execnStrng, shell=True)
            if retCd != 0:
                replMod.printMsg("Error in prepFileCdc.py, return code =  " + str(retCd))
                raise SystemExit(12)
                
    # Remove the individual inprocess files.
    for fileName in glob.glob(env.kdwHome + "/inbound/repl/" + suffix + "/" + oraTbl + ".inprocess.D*.T*"):
        # For debugging purposes, you might want to uncomment this to have the files go to a save directory
        # if oraTbl.upper() == "PS_TL_RPTD_TIME":
        #     os.rename(fileName, "/".join(fileName.split("\\")[:3]) + "/save/" + fileName.split("\\")[3])
        # else:
        os.remove(fileName)            
    
    if fileExists:
        fileSize = os.stat(env.kdwHome + "\\inbound\\repl\\" + suffix + "\\" + oraTbl + ".inprocess").st_size
        # Generate the Multiload
        if fileSize < 5000000:
            genTpump = True
            loadOp = "tpump"
        else:
            genTpump = False
            loadOp = "mload"
            
        utilityDataSize = genLoad(env, tbl, options, genTpump)
        
        replMod.printMsg("Running " + loadOp.upper() + " to load the staging table using a UtilityDataSize of " + \
            utilityDataSize + ".")
        execnStrng = loadOp + " < " + env.kdwHome + "\\scratch\\" + auditTbl + ".load > " + \
            env.kdwHome + "\\logs\\repl\\" + loadOp + "_" + auditTbl.lower() + ".log 2>&1"
        retCd = subprocess.call(execnStrng, shell=True)
        if retCd != 0:
            replMod.printMsg("Error in load process, return code =  " + str(retCd))
            replMod.printMsg("execnStrng = \n" + execnStrng)
            raise SystemExit(12)
            
        # Check to see if the error tables exist
        sqlStmt = """
            SELECT 1
              FROM DBC.Tables
              WHERE DatabaseName = '""" + auditDb + """'
                AND TableName IN ('""" + auditTbl + """_ET','""" + auditTbl + """_UV');"""
        rowCount = execSql(conn, cursor, env, sqlStmt, tuple(), options)
        if rowCount > 0:
            replMod.printMsg("ET or UV table exists after running the load process.")
            replMod.printMsg("Stopping process")
            raise SystemExit(12)

        os.remove(env.kdwHome + "/scratch/" + auditTbl + ".load")
        os.remove(env.kdwHome + "/logs/repl/" + loadOp + "_" + auditTbl.lower() + ".log")
        os.remove(env.kdwHome + "/inbound/repl/" + suffix + "/" + oraTbl + ".inprocess")
    else:
        replMod.printMsg("No transaction files were found.")   

    return fileExists


def main():

    usage = "usage: %prog [options] targetTbl"
    version = "%prog 1.0.0"
    description = \
        "Process the audit rows and update the target tables based on the audit rows."
    parser = OptionParser(usage=usage, version=version, description=description)
    
    parser.add_option("-t", "--targetTbl",
        action="store",
        default="",
        help="Specify the target table in databasename.tablename format [default: %default]")   
    parser.add_option("-a", "--auditTbl",
        action="store",
        default="",
        help="Specify the audit table name in databasename.tablename format [default: %default]")   
    parser.add_option("-k", "--keyColumns",
        action="store",
        default="",
        help="Specify the key columns (must be non-null), separated by commas. If not specified, all columns are considered to be the key [default: %default]")   
    parser.add_option("-m", "--mode",
        action="store",
        default="",
        help="Specify 'T' for transaction mode or 'B' for batch mode [default: %default]")   
    parser.add_option("-c", "--hardCoding",
        action="store",
        default="",
        help="Specify hard-coded values for columns in target that are not in replicated table. Example: \"SOURCE_ID = 2, TRANSCODE = 'R', TRANSDATE = CURRENT_TIMESTAMP(0)\" [default: %default]")   
    parser.add_option("-e", "--exclusiveLock",
        action="store_true",
        default=False,
        help="Specify this option if you want batch mode to take an exclusive lock on the target table while updating it [default: %default]")   
    parser.add_option("-l", "--loggingInterval",
        action="store",
        default="1",
        help="Specify the logging interval in minutes [default: %default]")   
    parser.add_option("-j", "--jobName",
        action="store",
        default="",
        help="Specify the job name that this load is associated with [default: %default]")   
    parser.add_option("-p", "--packFactor",
        action="store",
        default=16000, 
        help="Specify the pack factor to use for the job [default: %default]")   
    parser.add_option("-d", "--delimiter",
        action="store",
        default=";", 
        help="Specify the column literal delimiter to use [default: %default]")   
    parser.add_option("-w", "--where",
        action="store",
        default="", 
        help="Specify an optional WHERE clause for the extract (do not include the word 'WHERE') [default: %default]")   
    parser.add_option("-u", "--purgeMode",
        action="store_true",
        default=False, 
        help="Specify this option to do an update instead of a physical delete. [default: %default]")   
    parser.add_option("-s", "--purgeSet",
        action="store",
        default="", 
        help="Specify the columns to set for a logical delete (example: \"TRANSCODE = 'P', TRANSDATE = CURRENT_TIMESTAMP(0)\") [default: %default]")   
    parser.add_option("-g", "--purgeWhere",
        action="store",
        default="", 
        help="Specify the WHERE clause for purged rows not including the word 'WHERE' (example: \"TRANSCODE = 'P'\") [default: %default]")   
    parser.add_option("-r", "--refreshInd",
        action="store_true",
        default=False, 
        help="Specify whether this is a table refresh. [default: %default]")   
    parser.add_option("-q", "--queryBand",
        action="store",
        default="UtilityDataSize=SMALL;", 
        help="Specify the query band for the Multiload utility [default: %default]")   
       
    (options, args) = parser.parse_args()

    if len(args) == 0 and options.mode.upper() in ("T","B") and \
            options.keyColumns > "" and \
            options.targetTbl > "" and options.auditTbl > "":
        applyRepl(options)
    else:
        parser.print_help()
        raise SystemExit(12)


if __name__ == '__main__':
    main()
    
