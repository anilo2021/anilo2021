#!/usr/bin/env python

# Script Name:  prepFileCdc.py
# Date Written: 08/04/15
# Description:  This script pre-processes a set of files to remove line feeds, 
#             add a line number, replace unicode characters with a question mark,
#             and remove other characters outside of the hex 00-7F range.

# Usage example:
# python prepFileCdc.py -s "F:\kdw\dev\inbound\repl\py\PS_BUS_UNIT_TBL.inprocess.D*.T*" ^
#     -t "F:\kdw\dev\inbound\repl\py\PS_BUS_UNIT_TBL.inprocess" ^
#     -f 10     

# Modification Log:
    
# Date   Name         Comments
# -------- ------------ -----------------------------------------------  
# 08/04/15 B. Hull      Original.
# 09/11/15 B. Hull      Replaced the regex logic with a decode/encode to 
#                     replace Unicode characters with windows-1252 
#                     characters or question marks where it can't do 
#                     the conversion.
# 06/12/18 J. Rominske  Updated to Python 3 standard (print statements)

import glob
import datetime
from optparse import OptionParser


def prepFileCdc(options):

    print("Converting " + options.sourceFileSpec + " files to TPT compatible format...")
  
    target = open(options.targetFile, "w")
    
    newLineList = []
    writeBuffer = []
    lineNo = 0
    
    fieldCountInt = int(options.fieldCount)
    
    # Loop through each file that matches the sourceFileSpec
    for fileName in glob.glob(options.sourceFileSpec):
        print("Processing " + fileName)
        
        source = open(fileName, 'r')
        
        noOfFields = 0
        
        # Process each line in the file
        for line in source:
            # Replace every non-ASCII character with a question mark.
            newLineList.append(line[:-1].decode("utf8","replace").encode("windows-1252","replace"))
            
            # Add to the number of fields that we've processed so that we know when we're done with a record.
            noOfFields += line.count("\x1F")
                
            # If we've hit the number of fields that we expected to hit, the record is complete so append it to 
            # the write buffer.
            if noOfFields == fieldCountInt:
                lineNo += 1
                writeBuffer.append(str(lineNo) + "\x1F" + "\x1E".join(newLineList) + "\n")
                del newLineList[:]
                noOfFields = 0
            
            # Once we have 1000 records in the write buffer, then do the physical write.
            if len(writeBuffer) >= 1000:
                target.write("".join(writeBuffer))
                del writeBuffer[:]
                
        source.close()
    
    # If we have any records left in the write buffer, write them out.
    if len(writeBuffer) > 0:
        target.write("".join(writeBuffer))
            
    target.close()
    
    print("Process complete")
       
                
def main():
    """Parse the command line and run the program."""

    usage = "usage: %prog [options]"
    version = "%prog 1.0.0"
    description = \
        "This converts a CDC file to a file that can be loaded to Teradata using TPT."
    parser = OptionParser(usage=usage, version=version, description=description)

    parser.add_option("-s", "--sourceFileSpec",
        action="store",
        default="", 
        help="Specify the source file spec [default: %default]")  
    parser.add_option("-t", "--targetFile",
        action="store",
        default="", 
        help="Specify the target file [default: %default]")    
    parser.add_option("-f", "--fieldCount",
        action="store",
        default=0, 
        help="Specify the expected field count on each record [default: %default]") 
        
    (options, args) = parser.parse_args()
    if len(args) == 0 and options.sourceFileSpec > "" and options.targetFile > "" and options.fieldCount > 0:
        prepFileCdc(options)
    else:
        parser.print_help()
        raise SystemExit(2)


if __name__ == '__main__':
    main()
