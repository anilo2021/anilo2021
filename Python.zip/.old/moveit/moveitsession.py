####################################################################################################
# Name:                 moveitsession.py
# Python version:       Python 3.6.4
# Wiki path:            N/A
# Command line usage:   N/A
# Purpose:              Class contains wrapper methods to call MOVEit APIs
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-06-10 Sanju Joseph (sanj827@kellyservices.com)      Original Author
####################################################################################################

import requests
import json

# local module imports
from common.session import session

class moveItSession(session):
    def _setup(self):
        self.directory = self.repoDirectory/'moveit'
        # load stored credentials from JSON file
        self.moveit_creds = json.load(open(self.secureDirectory/(self.env+'_moveitcreds.json')))
        # session variables for IICS API interface
        self.server_url = 'https://amdcwftp05'
        self.moveit_api = self.server_url + '/api/v1/'
        
        self.hdrs = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        self.req = requests.Session()

    def json_response(self, response):
        if response.status_code == 200:
            self.log(text='response: ' + response.text)
        else:
            self.raise_exception(response)

        return json.loads(response.text)

    def raise_exception(self, response, logout_required=True):
        self.log(text='error code: ' + str(response.status_code))
        self.log(text='error response: ' + response.text)

        if logout_required:
            try:
                if self.logout() == False:
                    self.log(text='logout failed')
            except Exception as logout_exception:
                self.log(text='logout exception: ' + str(logout_exception))

        raise Exception(response.text)

    def login(self):
        login_url = self.moveit_api + 'token'
        self.log(text='Logging into MOVEit as ' + self.moveit_creds['username'])
        
        req_headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        moveit_creds = json.load(open(self.secureDirectory/(self.env+'_moveitcreds.json')))
        login_body = {"grant_type": moveit_creds['grant_type'], "server_host": moveit_creds['server_host'], "username": moveit_creds['username'], "password": moveit_creds['password']}
        response = self.req.post(login_url, headers=req_headers, data=login_body, verify=False)
        if response.status_code == 200: 
            self.log(text='Login Success')
            login_response = json.loads(response.text)
            self.hdrs['Authorization'] = 'Bearer ' + str(login_response['access_token'])
            return True
        else:
            self.log(text='Login Failed. Status code: ' + str(response.status_code))
            self.log(text=response.text)
            return False
    
    def logout(self):
        logout_url = self.moveit_api + 'token/revoke'
        req_headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        logout_body = {"token": self.hdrs['Authorization'].replace('Bearer ','')}
        try:
            response = self.req.post(logout_url, headers=req_headers, data=logout_body)
            if response.status_code == 200: 
                self.log(text='Logout Success')
                return True
            else:
                self.log(text='Logout Failed')
                self.log(text=response.text)
                return False
        except Exception as logout_exception:
                self.log(text='logout exception: ' + str(logout_exception))

    def get_all_tasks(self):
        tasks_url = self.moveit_api + 'tasks'
        self.log(text='request url: ' + tasks_url)
        tasks_res = self.req.get(tasks_url, headers=self.hdrs)
        
        return self.json_response(tasks_res)

    def start_task(self, task_id):
        start_task_url = self.moveit_api + 'tasks/' + str(task_id) + '/start'
        self.log(text='request url: ' + start_task_url)
        start_task_res = self.req.post(start_task_url, headers=self.hdrs)
        
        return self.json_response(start_task_res)
    
    def get_all_running_tasks(self):
        running_task_url = self.moveit_api + 'tasks/running'
        self.log(text='request url: ' + running_task_url)
        running_task_res = self.req.get(running_task_url, headers=self.hdrs)
        
        return self.json_response(running_task_res)

    def get_task_status(self, task_id, nominal_start):
        tasks_status_url = self.moveit_api + 'reports/taskruns'
        self.log(text='request url: ' + tasks_status_url)
        tasks_status_req_body = {"predicate": "TaskID==" + str(task_id) + ";NominalStart==\"" + str(nominal_start) +"\"","orderBy": "!StartTime","maxCount": 1}
        self.log(text='request: ' + json.dumps(tasks_status_req_body))
        tasks_status_res = self.req.post(tasks_status_url, headers=self.hdrs, json=tasks_status_req_body)
        
        return self.json_response(tasks_status_res)

    def stop_task(self, task_id, nominal_start):
        stop_task_url = self.moveit_api + 'tasks/' + str(task_id) + '/stop'
        self.log(text='request url: ' + stop_task_url)
        stop_task_req_body = {"nominalStart" : str(nominal_start)}
        self.log(text='request: ' + json.dumps(stop_task_req_body))
        stop_task_res = self.req.post(stop_task_url, headers=self.hdrs, json=stop_task_req_body)
        self.log(text='stop task response status code: ' + str(stop_task_res.status_code))
        if stop_task_res.status_code != 200:
            self.log(text='stop task response message: ' + stop_task_res.text)
        