####################################################################################################
# Name:                 runtask.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/moveit/runtask.vsdx
# Command line usage:   python start.py runmoveittask <moveit_taskname> [timeout_in_mins_default_60_mins]
# Purpose:              Execute MOVEit task
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-06-14 Sanju Joseph (sanj827@kellyservices.com)      Original Author
####################################################################################################

# library imports
import sys
import os
import datetime
import time

# local module imports
from moveit.moveitsession import moveItSession

def get_taskid(session, response, task_name):
    task_id = ''
    get_all_tasks_res = response['items']
    for each_task in get_all_tasks_res:
        if task_name.lower() == each_task['Name'].lower():
            task_id = each_task['ID']
            break

    return task_id

def application_exit():
    sessionContainer['moveit'].log(text='task status: succeed\nexit')
    sys.exit(0)

def application_exit_due_to_failure(session):
    session.log(text='task status: failed\nexit')
    sys.exit(1)

def get_last_ran_status(session, task_id, nominal_start):
    last_ran_task_list = session.get_task_status(task_id, nominal_start)['items']
    for each_task in last_ran_task_list:
        if task_id == str(each_task['TaskID']) and nominal_start == each_task['NominalStart']:
            if each_task['Status'].lower() == "success":
                session.log(text='Task id ' + task_id + ' completed successfully at ' + str(each_task['EndTime']))            
                session.logout()
                application_exit()
            else:
                session.log(text='Task id ' + task_id + ' status is not success')
                session.logout()
                application_exit_due_to_failure(session)

    session.log(text="didn't find task id '" + task_id + "' with nominal start time '" + nominal_start + "'. Hence marking as failure")
    session.logout()
    application_exit_due_to_failure(session)

def check_task_status(session, task_id, nominal_start, timeout_in_minutes):
    is_timeout = True
    is_task_completed = False
    current_datetime = datetime.datetime.now()
    timeout_datetime = current_datetime + datetime.timedelta(minutes=int(timeout_in_minutes))

    while current_datetime <= timeout_datetime:
        session.log(text='checking task id ' + task_id + ' status at ' + current_datetime.strftime("%m-%d-%Y, %H:%M:%S %p"))
        session.login()

        running_task_list = session.get_all_running_tasks()['items']
        if len(running_task_list) == 0:
            session.log(text='Running task list is empty')
            session.logout()
            is_timeout = False
            is_task_completed = True
            break

        for each_task in running_task_list:
            if task_id == str(each_task['TaskID']) and nominal_start == each_task['NominalStart']:
                session.log(text='Task is still running')
                session.logout()
            else:
                session.log(text='Task completed')
                is_timeout = False
                is_task_completed = True
                session.logout()
                break
        
        if is_task_completed==True:
            break
        else:
            time.sleep(15)

        current_datetime = datetime.datetime.now()

    session.login()
    if is_timeout==False and is_task_completed:
        get_last_ran_status(session, task_id, nominal_start)
    else:
        session.log(text='Timeout, hence marking the status as failure and stopping the task...')
        session.stop_task(task_id, nominal_start)
        session.logout()
        application_exit_due_to_failure(session)
      
def start(session, task_name, timeout_in_minutes):
    if session.login():
        task_id = get_taskid(session, session.get_all_tasks(), task_name)
        if len(task_id) != 0:
            session.log(text="found task id '" + task_id + "' of task name '" + task_name + "'")
            start_task_res = session.start_task(task_id)
            nominal_start = start_task_res['nominalStart']
            session.log(text='Task has been started at nominal start datetime: ' + nominal_start)
            session.logout()
            
            check_task_status(session, task_id, nominal_start, timeout_in_minutes)
        else:
            session.log(text="task name '" + task_name + "' doesn't exist")
            session.logout()
            application_exit_due_to_failure(session)
    else:
        session.log(text="login failed")
        application_exit_due_to_failure(session)
      

# main thread
if __name__ == "__main__":
    print('Running...')
    default_timeout_duration = 60
    timeout_in_minutes = str(default_timeout_duration)
    task_name = ''

    if len(sys.argv) > 1:
        task_name = sys.argv[1]
        task_name = task_name.strip()
    try:
        sessionContainer = {}
        sessionContainer['moveit'] = moveItSession(os.path.basename(__file__)[:-3], taskName=task_name)
        
        if len(task_name)==0:
            sessionContainer['moveit'].log(text="error: task name parameter is empty, hence marked status as 'failed'")
            application_exit_due_to_failure(sessionContainer['moveit'])
        else:
            sessionContainer['moveit'].log(text='input param 1 value: ' + sys.argv[1])

        if len(sys.argv) > 2:
            sessionContainer['moveit'].log(text='input param 2 value: ' + sys.argv[2])
            
            try:
                timeout_in_minutes = sys.argv[2].rstrip('0')
                timeout_in_minutes = int(timeout_in_minutes)
            except Exception as timeout_exception:
                sessionContainer['moveit'].log(text="error: timeout value must be a positive integer")
                application_exit_due_to_failure(sessionContainer['moveit'])

            if timeout_in_minutes <= 0:
                sessionContainer['moveit'].log(text="error: timeout value must be greater than zero")
                application_exit_due_to_failure(sessionContainer['moveit'])
               
        else:
            sessionContainer['moveit'].log(text='input param 2 value: ')
            timeout_in_minutes = default_timeout_duration
            sessionContainer['moveit'].log(text='timeout parameter is empty, hence set default ' + str(timeout_in_minutes) + ' minutes')

        sessionContainer['moveit'].log(text='task name: ' + task_name)
        sessionContainer['moveit'].log(text='timeout: ' + str(timeout_in_minutes) + ' minutes\n')

        start(sessionContainer['moveit'], task_name, timeout_in_minutes)
    except Exception as exception:
        sessionContainer['moveit'].log(text='Exception: ' + str(exception))
        raise