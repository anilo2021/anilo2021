####################################################################################################
# Name:                 axonmonitor.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/axonmonitor.vsdx
# Command line usage:   python start.py axonmonitor [-t]
# Purpose:              Evaluates status for MDM-relevant services and endpoints; sends eMail alerts when issues are detected/resolved.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2020-06-30 J. Rominske (jesr114@kellyservices.com)       Initial version
####################################################################################################

# library imports
import datetime
from influxdb import InfluxDBClient
import json
from pathlib import Path
import sys
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

# local module imports
from alerts.alertssession import alertsSession
from axon.axonsession import axonSession

# main script logic
def axonMonitor(session):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        session.log(text='Script run disabled in config file')
        return False
    # disable if during maintenance window
    if session.weekMaintWindow():
        session.log(text='Skipping monitor checkup for maintenance window')
    else:
        # start counters
        session.statData = {
            'errorCnt': 0,
            'warningCnt': 0,
            'urlErrors': [],
            'processErrors': []
        }
        # iterate through list of servers for the environment and report results
        session.log(text='Testing servers...')
        serverList = session.scriptConfig['axonUrls']
        for entry in serverList:
            session.log(text='Pinging '+entry['name']+' server at '+entry['address']+'...')
            conflictInd = session.getUrl(entry['address'])
            if conflictInd == 0:
                session.log(text=entry['name']+' server ping success')
            else:
                session.log(text=entry['name']+' server ping error')
                session.statData['errorCnt'] += 1
                session.statData['urlErrors'].append(entry['address'])
        
        # check the JBoss monitor log for errant statuses
        session.log(text='\nChecking custom Axon status files...')
        # check all script paths specified in the config file
        for customLogPathString in session.scriptConfig['customLogPaths']:
            customLogPath = Path(customLogPathString)
            # check if file exists and raise alert if not
            if not customLogPath.exists():
                session.log(text='ERROR: Log file '+str(customLogPath)+' not found')
                continue
            else:
                with open(customLogPath, 'r') as statusFile:
                    session.log(text='Status file '+str(customLogPath)+' loaded')
                    # load status file as list of lines
                    lineList = statusFile.readlines()
                    # check if file conatains more than the header and raise alert if not
                    if len(lineList) <= 2:
                        session.log(text='ERROR: Log file '+str(customLogPath)+' error - no contents found')
                        continue
                    timestamp = lineList[0].strip('\n').strip(' ')
                    # raise alert if log is behind by more than 15 minutes
                    now = datetime.datetime.today()
                    customLogTime = datetime.datetime.strptime(timestamp, '%m-%d-%Y_%H:%M:%S')
                    warningTime = session.scriptConfig['customLogTimeAllowance']['warning'] # number of minutes before warning
                    errorTime = session.scriptConfig['customLogTimeAllowance']['error'] # number of minutes before error
                    # check if error time elapsed
                    if now - datetime.timedelta(minutes=errorTime) >= customLogTime:
                        session.log(text='ERROR: Log last updated more than '+str(errorTime)+' minutes ago')
                        session.statData['errorCnt'] += 1
                    # check if warning time elapsed
                    elif now - datetime.timedelta(minutes=warningTime) >= customLogTime:
                        session.log(text='WARNING: Log last updated more than '+str(warningTime)+' minutes ago')
                        session.statData['warningCnt'] += 1
                    # check service statuses
                    statusList = [l[1:-1] for l in lineList if l.startswith(' |')] # removes any blank lines
                    # parse each line of the log file (except the header) into a list
                    for i in range(len(statusList)):
                        statusList[i] = statusList[i].replace(' ', '').replace('|', '').split('#')
                    # iterate through list of expected processes to check against statusList
                    for process in session.scriptConfig['expectedRunningProcesses']:
                        foundProcesses = [s[2] for s in statusList[2:-3]]
                        # report the status of the expected services as recorded by JBoss
                        if process in foundProcesses:
                            statusLine = statusList[foundProcesses.index(process)+2]
                            # if error, add to statusData
                            if statusLine[1] != '1':
                                session.log(text='ERROR: '+process+' status is '+statusLine[1]+' - expected status is 1')
                                session.statData['errorCnt'] += 1
                                session.statData['processErrors'].append(process+': '+statusLine[1])
                            # if OK, report success
                            else:
                                session.log(text='SUCCESS: '+process+' status: 1')
                        # if process not found in status, add to statusData
                        else:
                            session.log(text='ERROR: '+process+' status is missing')
                            session.statData['errorCnt'] += 1
                            session.statData['processErrors'].append(process+': MISSING')

        # log into Axon to confirm API connectivity
        if sessionContainer['axon'].login():
            session.log(text='SUCCESS: Axon login succeeded')
        else:
            session.log(text='ERROR: Axon login failed')
            session.statData['errorCnt'] += 1
        
        # insert results into Grafana database
        client = InfluxDBClient(host=session.alertsDbCreds['host'],
                                port=session.alertsDbCreds['port'], 
                                username=session.alertsDbCreds['username'],
                                password=session.alertsDbCreds['password'])
        session.log(text='Inserting results into Grafana DB '+session.alertsDbCreds['serverName']+'/'+session.alertsDbCreds['applicationName']+' via Grafana at '+session.alertsDbCreds['host']+':'+str(session.alertsDbCreds['port'])+'...')
        try:
            client.write_points(session.alertsDbCreds['applicationName']
                                +",host="+session.alertsDbCreds['serverName']
                                +" maxNotRunningServices="+str(len(session.statData['processErrors']))
                                +",maxNotRunningUrls="+str(len(session.statData['urlErrors'])),
                                protocol='line',database='telegraf')
            session.log(text='Gafana DB insert succeeded')
        # log error, but only increase warning count if Grafana fails
        except Exception as e:
            session.error(e, exit=False)
            session.log(text='WARNING: Grafana DB insert failed')
            session.statData['warningCnt'] += 1
        
        # run alert notification logic from session class and announce script success
        session.alertNotification()
        session.log(text='Axon monitoring script execution complete')


# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName='',  args=['axon'])
    sessionContainer['axon'] = axonSession('', '', logFileName=sessionContainer['alerts'].logFileName)
    try:
        if len(sys.argv) > 1 and sys.argv[1].startswith('-t'):
            sessionContainer['alerts'].alertNotification(test=True)
        else:
            axonMonitor(sessionContainer['alerts'])
        print('Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].alertsError(e, email=sessionContainer['alerts'].scriptConfig['errorNotification'])