####################################################################################################
# Name:                 edcmonitor.py
# Python version:       Python 3.6.4
# Source file:          AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/alerts/edcmonitor.vsdx
# Command line usage:   python start.py edcmonitor [-t]
# Purpose:              Tests all EDC servers and sends eMail alerts when issues are detected/resolved
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-03-31 H. Maddipati (harm344@kellyservices.com)      Original Author
# 2021-08-04 H. Maddipati (harm344@kellyservices.com)      Resolved problems with openpyxl module
####################################################################################################
# library imports
import datetime
from influxdb import InfluxDBClient
import json
from pathlib import Path
import sys
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

# local module imports
from alerts.alertssession import alertsSession

def edcMonitor(session):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        session.log(text='Script run disabled in config file')
        return False
    # disable if during maintenance window
    if not session.weekMaintWindow():
        # start counters
        session.statData = {
            'errorCnt': 0,
            'warningCnt': 0,
            'urlErrors': [],
            'processErrors': []
        }
        # iterate through list of servers for the environment and report ping results
        session.log(text='Testing servers...')
        serverList = session.scriptConfig['edcServers']
        for entry in serverList:
            session.log(text='\nPinging '+entry+'...')
            conflictInd = session.pingServer(entry)
            if conflictInd == 0:
                session.log(text='SUCCESS: '+entry+' pinged')
            else:
                session.log(text='ERROR: '+entry+' ping failed')
                session.statData['errorCnt'] += 1
                session.statData['urlErrors'].append(entry)
        
        # iterate through list of EDC URLs for the environment and report results
        session.log(text='Testing URLs...')
        serverList = session.scriptConfig['edcServiceUrls']
        for entry in serverList:
            session.log(text='\nPinging '+entry['name']+' server...')
            conflictInd = session.getUrl(entry['address'])
            if conflictInd == 0:
                session.log(text='SUCCESS: '+entry['name']+' status 200')
            else:
                session.log(text='ERROR: '+entry['name']+' status not 200')
                session.statData['errorCnt'] += 1
                session.statData['urlErrors'].append(entry['address'])
        
        # check the JBoss monitor log for errant statuses
        session.log(text='\nChecking custom JBoss status files...')
        # check all script paths specified in the config file
        for customLogPathString in session.scriptConfig['customLogPaths']:
            nodeName = customLogPathString.split('\\')[2]
            customLogPath = Path(customLogPathString)
            # check if file exists and raise alert if not
            if not customLogPath.exists():
                session.log(text='ERROR: Log file '+str(customLogPath)+' not found')
                session.statData['errorCnt'] += 1
                continue
            else:
                with open(customLogPath, 'r') as statusFile:
                    session.log(text='Status file '+str(customLogPath)+' loaded')
                    # load status file as list of lines
                    statusList = statusFile.readlines()
                    if len(statusList) < 1:
                        session.log(text='ERROR: Log file '+str(customLogPath)+' error - no statuses found')
                        session.statData['errorCnt'] += 1
                        continue
                    now = datetime.datetime.today()
                    timestamp = statusList[0].strip('\n').strip(' ')
                    customLogTime = datetime.datetime.strptime(timestamp,'%m-%d-%Y_%H:%M:%S')
                    warningTime = session.scriptConfig['customLogTimeAllowance']['warning'] # number of minutes before warning
                    errorTime = session.scriptConfig['customLogTimeAllowance']['error'] # number of minutes before error
                    # check if error time elapsed
                    if now - datetime.timedelta(minutes=errorTime) >= customLogTime:
                        session.log(text='ERROR: Log last updated more than '+str(errorTime)+' minutes ago')
                        session.statData['errorCnt'] += 1
                    # check if warning time elapsed
                    elif now - datetime.timedelta(minutes=warningTime) >= customLogTime:
                        session.log(text='WARNING: Log last updated more than '+str(warningTime)+' minutes ago')
                        session.statData['warningCnt'] += 1
                    # parse each line of the log file into a list
                    for i in range(len(statusList)):
                        # split by spaces, then remove nulls and newlines
                        statusList[i] = [j for j in statusList[i].strip('\n').split(' ') if j not in ('', '\n')]
                    foundProcesses = [s[1] for s in statusList[1:]] # exclude timestamp
                    # iterate through list of expected processes to check against statusList    
                    for process in session.scriptConfig['expectedRunningProcesses']:
                        # report the status of the expected services as recorded by JBoss
                        if process in foundProcesses:
                            statusLine = statusList[foundProcesses.index(process)+1] # +1 because, 0 index refers timestamp
                            # if error, add to statusData
                            if statusLine[3] != 'enabled':
                                session.log(text='ERROR: '+process+' status is '+statusLine[3]+' - expected status is enabled')
                                session.statData['errorCnt'] += 1
                                session.statData['processErrors'].append(process+': '+statusLine[3])
                            # if OK, report success
                            else:
                                session.log(text='SUCCESS: '+process+' status: enabled')
                        # if process not found in status, add to statusData
                        else:
                            session.log(text='ERROR: '+process+' status is missing')
                            session.statData['errorCnt'] += 1
                            session.statData['processErrors'].append(process+': MISSING')


        # insert results into Grafana database
        client = InfluxDBClient(host=session.alertsDbCreds['host'],
                                port=session.alertsDbCreds['port'], 
                                username=session.alertsDbCreds['username'],
                                password=session.alertsDbCreds['password'])
        session.log(text='Inserting results into Grafana DB '+session.alertsDbCreds['serverName']+'/'+session.alertsDbCreds['applicationName']+' via Grafana at '+session.alertsDbCreds['host']+':'+str(session.alertsDbCreds['port'])+'...')
        try:
            client.write_points(session.alertsDbCreds['applicationName']
                                +",host="+session.alertsDbCreds['serverName']
                                +" maxNotRunningServices="+str(len(session.statData['processErrors']))
                                +",maxNotRunningUrls="+str(len(session.statData['urlErrors'])),
                                protocol='line',database='telegraf')
            session.log(text='Gafana DB insert succeeded')
        # log error, but only increase warning count if Grafana fails
        except Exception as e:
            session.error(e, exit=False)
            session.log(text='WARNING: Grafana DB insert failed')
            session.statData['warningCnt'] += 1
        
        # run alert notification logic from session class and announce script succss
        session.alertNotification()
        session.log(text='EDC monitoring script execution complete')




# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['alerts'] = alertsSession(Path(__file__).stem, taskName='', args=['edc']) 
    try:
        if len(sys.argv) > 1  and sys.argv[1].startswith('-t'):
            sessionContainer['alerts'].alertNotification(test=True)
        else:
            edcMonitor(sessionContainer['alerts'])
        print('Script execution complete.')
    except Exception as e:
        sessionContainer['alerts'].alertsError(e, email=sessionContainer['alerts'].scriptConfig['errorNotification'])