####################################################################################################
# Name:                 deployiicsassetstoazuredevops.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/azuredevops/deployiicsassetstoazuredevops.vsdx
# Command line usage:   python start.py deployiicsassetstoazuredevops <DEV>
# Purpose:              Imports IICS assets from DFS(network drive) to Azure DevOps repositories
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-09-27 Sanju Joseph (sanj827@kellyservices.com)      Original Author
####################################################################################################

# library imports
import datetime
import json
import os
import sys
from pathlib import Path


# local module imports
from azuredevops.azuredevopssession import azureDevopsSession

# get all directory names of given path
def getDirectories(path):
    for _, dirnames, _ in os.walk(path):
        return dirnames

# create directory if directory doesn't exist and returns directory path 
def checkAndCreateDirectory(devops, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                devops.log(text="created new directory name: " + eachDirectory)
            except OSError:
                devops.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath

# get all file names of given path
def getFileNames(path):
    for _, _, filenames in os.walk(path):
        return filenames

# get all IICS asset (zip) file paths
def getFeatureDirectoryAssetPaths(path):
    filePaths = []
    for directory in getDirectories(path):
        for projectDir in getDirectories(os.path.join(path, directory)):
            assetDir = os.path.join(path, directory, projectDir)
            for fileName in getFileNames(assetDir):
                filePaths.append(os.path.join(assetDir, fileName))
    return filePaths

# get all sub-directories
def getSubdirectoryPaths(path):
    dirPaths = []
    for directory in getDirectories(path):
        subDir = os.path.join(path, directory)
        for projectDir in getDirectories(subDir):
            dirPaths.append(os.path.join(path, directory, projectDir))
        
        if subDir not in dirPaths:
            dirPaths.append(subDir)

    return dirPaths                

# create directory inside archive directory 
def createFeatureDirectoryInArchive(devops, archivePath, projectDirectory, featureDirectory):
    archiveDirArray = []
    archiveDirArray.append(projectDirectory)
    archiveDirArray.append(featureDirectory + '_' + getCurrentTimeStamp())
    return checkAndCreateDirectory(devops, archivePath, archiveDirArray)

# get current date time stamp
def getCurrentTimeStamp():
    return datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')

# provide pull request reviewer list
def getReviewerList(config, iicsProjectName):
    reviewerList =[]
    for id in str(config['iics']['reviewers'][iicsProjectName]).split(','):
        if len(id) > 0:
            reviewerList.append(json.loads('{"id":"' + id.strip() + '"}'))

    return reviewerList

# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def sendEmail(session, emailAddress, subject, body, isSuccess=False, attachment=None):
    if emailAddress is not None and emailAddress.strip() != '':
        recipients = []
        recipients.append(emailAddress)
        
        config = getConfiguration(session)
        emailDefaultRecipients = config['emaildefaultrecipients']
        sendEmailToRecipientsOnSuccess = config['sendemailtorecipientsonsuccess']

        if (not isSuccess) or (isSuccess and sendEmailToRecipientsOnSuccess):
            for email in emailDefaultRecipients.split(','):
                recipients.append(email.strip())

        try:
            body = convert_plaintext_to_html(body)
            with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_iicsexport.html') as template:
                emailbody = template.read().format(body)

            session.email(subject, emailbody, attachment=attachment, recipients=recipients)
        except Exception as emailException:
            session.log(text="error occurred while sending email. Error details: " + str(emailException))

# get Azure DevOps configuration
def getConfiguration(session):
    with open(session.configDirectory/'azuredevops-config.json') as configFile:
        return json.load(configFile)

# process IICS object to Azure Devops branch
def processIICStoAzureDevops(devops):
    env = devops.env
    config = getConfiguration(devops)

    export_package_path = config['iics']['dsfserverpath']+'\\'+config['iics']['export_package_path']
    logPath = export_package_path+'\\'+config['iics']['log_path']
    archivePath = export_package_path+'\\'+config['iics']['archive_path']
    
    pullRequestEnabled = config['iics']['pullrequestenabled']

    project_id = config['project_id']
    requestFileDetailsName = 'requestfiledetails.txt'

    # looping every directories under export directory
    for projectDirectory in getDirectories(export_package_path):
        # excluding directory which starts with underscore (_)
        if not projectDirectory.startswith('_'):
            for featureDirectory in getDirectories(os.path.join(export_package_path, projectDirectory)):
                devops.log(taskName=featureDirectory, directory=os.path.join(logPath, projectDirectory))
                
                if featureDirectory.startswith(config['iics']['feature_directory_name_starts_with']):
                    featureDirectoryPath = os.path.join(export_package_path, projectDirectory, featureDirectory)
                
                    pullrequestfilepath = os.path.join(featureDirectoryPath, requestFileDetailsName)
                    if os.path.exists(pullrequestfilepath):
                        devops.log(text= requestFileDetailsName + ' file is available')
                        repository_name = projectDirectory.lower()
                        
                        if repository_name in config['iics']['repos']:
                            # get the Repository Id based on IICS project name
                            repository_id = config['iics']['repos'][repository_name]
                            branches = devops.getBranches(repository_id)

                            emailAddress = ''
                            prhandler = open(pullrequestfilepath, 'r')
                            fileContents = prhandler.readlines()
                            prhandler.close()

                            for eachLine in fileContents:
                                keyValue = eachLine.replace('\n','').strip().split(':')
                                if keyValue[0] == 'EMAIL':
                                    emailAddress = keyValue[1]
                                    devops.log(text='request file created by ' + emailAddress)
                                    continue

                                if pullRequestEnabled and keyValue[0] == 'PULLREQUEST':
                                    if keyValue[1] == '1':
                                        isPullRequestRequired = True
                                        devops.log(text='Pull request is required')
                                    elif keyValue[1] == '0':
                                        isPullRequestRequired = False
                                        devops.log(text='Pull request is not required')
                                else:
                                    isPullRequestRequired = False
                        else:
                            devops.log(text=repository_name + ' repository id is not available in config file, hence ignored')
                            continue
                    else:
                        devops.log(text=requestFileDetailsName + ' file is not available, will process again once ' + requestFileDetailsName + ' file is available')
                        continue
                
                    try:
                        is_branch_exist = False
                        
                        for branch in branches:
                            branch_name = devops.getBranchName(branch)
                            branch_id = devops.getBranchObjectId(branch)
                            # get master branch id
                            if devops.isMasterBranch(branch):
                                master_branch_id = branch_id
                            # check if branch exists then get branch id 
                            if branch_name.lower().split('/')[-1] == featureDirectory.lower():
                                source_branch_name = branch_name
                                source_branch_id = branch_id
                                is_branch_exist = True

                        # if branch doen't exist then create branch and retrieve new branch id        
                        if not is_branch_exist:
                            devops.log(text="'" + featureDirectory + "' branch doesn't exist, hence creating branch")
                            createBranchResponse = devops.createBranch(project_id, repository_id, master_branch_id, featureDirectory)
                            source_branch_name = createBranchResponse[0].name
                            source_branch_id = createBranchResponse[0].new_object_id
                        else:
                            devops.log(text="'" + featureDirectory + "' branch already exists")

                        # create archive directory and sub-directories
                        featureDirectoryArchivePath = createFeatureDirectoryInArchive(devops, archivePath, projectDirectory, featureDirectory)
                        
                        # returns all assets path
                        assetPaths = getFeatureDirectoryAssetPaths(featureDirectoryPath)
                        
                        itemPaths = []
                        # committing asset changes one by one on Azure Devops above selected branch
                        for assetPath in assetPaths:
                            _, itemPath = devops.commitChanges(repository_id, assetPath, source_branch_id, source_branch_name, is_branch_exist, 3)
                            source_branch_id = devops.getBranchId(repository_id, source_branch_name)
                            itemPaths.append(itemPath)
                            try:
                                # moving asset to archive directory
                                itemPathArray = assetPath.split('\\')
                                archiveAssetPath = checkAndCreateDirectory(devops, featureDirectoryArchivePath, itemPathArray[-3:len(itemPathArray)-1])
                                newAssetPath = os.path.join(archiveAssetPath, itemPathArray[-1])
                                os.rename(assetPath, newAssetPath)
                                devops.log(text='Asset has been moved to archive directory: ' + newAssetPath + '\n')
                            
                            except Exception as movingToArchiveException:
                                devops.log(text='Exception occurred while moving asset to archive. Exception details: ' + str(movingToArchiveException))  
                        
                        if len(assetPaths) != 0:
                            devops.log(text='commited all changes successfully')
                            
                            pullReqTitle = 'Added/updated files on ' + featureDirectory + ' branch'
                            description = pullReqTitle
                            
                            # create pull request on Azure Devops
                            if pullRequestEnabled and isPullRequestRequired:
                                devops.log(text='iics project name: ' + projectDirectory)
                                reviewerList = getReviewerList(config, projectDirectory.lower())
                                devops.log(text='creating pull request...')
                                devops.createPullRequest(project_id, repository_id, source_branch_name, config['iics'][env]['targeted_branch_name'], pullReqTitle, description, reviewerList)

                        subject = 'Azure DevOps | Success'
                        body = "Requested file changes have been committed to Azure DevOps branch '" + featureDirectory + "' successfully. \r\n " + "Following are the committed file(s) details: " + " \r\n\t" + "\r\n\t".join(itemPaths)
                        sendEmail(devops, emailAddress, subject, body, isSuccess=True)
                    except Exception as exceptionOnFeatureDirectory:
                        devops.log(text='Exception for branch: ' + featureDirectory + '. Exception details: ' + exceptionOnFeatureDirectory.args[0])
                        
                        subject = 'Azure DevOps | Error'
                        body = 'An error occurred while processing requested file changes on Azure Devops branch name ' + featureDirectory + '. Please check the attached log file.'
                        sendEmail(devops, emailAddress, subject, body, isSuccess=False, attachment=str(devops.logFileName))

                    # remove requestfiledetails.txt file
                    os.remove(os.path.join(featureDirectoryPath, requestFileDetailsName))
                    devops.log(text='Removed ' + requestFileDetailsName + ' file')

                    # remove empty directories
                    removeSubdirectories = getSubdirectoryPaths(featureDirectoryPath)
                    removeSubdirectories.append(featureDirectoryPath)
                    for subDirectoryPath in removeSubdirectories:
                        try:
                            os.rmdir(subDirectoryPath)
                            devops.log(text='Removed empty directory: ' + subDirectoryPath)
                        except OSError as osError:
                            devops.log(text='Error occurred while removing empty directory: ' + subDirectoryPath + '. OSError details: ' + str(osError))
                
                else:
                    devops.log(text='Invalid directory name: ' + featureDirectory + '. Hence ignoring this directory.')
    

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['azuredevops'] = azureDevopsSession(os.path.basename(__file__)[:-3], taskName='')
    extraLogFilePath = str(sessionContainer['azuredevops'].logFileName)
    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as fileRemoveException:
        print("couldn't able to delete extra log file: "+extraLogFilePath)

    try:        
        processIICStoAzureDevops(sessionContainer['azuredevops'])

        print('Script execution complete')
    except Exception as e:
        if os.path.exists(str(sessionContainer['azuredevops'].logFileName)):
            sessionContainer['azuredevops'].error(e)
        else:
            print('Exception occurred: '+str(e))