####################################################################################################
# Name:                 azuredevopssession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/21/azuredevopssession
# Command line usage:   N/A
# Purpose:              Class contains methods to call Azure DevOps APIs
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-12-26 Sanju Joseph (sanj827@kellyservices.com)       Original Author
####################################################################################################

from vsts.exceptions import VstsServiceError
from vsts.vss_connection import VssConnection
from msrest.authentication import BasicAuthentication
from msrest.serialization import Model
from vsts.git.v4_1.models.git_pull_request_search_criteria import GitPullRequestSearchCriteria
import json
import base64
import os
from pathlib import Path

# local module imports
from common.session import session


class azureDevopsSession(session):
    def _setup(self):
        self.directory = self.repoDirectory/'iics'
        self.new_line = '\n'
        
        with open(os.path.join(self.configDirectory, 'azuredevops-config.json')) as configFile:
            self.config = json.load(configFile)
        
        with open(os.path.join(self.secureDirectory/'azuredevops.json')) as credentialsFile:
            credentialsConfig = json.load(credentialsFile)

        self.connection = VssConnection(base_url=self.config['organization_url'], creds=BasicAuthentication('', credentialsConfig['personal_access_token']))
        self.core_client = self.connection.get_client('vsts.core.v4_1.core_client.CoreClient')
        self.git_client = self.connection.get_client('vsts.git.v4_1.git_client.GitClient')
        
    # get Azure Devops project list
    def getProjects(self):
        return self.core_client.get_projects()

    # get Azure Devops repository list of a given project id
    def getRepositories(self, projectId):
        return self.git_client.get_repositories(projectId)

    # get all Azure Devops branches of a given repository id
    def getBranches(self, repositoryId):
        return self.git_client.get_refs(repositoryId)
    
    # returns branch id of a given repository id and branch name 
    def getBranchId(self, repositoryId, branchName):
        refs = self.git_client.get_refs(repositoryId)
        for ref in refs:
            if self.getBranchName(ref).lower() == branchName.lower():
                return ref.__dict__['object_id']
    
    # returns True if branch is a master branch, else False
    def isMasterBranch(self, branch):
        return self.getBranchName(branch).lower().split('/')[-1] == 'master'

    # returns branch name of a given branch object
    def getBranchName(self, branch):
        return branch.__dict__['name']

    # returns branch id of a given branch object
    def getBranchObjectId(self, branch):
        return branch.__dict__['object_id']

    # create new Azure Devops branch
    def createBranch(self, projectId, repositoryId, masterBranchId, newBranchName):
        refUpdates = []
        refUpdates.append(json.loads('{"name":"refs/heads/' + newBranchName + '","repository_id":"' + repositoryId + '" , "old_object_id":"0000000000000000000000000000000000000000", "new_object_id":"' + masterBranchId + '"}'))
        return self.git_client.update_refs(project_id=projectId, repository_id=repositoryId, ref_updates=refUpdates) 

    # retruns True is a given item path is already exist on a given branch name, else False
    def isItemExist(self, repositoryId, branchName, itemPath):
        versionDescriptor = type('',(), {'version':branchName, 'version_type':'branch', 'version_options':'none'})
        try:
            getItemResponse = self.git_client.get_item(repository_id=repositoryId, 
            include_content_metadata=True, path=itemPath, version_descriptor = versionDescriptor)
            self.log(text='item path ' + getItemResponse.path + ' already exists')
            self.log(text='get item response: ')
            self.log(text=str(getItemResponse) + self.new_line)
            return True
        except VstsServiceError as e:
            if e.type_key == 'GitItemNotFoundException':
                self.log(text="item path " + itemPath + " doesn't exist" + self.new_line)
                return False
            else:
                raise e

    # encode a binary file to the base64 format
    def encodeBinaryFile(self, filePath):
        with open(filePath, "rb") as item:
            bytes = item.read()
            encodedItem = base64.b64encode(bytes).decode('utf-8')
            item.close()

        self.log(text='file encoded to base 64 format. file path: ' + filePath + self.new_line)
        return encodedItem

    # commit changes to Azure Devops
    def commitChanges(self, repositoryId, assetPath, sourceBranchId, sourceBranchName, isBranchExist, nestedFolder):
        commitRequestRawText = '{"refUpdates": [{"name": "{param_branchname}","oldObjectId": "{param_commitid}"}],"commits": [{"comment": "{param_comment}","changes": []}]}'
        changesRequestRawText = '{"changeType": "{param_mode}","item": {"path": "{param_assetpath}"},"newContent": {"content": "{param_assetcontent}","contentType": "base64encoded"}}'
        assets = []
        branchName = sourceBranchName.split('/')[-1]
        if isBranchExist:
            comment = 'auto:: updated ' + branchName + ' branch'
        else:
            comment = 'auto:: added item(s) ' + branchName + ' branch'

        self.log(text='processing file: ' +  assetPath)
        nestedFolder = nestedFolder * -1
        itemPath = '/' + '/'.join(assetPath.split('\\')[nestedFolder:])
        
        self.log(text='Azure Devops item path: ' +  itemPath)
        if self.isItemExist(repositoryId, branchName, itemPath):
            changeType = 'edit'
            itemPathDescription = itemPath + ' - [updated]'
        else:
            changeType = 'add'
            itemPathDescription = itemPath + ' - [added]'

        assets.append(json.loads(changesRequestRawText.replace('{param_mode}', changeType).replace('{param_assetpath}', itemPath).replace('{param_assetcontent}', self.encodeBinaryFile(assetPath))))

        commitRequestJson = json.loads(commitRequestRawText.replace('{param_branchname}', sourceBranchName).replace('{param_commitid}', sourceBranchId).replace('{param_comment}', comment))
        commitRequestJson['commits'][0]['changes'] = assets
        
        response = self.git_client.create_push(repository_id=repositoryId, push=commitRequestJson)
        self.log(text='received commit response:')
        self.log(text=str(response) + self.new_line)
        return response, itemPathDescription

    # create new pull request on Azure Devops
    def createPullRequest(self, projectId, repositoryId, sourceBranchName, targetBranchName, title, description, reviewerList):
        createPullRequestRawText = '{"sourceRefName": "","targetRefName": "","title": "","description": ""}'
        createPullRequestJson = json.loads(createPullRequestRawText)
        createPullRequestJson['sourceRefName'] = sourceBranchName
        createPullRequestJson['targetRefName'] = targetBranchName
        createPullRequestJson['title'] = 'auto:: ' + title
        createPullRequestJson['description'] = description
        createPullRequestJson['completionOptions'] = json.loads('{"deleteSourceBranch": false, "squashMerge": false, "triggeredByAutoComplete" : true}')
        self.log(text='json request of create pull request:')
        self.log(text=json.dumps(createPullRequestJson))

        try:
            createPullRequestResponse = self.git_client.create_pull_request(repository_id=repositoryId, git_pull_request_to_create = createPullRequestJson)
            self.log(text='received pull request response:')
            self.log(text=str(createPullRequestResponse) + self.new_line)
            
            pullRequestId = createPullRequestResponse.pull_request_id
            self.log(text='pull request has been created successfully with id: ' + str(pullRequestId))

            if len(reviewerList) > 0:
                addReviewersToPullRequestResponse = self.git_client.create_pull_request_reviewers(repository_id=repositoryId, pull_request_id=pullRequestId, reviewers=reviewerList)
                
                self.log(text='received pull request with reviewers response:')
                self.log(text=str(addReviewersToPullRequestResponse) + self.new_line)
            else:
                self.log(text='there are no reviewers attached to this pull request')
            # else:
            #     self.log(text='pull request already exists and created by ' + getPullRequestResponse[0].created_by.id + self.new_line)

        except VstsServiceError as e:
            self.log(text='vsts error occurred: ' + str(e))


# main thread
if __name__ == "__main__":
    print('Running main function...')
    