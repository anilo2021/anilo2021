####################################################################################################
# Name:                 cognostoazuredevops.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/azuredevops/cognostoazuredevops.vsdx
# Command line usage:   python cognostoazuredevops <log_file_name> <export_file_name> <requested_by_email> <is_pr_required>
# Purpose:              Imports report/package from DFS(network drive) to Azure DevOps "Cognos" repository
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-03-26 Sanju Joseph (sanj827@kellyservices.com)       Original Author
# 2019-07-29 Sanju Joseph (sanj827@kellyservices.com)       Major logic version
####################################################################################################

# library imports
import datetime
import json
import os
import sys
from pathlib import Path
import zipfile
from xml.etree import ElementTree

# local module imports
from azuredevops.azuredevopssession import azureDevopsSession

# get all directory names of given path
def getDirectories(path):
    for _, dirnames, _ in os.walk(path):
        return dirnames

# create directory if directory doesn't exist and returns directory path 
def checkAndCreateDirectory(devops, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                devops.log(text="created new directory name: " + eachDirectory)
            except OSError:
                devops.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath

# get all file names of given path
def getFileNames(path):
    for _, _, filenames in os.walk(path):
        return filenames

# get all sub-directories
def getSubdirectoryPaths(path):
    dirPaths = []
    for directory in getDirectories(path):
        subDir = os.path.join(path, directory)
        for projectDir in getDirectories(subDir):
            dirPaths.append(os.path.join(path, directory, projectDir))
        
        if subDir not in dirPaths:
            dirPaths.append(subDir)

    return dirPaths                

# create directory inside archive directory 
def createFeatureDirectoryInArchive(devops, archivePath, object_type, featureDirectory):
    archiveDirArray = []
    archiveDirArray.append(object_type)
    archiveDirArray.append(featureDirectory + '_' + getCurrentTimeStamp())
    return checkAndCreateDirectory(devops, archivePath, archiveDirArray)

# get current date time stamp
def getCurrentTimeStamp():
    return datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')

# provide pull request reviewer list
def getReviewerList(config, iicsProjectName):
    reviewerList =[]
    for id in str(config['iics']['reviewers'][iicsProjectName]).split(','):
        if len(id) > 0:
            reviewerList.append(json.loads('{"id":"' + id.strip() + '"}'))

    return reviewerList

# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# send an email
def sendEmail(session, emailAddress, subject, body, isSuccess=False, attachment=None):
    if emailAddress is not None and emailAddress.strip() != '':
        recipients = []
        recipients.append(emailAddress)
        
        config = getConfiguration(session)
        emailDefaultRecipients = config['emaildefaultrecipients']
        sendEmailToRecipientsOnSuccess = config['sendemailtorecipientsonsuccess']

        if (not isSuccess) or (isSuccess and sendEmailToRecipientsOnSuccess):
            for email in emailDefaultRecipients.split(','):
                recipients.append(email.strip())

        try:
            body = convert_plaintext_to_html(body)
            with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_iicsexport.html') as template:
                emailbody = template.read().format(body)

            session.email(subject, emailbody, attachment=attachment, recipients=recipients)
        except Exception as emailException:
            session.log(text="error occurred while sending email. Error details: " + str(emailException))

def extract_from_zip_file(devops, zip_file_path):
    file_list=[]
    zip_file = zipfile.ZipFile(zip_file_path)
    devops.log(text='extracted ' + str(os.path.basename(zip_file_path)) + ' file')
    file_list.extend(zip_file.namelist()) 
    zip_file.close()

    return file_list

def get_export_type(export_type):
    package_name = 'package'
    report_name = 'report'
    folder_name = 'folder'

    export_type = str(export_type).lower()
    if export_type == package_name:
        return package_name
    elif export_type == folder_name:
        return report_name

def createReportInfoFile(devops, log_file_contents, export_report_path, export_folder_name, xml_file_name, emailNotificationLabel, email_address):
    # object_type = ''
    
    # for each_line in log_file_contents:
    #     if each_line.strip().lower().startswith('- added folder to deployment:'):
    #         object_type = get_export_type(str(each_line.split(':')[1].strip().lower().split('/')[-1].split('[')[0]))
    #         break
    object_type = os.path.basename(os.path.split(export_report_path)[0])
    report_info_file = export_report_path.replace('.zip','.txt')
    
    with open(report_info_file, 'w+') as filehandle:
        filehandle.write(emailNotificationLabel + ': ' + email_address + '\n')
        filehandle.write('Zip file name: ' + export_report_path.split('\\')[-1] + '\n')
        filehandle.write('Zip file contents:' + '\n')
        
        file_list = extract_from_zip_file(devops, export_report_path)

        for file_name in file_list:
            filehandle.write('\t%s\n' % file_name)

        filehandle.write('File size: ' + str(os.stat(export_report_path).st_size/1024.0) + ' KB')
        filehandle.write('\n\n')
        filehandle.writelines(log_file_contents)
        filehandle.close()

    devops.log(text='export report info file path: ' + report_info_file)

    return report_info_file, object_type

# get log file contents
def get_log_file_contents(log_file_path):
    log_file_lines = []
    file_contents = []
    is_started = False
    with open(log_file_path) as vbs_log_handler:
        log_file_lines.extend(vbs_log_handler.readlines())
        vbs_log_handler.close()

    for each_line in log_file_lines:
        if each_line.strip().lower().startswith('deployment type:'):
            is_started = True
        
        if is_started == True and each_line.strip().lower().startswith('successfully logged off user from cognos.'):
            is_started = False

        if is_started:
            file_contents.append(each_line)
    
    return file_contents

# get Azure DevOps configuration
def getConfiguration(session):
    with open(session.repoDirectory/'azuredevops'/'azuredevops-config.json') as configFile:
        return json.load(configFile)

# process Cognos object to Azure Devops branch
def processCognostoAzureDevops(devops, config, failure_email_subject, log_file_contents, export_report_path, requested_by, ispullrequest_required):
    env = devops.env
    log_file_path = str(devops.logFileName)
    
    deployment_path = config['cognos']['dfsserverpath']+'\\'+config['cognos']['deployment_path']
    export_folder_name = config['cognos']['export_report_path']
    export_file_path = deployment_path+'\\' + export_folder_name
    archivePath = export_file_path+'\\'+config['cognos']['archive_path']
    pullRequestEnabled = config['cognos']['pullrequestenabled']
    xml_file_name = config['cognos']['xml_file_name']
    email_notification_label = config['cognos']['email_notification_label']
    project_id = config['project_id']
    repository_id = config['cognos']['repository_id']
    file_name_starts_with = config['cognos']['feature_directory_name_starts_with']

    branches = devops.getBranches(repository_id)
    
    devops.log(text='export was requested by: ' + requested_by)
    # export_report_path = str(os.path.join(deployment_path, export_report_path))

    if not os.path.exists(export_report_path):
        error_message = "Requested file didn't export. Please check the attached log file."
        devops.log(text=error_message)
        sendEmail(devops, requested_by, failure_email_subject, error_message, isSuccess=False, attachment=str(log_file_path))
        return

    devops.log(text='export report file path: ' + export_report_path)
    report_info_file, object_type = createReportInfoFile(devops, log_file_contents, export_report_path, export_folder_name, xml_file_name, email_notification_label, requested_by)
    
    try:
        is_branch_exist = False
        zip_file_name = str(os.path.basename(export_report_path))
        current_branch_name = file_name_starts_with + zip_file_name[:-4].replace(' ','_')
        
        for branch in branches:
            branch_name = devops.getBranchName(branch)
            branch_id = devops.getBranchObjectId(branch)
            # get master branch id
            if devops.isMasterBranch(branch):
                master_branch_id = branch_id
            # check if branch exists then get branch id 
            if branch_name.lower().split('/')[-1] == current_branch_name.lower():
                source_branch_name = branch_name
                source_branch_id = branch_id
                is_branch_exist = True

        # if branch doesn't exist then create branch and retrieve new branch id        
        if not is_branch_exist:
            devops.log(text="'" + current_branch_name + "' branch doesn't exist, hence creating a new branch")
            createBranchResponse = devops.createBranch(project_id, repository_id, master_branch_id, current_branch_name)
            source_branch_name = createBranchResponse[0].name
            source_branch_id = createBranchResponse[0].new_object_id
        else:
            devops.log(text="'" + current_branch_name + "' branch already exists")

        # create archive directory and sub-directories
        featureDirectoryArchivePath = createFeatureDirectoryInArchive(devops, archivePath, object_type, current_branch_name)
        
        # returns all report objects path
        assetPaths = []
        assetPaths.append(export_report_path)
        assetPaths.append(report_info_file)
        
        itemPaths = []
        # committing asset changes one by one on Azure Devops above selected branch
        for assetPath in assetPaths:
            devops.log(text='asset path: ' + str(assetPath))
            _, itemPath = devops.commitChanges(repository_id, assetPath, source_branch_id, source_branch_name, is_branch_exist, 2)
            source_branch_id = devops.getBranchId(repository_id, source_branch_name)
            itemPaths.append(itemPath)
            try:
                # moving asset to archive directory
                itemPathArray = assetPath.split('\\')
                newAssetPath = os.path.join(featureDirectoryArchivePath, itemPathArray[-1])
                os.rename(assetPath, newAssetPath)
                devops.log(text='Object has been moved to archive directory with file name: ' + os.path.basename(newAssetPath) + '\n')
            
            except Exception as movingToArchiveException:
                devops.log(text='Exception occurred while moving object to archive. Exception details: ' + str(movingToArchiveException))  
        
        if len(assetPaths) != 0:
            devops.log(text='commited all changes successfully')
            
            pullReqTitle = 'Added/updated files on ' + current_branch_name + ' branch'
            description = pullReqTitle
            
            # create pull request on Azure Devops if pull request is enabled and it's requested by user
            if pullRequestEnabled and ispullrequest_required:
                devops.log(text='creating pull request...')
                devops.createPullRequest(project_id, repository_id, source_branch_name, config['cognos'][env]['targeted_branch_name'], pullReqTitle, description, [])

        subject = 'Azure DevOps | Cognos | Success'
        body = "Requested file changes have been committed to Azure DevOps branch '" + current_branch_name + "' successfully. \r\n " + "Following are the committed file(s) details: " + " \r\n\t" + "\r\n\t".join(itemPaths)
        sendEmail(devops, requested_by, subject, body, isSuccess=True)
    except Exception as exceptionOnFeatureDirectory:
        devops.log(text='Exception occurred. Eception details: ' + exceptionOnFeatureDirectory.args[0])
        body = 'An error occurred while processing requested file changes on Azure Devops branch name ' + current_branch_name + '. Please check the attached log file.'
        sendEmail(devops, requested_by, failure_email_subject, body, isSuccess=False, attachment=str(devops.logFileName))


def is_pull_request_required():
    ispullrequest_required = False
    if len(sys.argv) == 5:
            if sys.argv[4] == '1':
                ispullrequest_required = True
    
    return ispullrequest_required

def delete_extra_log_file(session):
    extraLogFilePath = str(session.logFileName)
    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as _:
        print("couldn't able to delete extra log file: " + extraLogFilePath)


def process(session):
    log_file_name = sys.argv[1]
    export_report_name = sys.argv[2]
    requested_by = sys.argv[3]
    ispullrequest_required = is_pull_request_required()
    
    config = getConfiguration(session)
    export_file_path = config['cognos']['dfsserverpath']+'\\'+config['cognos']['deployment_path'] + '\\' + config['cognos']['export_report_path']
    log_file_path = export_file_path+'\\'+config['cognos']['log_path'] +'\\' + log_file_name
    failure_email_subject = 'Azure DevOps | Cognos | Error'

    export_report_name = export_file_path + '\\' + export_report_name

    session.logFileName = log_file_path
    
    if os.path.exists(log_file_path):
        log_file_contents = get_log_file_contents(log_file_path)
        
        session.log(text='\n\n===================LOG DETAILS OF PYTHON CODE====================\n')
        session.log(text='log file name: '+log_file_name)
        session.log(text='export file name: '+ str(os.path.basename(export_report_name)))
        session.log(text='requested by: '+requested_by)
        session.log(text='pull request: '+str(ispullrequest_required))

        processCognostoAzureDevops(session, config, failure_email_subject, log_file_contents, export_report_name, requested_by, ispullrequest_required)
    else:
        error_message = "Couldn't able to find the log file name: " + str(os.path.basename(log_file_path) + " created by Java")
        log_file_handler = open(log_file_path, 'w+')
        log_file_handler.close()
        session.log(text=error_message + ', hence created this log file to log the error.')
        sendEmail(session, requested_by, failure_email_subject, error_message, isSuccess=False)

# main thread
if __name__ == "__main__":
    print('Running...')
    
    try:
        sessionContainer = {}
        sessionContainer['azuredevops'] = azureDevopsSession(os.path.basename(__file__)[:-3], taskName='')
        delete_extra_log_file(sessionContainer['azuredevops'])

        process(sessionContainer['azuredevops'])

        print('Script execution complete')
    except Exception as e:
        if os.path.exists(str(sessionContainer['azuredevops'].logFileName)):
            sessionContainer['azuredevops'].error(e)
        else:
            print('Exception occurred: '+str(e))
    