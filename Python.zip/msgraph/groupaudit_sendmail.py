####################################################################################################
# Name:                 groupaudit_sendmail.py
# Python version:       Python 3.6.4
# Diagram Path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/msgraph/groupaudit-sendmail.vsdx
# Command line usage:   python start.py groupaudit_sendmail [startaudit, defaultreminder, esclatereminder, closeaudit]
# Purpose:              Sends notification emails to group owners requesting them to complete Group Audit;
#                       Notification level is adjusted by parameters 
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-07-28 H. Maddipati (harm344@kellyservices.com)      Original Author
# 2022-02-08 H. Maddipati (harm344@kellyservices.com)      bcc owners; Modified email context
####################################################################################################

# library imports
import json
import io
from pathlib import Path
import sys
import pandas as pd
import datetime
import string
import random
# local module imports
from mssharepoint.sharepointsession import sharepointSession
from msgraph.graphsession import graphSession
from alerts.alertssession import alertsSession

def auditgroupSendmail(session,mailType):
    # Database connection
    auditConfig = session.scriptConfig
    conn = session.getDatabaseConnection(auditConfig['Database'])  
    excludeMembers = auditConfig['excludeUpn'] # To exclude members from getting audit emails
    session.log(text="Exclude emails (members that do not need to audit): {}".format(excludeMembers))
    # Get Current running campaign
    campaignTableDF = pd.read_sql("SELECT * FROM {}".format(auditConfig['tables']['campaignTable']),conn)
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    todayInt = int(datetime.datetime.now().strftime("%Y%m%d"))
    currentCampaignData = campaignTableDF[(todayInt >= campaignTableDF['startDateInt']) & (campaignTableDF['endDateInt'].isnull() )] # If campaign start date is given and end date is not specified
    if len(currentCampaignData)>0:
        currentCampaign = currentCampaignData['id'].values[0]
        session.log(text="Current campaign: {}".format(currentCampaign))
    else:
        raise Exception("There is no active campaign")
    # Get all owners from SQL table
    ownersDF = pd.read_sql("select distinct first,last,memberId,userPrincipalName,isDeleted,campaignId from {} where owner = 1 AND isDeleted='False' AND campaignId='{}' ".format(auditConfig['tables']['membersTable'],currentCampaign),conn)
    ownersDF = ownersDF.set_index('memberId')
    # Get owners that did not audit
    membersUpn = unrespondedOwners(ownersDF,currentCampaign,excludeMembers,conn,auditConfig) 
    # If argument = startaudit, Sends PowerApps link to all current group owners.
    if mailType=='startaudit':
        # Email to Owners: Link to PowerApps
        with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sendmail.html') as template:
            dataInserts= {
                "subjectLine": "Audit the security Groups using PowerApps ",
                "powerAppsLink": auditConfig['powerAppLink'],
                "ownershipDocument": auditConfig['ownershipDocument'],
                "contactMail": auditConfig['emailRecipients']['notification']['html'][0],
                "pictureName": auditConfig['instructionPicture'].split('/')[-1],
                "instructionVideo": auditConfig['instructionVideo']
            }
            session.graphEmail( body=template.read().format(**dataInserts),
                                recipients=auditConfig['emailRecipients']['notification']['html'],
                                bcc=membersUpn,
                                attachment=str(session.repoDirectory/'common'/'emailTemplates') + str(Path(auditConfig['instructionPicture'])))
    
    # If argument = defaultreminder, Check if all owners compelted their audit.
    if mailType=='defaultreminder': 
        # Send mail to owners who have not responded
        if not membersUpn:
            # If membersUpn is empty: All members audited their groups, we close the campaign
            closeCampaign(session,auditConfig,today,currentCampaignData,conn,membersUpn,"All owners have responded. Campaign has been closed")
            session.log(text="All owners have audited. Campaign has been closed ")
        else:
            # Email is sent to Group Owners that still need to complete the audit
            with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sendmail.html') as template:
                dataInserts= {
                        "subjectLine": "This is a reminder, please complete audit process at your earliest.",
                        "powerAppsLink": auditConfig['powerAppLink'],
                        "ownershipDocument": auditConfig['ownershipDocument'],
                        "contactMail": auditConfig['emailRecipients']['notification']['html'][0],
                        "pictureName": auditConfig['instructionPicture'].split('/')[-1],
                        "instructionVideo": auditConfig['instructionVideo']
                    }
                session.graphEmail( body=template.read().format(**dataInserts),
                                    recipients=auditConfig['emailRecipients']['notification']['html'],
                                    bcc=membersUpn,
                                    attachment=str(session.repoDirectory/'common'/'emailTemplates') + str(Path(auditConfig['instructionPicture']))) 
            session.log(text="Owners that must audit {}".format(membersUpn))

    # If argument = escalatereminder, Check if all owners compelted their audit.
    if mailType=='escalatereminder': 
        # Send mail to owners who have not responded and their managers
        if not membersUpn:
            # If membersUpn is empty: All members audited their groups, we close the campaign
            closeCampaign(session,auditConfig,today,currentCampaignData,conn,membersUpn,"All owners have responded. Campaign has been closed")
            session.log(text="All owners have audited. Campaign has been closed ")
        else:
            # Get manager
            for user in membersUpn:
                manager = session.graphGetManager(user)
                # Email is sent to Group Owners that still need to complete the audit
                with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sendmail.html') as template:
                    dataInserts= {
                            "subjectLine": "This is an escalated reminder for "+"<b>"+""+user+""+"</b>"+", please complete the audit process. (cc Manager: "+ manager['displayName'] +", "+manager['userPrincipalName']+"). "+"<br \>"+" "+ manager['displayName'] +", please ensure that the group owner completes the audit.",
                            "powerAppsLink": auditConfig['powerAppLink'],
                            "ownershipDocument": auditConfig['ownershipDocument'],
                            "contactMail": auditConfig['emailRecipients']['notification']['html'][0],
                            "pictureName": auditConfig['instructionPicture'].split('/')[-1],
                            "instructionVideo": auditConfig['instructionVideo']
                        }
                    session.graphEmail( body=template.read().format(**dataInserts),
                                        recipients=[user,manager['userPrincipalName']],
                                        attachment=str(session.repoDirectory/'common'/'emailTemplates') + str(Path(auditConfig['instructionPicture']))) 
            session.log(text="Owners that must audit {}".format(membersUpn))
    
    # If argument = closeaudit, Force close the campaign
    if mailType=='closeaudit':
        session.log(text="Force closing campaign {}".format(currentCampaign))
        closeCampaign(session,auditConfig,today,currentCampaignData,conn,membersUpn,"Stopping current campaign.")
        session.log(text="Owners that did not complete auditing {}".format(membersUpn))


def closeCampaign(session,auditConfig,today,currentCampaignData,conn,unresponded,note): # Close Campaign in SQL talbe and send mail to AIM infrastructure
    session.log("Ending Campaign")
    cursor = conn.cursor()    
    updateQ = "UPDATE {} SET endDate='{}' Where id='{}' ".format(auditConfig['tables']['campaignTable'],today, currentCampaignData['id'].values[0])
    cursor.execute(updateQ)
    session.log(updateQ)
    conn.commit()
    # Email is sent to AIM INFRA
    with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sendmail_campaign.html') as template:
        lineEnd = ["None"] if not unresponded else unresponded
        dataInserts = {
            "subjectLine": note,
            "campaignId": str( currentCampaignData['id'].values[0]),
            "start": str(currentCampaignData['startDate'].values[0])[0:10] ,
            "end":today,
            "ownersList": "<li>".join(lineEnd)  
        }
        session.graphEmail(body=template.read().format(**dataInserts),recipients=auditConfig['emailRecipients']['notification']['html']) 

def unrespondedOwners(ownersDF,currentCampaign,excludeMembers,conn,auditConfig):
    # Database cursor
    cursor = conn.cursor()
    toSend = []
    # Check if each owner has audited all thier groups 
    for ownerId in ownersDF.index:
        # Get count of total groups the owner needs to audit
        cursor.execute("select COUNT(*) from {} where memberId = '{}' AND owner=1 AND isDeleted='False' AND campaignId='{}'".format(auditConfig['tables']['membersTable'],ownerId,currentCampaign))
        Totalcount = cursor.fetchone()[0]
        # Get groups that were already audited for a particular owner
        cursor.execute("select COUNT(*) from {} where campaignId = '{}' AND ownerId='{}'".format(auditConfig['tables']['auditResponseTable'],currentCampaign,ownerId))
        auditCount = cursor.fetchone()[0]
        # Modifying Dataframe
        ownersDF.loc[ownerId,"TotalGroups"] = Totalcount
        ownersDF.loc[ownerId,"AuditedGroups"] = auditCount 
    for index,row in ownersDF.iterrows():
        # If owner has not audited all of their groups, send a reminder
        if row["TotalGroups"] != row["AuditedGroups"]: 
            toSend.append(row['userPrincipalName'])
    # Remove excluded members
    toSend = [upn for upn in toSend if upn not in excludeMembers]
    # Filter in betaTesters if they exist
    # toSend = [upn for upn in toSend if upn in auditConfig['betaTesters']]
    return toSend


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['msgraph'] = graphSession(Path(__file__).stem,taskName=('_'.join(sys.argv[1:3])).replace(' ', '_'))
    try:
        if not (sessionContainer['msgraph'].login()):
            sessionContainer['msgraph'].log('Login error - aborted')
        else:
            sessionContainer['msgraph'].log('Login Complete')
            mailType = sys.argv[1].lower()
            sessionContainer['msgraph'].log("Mail Type argument selected: "+ mailType)
            if len(sys.argv)>1 and (mailType=='startaudit' or mailType=='defaultreminder' or mailType=='escalatereminder' or mailType=='closeaudit'): 
                auditgroupSendmail(sessionContainer['msgraph'],mailType)
            else:
                raise Exception("Input argument needs to be 'startaudit' or 'defaultreminder' or 'escalatereminder' or 'closeaudit'")
    except Exception as e:
        sessionContainer['msgraph'].graphError(e,email=sessionContainer['msgraph'].scriptConfig['errorNotification'])