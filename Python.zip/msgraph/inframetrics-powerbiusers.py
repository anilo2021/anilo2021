####################################################################################################
# Name:                 inframetrics-powerbiusers.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msgraph/inframetrics-powerbiusers.vsdx
# Command line usage:   python start.py inframetrics-powerbiusers <groupName>
# Purpose:              Query Azure AD for member of Power BI user groups, then load results into a CSV
#                       that is uploaded to SharePoint
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-07-09 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import csv
import datetime
import json
from pathlib import Path
import sys
# local module imports
from msgraph.graphsession import graphSession
from mssharepoint.sharepointsession import sharepointSession

# function for testing Azure Graph methods of azureWrapper
def powerBiUsersRefresh(session):
    # set default local and SharePoint paths for CSV file
    csvFilePath = session['msgraph'].directory/'upload'/'PwrBiProUsers.csv'
    csvSharepointPath = '/pwrBiDataSorces/PwrBiProUsers.csv'
    # load groups ref JSON
    groupRef = json.load(open(session['msgraph'].configDirectory/('graph-powerbigroups.json')))
    # get list of members the relevant groups and save to JSON file
    userList = {}
    for group in groupRef:
            userList[group['name']] = session['msgraph'].graphGroupMembersList(group['id'])
    # record member results as JSON for logging
    jsonFileTimestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
    session['msgraph'].createJsonFile('userlists/usersList_'+jsonFileTimestamp+'.json', userList)
    # if new, create CSV from scratch
    SharePointCheckList = session['mssharepoint'].fileGetInFolder('/'.join(csvSharepointPath.split('/')[:-1])).json() # sic
    if not any([True for f in SharePointCheckList['d']['Files']['results'] if f['Name'] == 'PwrBiProUsers.csv']):
        # open new CSV file
        csvFilePath.parent.mkdir(parents=True, exist_ok=True)
        with open(csvFilePath, 'w', newline='') as csvFile:
            csvWrite = csv.writer(csvFile, delimiter=',')
            # write header line
            csvWrite.writerow(['Group', 'Name', 'User Principal', 'AIM Classification'])
            # generate rows of CSV using Graph user data
            for group in userList:
                for user in userList[group]:
                    csvWrite.writerow([group, user['displayName'], user['userPrincipalName'], ''])
    # if not new, perform upsert into existing CSV  
    else:
        # download current CSV from SharePoint
        session['msgraph'].log(text='Downloading SharePoint file '+csvSharepointPath+' to script folder')
        downloadPath = session['mssharepoint'].fileDownload(csvSharepointPath) # defaults to 'download' subfolder
        # get current data from CSV to compare against
        with open(downloadPath, 'r', newline='') as csvRead:
            currentData = list(csv.reader(csvRead, delimiter=','))
        # use user principal and group as a composite key
        keyColumn = [[row[0], row[2]] for row in currentData]
        # iterate through user list over CSV
        newRows = [] # cache for any new rows that need to be written
        for group in userList:
            for user in userList[group]:
                # insert records that do not exist already
                if [group, user['userPrincipalName']] not in keyColumn:
                    # add new row to cache
                    session['msgraph'].log(text='New '+group+' member: '+user['userPrincipalName'])
                    newRows.append([group, user['displayName'], user['userPrincipalName'], ''])
                # update records that do already exist
                else:
                    # update row of CSV that pertains to the given user of a given group
                    i = keyColumn.index([group, user['userPrincipalName']])
                    currentData[i] = [group, user['displayName'], user['userPrincipalName'], currentData[i][3]]
                    # null entry in keyColumn because it's already dealt with
                    keyColumn[i] = None
        # if group members in CSV not returned by Graph, delete from CSV Data
        for i in range(1, len(keyColumn)): # ignore header row
            # since keyColumn is being trimmed, compare cursor to current length of keyColumn
            if i >= len(keyColumn):
                break
            # delete entry from keyColumn and currentData
            if keyColumn[i] is not None:
                session['msgraph'].log(text='Removing group '+keyColumn[i][0]+' member '+keyColumn[i][1]+' from CSV')
                del currentData[keyColumn.index(keyColumn[i])]
                del keyColumn[keyColumn.index(keyColumn[i])]
        # add new rows to bottom of current rows
        newData = currentData+newRows
        # write new version of data to CSV (overwrites downloaded version of file)
        csvFilePath.parent.mkdir(parents=True, exist_ok=True)
        with open(csvFilePath, 'w', newline='') as csvWrite:
            writer = csv.writer(csvWrite, delimiter=',')
            for row in newData:
                writer.writerow(row)
    # upload CSV to SharePoint
    session['mssharepoint'].fileUpload(csvSharepointPath, csvFilePath)

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['msgraph'] = graphSession(Path(__file__).stem, 'update')
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem, '', logFileName=sessionContainer['msgraph'].logFileName, args=['aim_infra'])
    try:
        if not (sessionContainer['msgraph'].login() and sessionContainer['mssharepoint'].login()):
            print('Login error - aborted')
        else:
            powerBiUsersRefresh(sessionContainer)
    except Exception as e:
        sessionContainer['msgraph'].graphError(e)