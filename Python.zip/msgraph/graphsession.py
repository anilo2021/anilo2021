####################################################################################################
# Name:                 graphsession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/27/graphsession
# Command line usage:   N/A
# Purpose:              Class contains methods for Microsoft Graph API automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-07-09 J. Rominske (jesr114@kellyservices.com)      Original Author
# 2021-07-28 H. Maddipati (harm344@kellyservices.com)     Added API methods and getDatabaseConnection
# 2022-02-08 H. Maddipati (harm344@kellyservices.com)     Bcc parameter added to graphEmail.   
####################################################################################################

# library imports
import json
from pathlib import Path
import requests
import sys
import sqlalchemy

# local module imports
from common.session import session
# python ODBC
import pyodbc

# session subclass with methods relevant to Azure Data Warehouse Automation  
class graphSession(session):
    # specific initialization method
    def _setup(self):
        self.directory = self.repoDirectory/'msgraph'
        # load stored credentials from JSON file
        self.azureCreds = json.load(open(self.secureDirectory/(self.env+'_azurecreds.json')))
        # session variables for Azure API interface
        self.loginUrl = "https://login.microsoftonline.com/{}/oauth2/token".format(self.azureCreds['tenantId']) # login URL for the Azure API Service
        self.graphUrl = 'https://graph.microsoft.com' # URL for Microsoft Graph
        self.hdrs = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        self.req = requests.Session()

    # method for sending emails specific to Azure
    def graphEmail(self, body, attachment=None, recipients=None, bcc=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_msgraph.html') as template:
            self.email(subject='Notification from the AIM Active Directory Automation System', 
                       body=template.read().format(body), # replace "{}" in template file with values
                       recipients=recipients,
                       attachment=attachment,
                       bcc=bcc) # call basic email function

    # method to send error report email for Azure
    def graphError(self, error, email=True):
        errorCode = self.error(error, exit=False) 
        if email:
            self.log(text='Sending error notification email...')
            self.graphEmail('An error occurred with code: '+str(errorCode)+'\nPlease check the logs.')
        sys.exit(errorCode)

    # session method for logging into Microsoft Graph
    def login(self, principal=None):
        if principal is not None:
            principal = {
                'type': 'ServicePrincipal',
                'label': 'ACE'
            }
            creds = self.azureCreds[principal['type']][principal['label']+'_'+self.env]
        else:
            creds = self.azureCreds
        loginData = {
            'grant_type': 'client_credentials',
            'client_id': creds['clientId'],
            'client_secret': creds['clientSecret'],
            'resource': self.graphUrl,
            'scope': self.graphUrl+'.default'
        }
        response = self.req.post(self.loginUrl, headers=self.hdrs, data=loginData)
        if response.status_code == 200 : 
            self.log(text='Login Success')
            self.hdrs['Authorization'] = "Bearer "+response.json()['access_token']
            self.hdrs['Content-Type'] = 'application/json'
            self.hdrs['Accept'] = 'application/json;odata.metadata=minimal;odata.streaming=true;IEEE754Compatible=true'
            return True
        else:
            self.log(text='Login Failed')
            self.log(text=response.text)
            return False

    def getDatabaseConnection(self,dbName,connType=None):
        dbCreds = json.load(open(self.secureDirectory/(self.env+'_dbcreds.json'))) # import db creds json
        if connType=='sqlalchemy':
            creds = dbCreds[dbName]
            # switch object structure based on given dbType
            if creds['dbType'] == 'Microsoft':
                if 'dsn' in creds:
                    engine = sqlalchemy.create_engine(
                        'mssql+pyodbc://{user}:{password}@{dsn}'.format(
                            user=creds['userId'],
                            password=creds['passwd'],
                            dsn=creds['dsn']))
                else:
                    engine = sqlalchemy.create_engine(
                        'mssql+pyodbc://{user}:{password}@{server}/{dbName}?driver={driver}'.format(
                            user=creds['userId'],
                            password=creds['passwd'],
                            server=creds['server'],
                            dbName=creds['dbName'],
                            driver=creds['driver'].replace(' ', '+')))
            elif creds['dbType'] == 'Teradata':
                engine = sqlalchemy.create_engine(
                    'teradatasql://{user}:{password}@{dbcName}'.format(
                        user=creds['userId'],
                        password=creds['passwd'],
                        dbcName=creds['dbName']))
            elif creds['dbType'] == 'Oracle':
                engine = sqlalchemy.create_engine(
                    'oracle+cx_oracle://{user}:{password}@{dbq}'.format(
                        user=creds['userId'],
                        password=creds['passwd'],
                        dbq=creds['dbq']))
            elif creds['dbType'] == 'Snowflake':
                engine = sqlalchemy.create_engine(
                    'snowflake://{user}:{password}@{account}'.format(
                        user=creds['userId'],
                        password=creds['passwd'],
                        account=creds['dbName']))
        else:
            dbConnection = {
                'server' : dbCreds[dbName]['server'],
                'database' :  dbCreds[dbName]['database'],
                'username' :dbCreds[dbName]['username'],
                'password' : dbCreds[dbName]['password'],   
                'driver': dbCreds[dbName]['driver']
            }
            engine = pyodbc.connect('DRIVER='+dbConnection['driver']+';SERVER='+dbConnection['server']+';PORT=1433;DATABASE='+dbConnection['database']+';UID='+dbConnection['username']+';PWD='+ dbConnection['password'])
        return engine

    # method to run query defined in a given file provided with appropriate params
    def executeSqlFile(self, fileName, cursor=None, params=(), commit=False):
        # use session cursor by default
        if not cursor:
            cursor = self.cursor
        # open file from sql directory and execute contents on cursor
        with open(self.directory/'sql'/fileName) as q:
            # fill in param markers with values, unpacking lists if needed
            query = q.read().format(*params) if isinstance(params, (list, tuple)) else q.read().format(params)
            try: 
                self.log(text='Executing SQL from '+fileName+':\n'+query+'\n')
                cursor.execute(query)
            except Exception as e:
                self.error(e)
        # commit to the db if specified
        if commit:
            cursor.commit()

    # generic method for using resource methods
    def _doAPI(self, reqType, apiVersion, method, jsonData={}, headers=None, prev=None, paramDict=None):
        url = self.graphUrl+'/'+apiVersion+'/'+method
        if not headers:
            headers = self.hdrs
        if paramDict is not None and any([paramDict[p] for p in paramDict]):
            # parse paramDict into equality statements
            paramList = []
            for param in paramDict:
                # append only if value of the param is not None
                if paramDict[param] is not None:
                    paramList.append('$'+param+'='+str(paramDict[param]))
            # append params to URL
            url += '?'+('&'.join(paramList))
        self.log(text='\tAccessing API resource at '+url)
         # perform GET request (with pagination) if applicable
        if reqType == 'GET':
            # get initial result, ordered by display name
            result = self.req.get(url, headers=headers).json()
            resultList = result['value'] if 'value' in result else result
            # base case - return result
            if len(resultList) < 100:
                return resultList
            # pagination logic
            elif len(resultList) == 100:
                # if nextlink provided, use it to finish list
                if '@odata.nextLink' in result:
                    while '@odata.nextLink' in result:
                        result = self.req.get(result['@odata.nextLink'], headers=headers).json()
                        resultList = resultList+result['value']
                    return resultList
                # if nextlink not provided, return result
                else:
                    return result['value']
        # perform POST request if applicable
        if reqType == 'POST':
            return self.req.post(url, headers=headers, json=jsonData)
        # perform PATCH request if applicable
        elif reqType == 'PATCH':
            return self.req.patch(url, headers=headers, json=jsonData)
        # perform PUT request if applicable
        elif reqType == 'PUT':
            return self.req.put(url, headers=headers, json=jsonData)
        # perform DELETE request if applicable
        elif reqType == 'DELETE':
            return self.req.delete(url, headers=headers)

    # graph add user to group
    def graphAddGroupMember(self,groupId,body):
        return self._doAPI('POST','v1.0','groups/{}/members/$ref'.format(groupId),jsonData=body)
    # graph remove user from group
    def graphRemoveGroupMember(self,groupId,userId):
        return self._doAPI('DELETE','v1.0','groups/{}/members/{}/$ref'.format(groupId,userId))
    # graph get manager
    def graphGetManager(self,upn):
        return self._doAPI('GET', 'v1.0', 'users/'+upn+'/manager')
    # graph groups list
    def graphGroupsList(self):
        return self._doAPI('GET', 'v1.0', 'groups?$orderby=displayName DESC')
    # graph group details
    def graphGroupInfo(self,id):
        return self._doAPI('GET', 'v1.0', "groups/{}".format(id))
    #  # gets list of members of a group
    def graphGroupMembersList(self, groupName,filters=None):
        return self._doAPI('GET', 'v1.0', 'groups/'+groupName+'/members',paramDict={'select':filters})
    # get app role assignments for a group
    def graphGroupAppRoleAssignments(self, groupId):
        return self._doAPI('GET', 'v1.0', 'groups/'+groupId+'/appRoleAssignments')
    # gets list of owners of a group
    def graphGroupOwnersList(self, groupName,filters=None):
        return self._doAPI('GET', 'v1.0', 'groups/'+groupName+'/owners',paramDict={'select':filters})
    # get user details
    def graphUserDetails(self, userId,filters=None):
        return self._doAPI('GET', 'v1.0', 'users/'+userId,paramDict={'select':filters})
    # get app role assignments for a user
    def graphUserAppRoleAssignments(self, userId):
        return self._doAPI('GET', 'v1.0', 'users/'+userId+'/appRoleAssignments')
    # graph objects owned by a user
    def ownedObjects(self,userId):
        return self._doAPI('GET', 'v1.0', "users/"+userId+"/ownedObjects")


# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    G = graphSession(Path(__file__).stem, 'test')
    try:
        if not G.login():
            print('Login error - aborted')
        else: 
            G.log(text='Class compile test complete')
            print('Script execution complete')
    except Exception as e:
        G.error(e)