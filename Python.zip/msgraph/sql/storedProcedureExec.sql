-- execute a stored procedure with provided name
EXEC {};