CREATE PROCEDURE delete_msgraph_groups
AS
BEGIN
DELETE from msgraph.groups 
WHERE 
	NOT EXISTS 
	(SELECT null from msgraph.stg_groups as [stage] 
		where 
		msgraph.groups.Id=[stage].Id
	)
END