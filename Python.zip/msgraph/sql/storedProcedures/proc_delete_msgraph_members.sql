CREATE PROCEDURE delete_msgraph_members
AS
BEGIN
DELETE from msgraph.members
WHERE 
	NOT EXISTS 
	(SELECT null from msgraph.stg_members as [stage] 
		where 
		msgraph.members.Id=[stage].Id and 
		msgraph.members.groupId=[stage].groupId
	)
END