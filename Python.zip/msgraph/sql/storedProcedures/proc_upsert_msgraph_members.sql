CREATE PROCEDURE upsert_msgraph_members
AS
BEGIN
MERGE msgraph.members AS [Target]
USING (SELECT * from msgraph.stg_members) AS [Source] 
    ON [Target].Id = [Source].Id and [Target].groupId = [Source].groupId 
WHEN MATCHED THEN
    UPDATE SET
        [Target].displayName = [Source].displayName
        ,[Target].first = [Source].first
		,[Target].last = [Source].last
        ,[Target].userPrincipalName = [Source].userPrincipalName
        ,[Target].isOwner = [Source].isOwner
		,[Target].isMember = [Source].isMember
WHEN NOT MATCHED THEN
    INSERT (
        Id
        ,displayName
        ,first
		,last
		,userPrincipalName
        ,groupId
		,isOwner
		,isMember
    ) VALUES (
        [Source].Id
        ,[Source].displayName
        ,[Source].first
		,[Source].last
		,[Source].userPrincipalName
        ,[Source].groupId
		,[Source].isOwner
		,[Source].isMember
		);
END
