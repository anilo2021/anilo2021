-- stored procedure upsert_msgraph_groups
CREATE PROCEDURE upsert_msgraph_groups
AS
BEGIN
MERGE msgraph.groups AS [Target]
USING (SELECT * from msgraph.stg_groups) AS [Source] 
    ON [Target].Id = [Source].Id
WHEN MATCHED THEN
    UPDATE SET
        [Target].displayName = [Source].displayName
        ,[Target].description = [Source].description
        ,[Target].securityEnabled = [Source].securityEnabled
WHEN NOT MATCHED THEN
    INSERT (
        displayName
        ,Id
        ,description
        ,securityEnabled
    ) VALUES (
        [Source].displayName
        ,[Source].Id
        ,[Source].description
        ,[Source].securityEnabled
		);
END