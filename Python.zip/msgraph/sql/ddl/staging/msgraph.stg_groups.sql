CREATE TABLE msgraph.stg_groups 
(
Id varchar(255), 
displayName varchar(255),
description varchar(500),
securityEnabled int
);
