CREATE TABLE msgraph.stg_members 
(
Id varchar(255), 
displayName varchar(255),
first varchar(255),
last varchar(255),
userPrincipalName varchar(255),
groupId varchar(255),
isOwner int,
isMember int
);
