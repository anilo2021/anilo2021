-- DDL to create the msgraph.vw_members view
CREATE VIEW msgraph.vw_members AS
  SELECT
    Id,
    displayName,
    first,
    last,
    userPrincipalName,
    groupId,
    isOwner,
    isMember
  FROM msgraph.members;
