-- DDL to create the msgraph.vw_groups view
CREATE VIEW msgraph.vw_groups AS
  SELECT
    Id,
    displayName,
    description,
    securityEnabled
  FROM msgraph.groups;