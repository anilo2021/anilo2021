CREATE TABLE msgraph.groups 
(
Id varchar(255) NOT NULL, 
displayName varchar(255),
description varchar(500),
securityEnabled int,
constraint PK_groups PRIMARY KEY CLUSTERED(Id)
);
