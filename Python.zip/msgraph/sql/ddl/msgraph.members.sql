CREATE TABLE msgraph.members 
(
Id varchar(255) NOT NULL, 
displayName varchar(255),
first varchar(255),
last varchar(255),
userPrincipalName varchar(255),
groupId varchar(255) NOT NULL,
isOwner int,
isMember int,
constraint PK_members PRIMARY KEY CLUSTERED(Id,groupId)
);
