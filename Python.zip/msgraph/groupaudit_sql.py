####################################################################################################
# Name:                 groupaudit_sql.py
# Python version:       Python 3.6.4
# Diagram Path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/msgraph/groupaudit-sql.vsdx
# Command line usage:   python start.py groupaudit_sql [start]
# Purpose:              Stores AD group member and owner information in SQL DB; Starts a new campaign; 
#                       Sends AIM Infrastructure an email on any discrepancies in AD groups
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-07-28 H. Maddipati (harm344@kellyservices.com)      Original Author
# 2022-01-19 H. Maddipati (harm344@kellyservices.com)      Added feature to track Terminated users.
####################################################################################################

# library imports
import json
import io
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import datetime
import string
import random
# library import check
try:
    import openpyxl
    excelEngine = 'openpyxl'
except ModuleNotFoundError as e:
    excelEngine = 'xlrd'
# local module imports 
from mssharepoint.sharepointsession import sharepointSession
from msgraph.graphsession import graphSession
# Python ODBC
import pyodbc

def groupaudit_sql(session):
    auditConfig = session['msgraph'].scriptConfig # Config file
    groupsDf = getGroups(session,auditConfig['serviceAccount']) # Get group Ids from Graph
    # Check differnece with Secuirity group Inventory excel file
    campaign = getCampaign(session['msgraph'],auditConfig)
    # get members data using Graph API
    membersDF = getmembersGraph(session,groupsDf["ObjectId"].values.tolist(),campaign)
    disabledAccounts = membersDF.loc[membersDF['accountEnabled']==False] # list of users that are terminated
    checkDiscrepancy(session,groupsDf, disabledAccounts,auditConfig) 
    # Add/remove users from PowerApp sharing group
    updateShareGroupMembers(session,auditConfig,membersDF,campaign)
    # Update ADgroups SQL Table and get deleted groups
    deletedGroupIds = groupsCheck(session,groupsDf["ObjectId"].values.tolist(),auditConfig)
    session['msgraph'].log(text="Group updates done successfully")
    # Update Members SQL Table
    membersCheck(session,membersDF,deletedGroupIds,auditConfig,campaign)
    session['msgraph'].log(text="Member updates done successfully")


def getGroups(session,serviceAccount): # Gets all groups owned srv-O365bi. Returns DataFrame of groups Info 
    ownedGroups = session['msgraph'].ownedObjects(serviceAccount['id']) # API call: reutrns groups owned by service account
    groupRow = []
    for group in ownedGroups:
        groupRow.append([group['displayName'],group['id']])
    groupsDf = pd.DataFrame(groupRow,columns = ["GroupName","ObjectId"])
    session['msgraph'].log(text="Groups owned by {}: {}".format(serviceAccount['upn'],groupsDf["GroupName"].values.tolist()))
    return groupsDf


def checkDiscrepancy(session,srvo365OwnedGroupsDf,disabledAccounts,auditConfig):
    def performGroupCheck(session,df,srvo365OwnedGroups): # Checks if groups are O356/Security/owned by srvo356bi
        df = df.copy(deep=True)
        for index, row in df.iterrows(): 
            currentGroupId = row["ObjectId"]
            # check if service account is an owner
            if currentGroupId in srvo365OwnedGroups:
                df.loc[index,"srvo365bi"] = 1 
            else:
                df.loc[index,"srvo365bi"] = 0
            # Check if it is a security group
            groupInfo=session['msgraph'].graphGroupInfo(currentGroupId) # Get group details using Graph API
            if "id" in groupInfo:
                if groupInfo["securityEnabled"]==True:
                    df.loc[index,"security"] = 1
                else:
                    df.loc[index,"security"] = 0
                # Check if it is an O365 group
                if groupInfo["mailEnabled"]==True and "Unified" in groupInfo["groupTypes"]:
                    df.loc[index,"O365"] = 1
                else:
                    df.loc[index,"O365"] = 0
            elif 'error' in groupInfo:
                df.loc[index,"Errors"] = groupInfo['error']['code']
            else:
                session['msgraph'].log(text="Unexpected error for group ID:{}.  {}".format(currentGroupId,groupInfo)) 
        return df

    def disabledMembersReport(groups,disabledAccounts):
        disabledAccounts = disabledAccounts.reset_index()
        mergedDf = pd.merge(disabledAccounts,groups,left_on='groupId',right_on='ObjectId')
        mergedDf = mergedDf.reindex(columns=['first','last','GroupName','owner','userPrincipalName','campaignId','accountEnabled','groupId','memberId'])
        return mergedDf

    fileName = auditConfig["GroupInventoryFile"]['fileName']
    fileLoc = auditConfig["GroupInventoryFile"]['SharePointPath'] + fileName
    # Get excel file from sharepoint
    with open(session['mssharepoint'].fileDownload(fileLoc),'rb') as excelFile:
        session['msgraph'].log(text="Reading File from {}".format(fileLoc))
        inventoryDf = pd.read_excel(excelFile, "Group Inventory",usecols="E,F",engine=excelEngine).replace(r'^\s*$',np.nan,regex=True)
        inventoryDf.columns = inventoryDf.iloc[0] # making first row as column header
        inventoryDf = inventoryDf[1:].dropna(subset=['GroupName']) # Dataframe with inventory list    # Ids of groups owned by srvo365bi
    srvOwnedIds = srvo365OwnedGroupsDf["ObjectId"].values.tolist()
    # Get duplicates and missing Ids of groups
    duplicatesDf = inventoryDf.loc[inventoryDf.ObjectId.str.contains("Duplicated", na=False)]
    missingDf = inventoryDf[inventoryDf['ObjectId'].isna()]
    # Cleaned inventory dataframe
    inventoryDf = inventoryDf.loc[~inventoryDf.ObjectId.str.contains("Duplicated", na=True)]
    inventoryIds = inventoryDf["ObjectId"].values.tolist()
    # Perfrom required verification for groups listed only in excel
    excelInventory = performGroupCheck(session,inventoryDf,srvOwnedIds)
    # Perform required verification for groups listed only in Graph
    uniquetoSrv = srvo365OwnedGroupsDf[~srvo365OwnedGroupsDf.ObjectId.isin(inventoryIds)]
    uniqueGraphGroupsDf = performGroupCheck(session,uniquetoSrv,srvOwnedIds)
    # Filter missinDf: Add objectIds to missingDf from uniqueGraphGroupsDf 
    uniqueGraphGroupsDf = uniqueGraphGroupsDf.set_index(['GroupName'])    
    missingDf = missingDf.set_index(['GroupName'])    
    for index,row in missingDf.iterrows():
        if index in uniqueGraphGroupsDf.index:
            missingDf.loc[index,"ObjectId"] = uniqueGraphGroupsDf.loc[index]["ObjectId"]
            missingDf.loc[index,"missingId"] = "Missing in Excel"
        else:
            missingDf.loc[index,"missingId"] = "Item does not exist in azure portal"
    uniqueGraphGroupsDf, missingDf=uniqueGraphGroupsDf.reset_index(),missingDf.reset_index()
    # Generate report for disabled accounts
    disabledMembersDf = disabledMembersReport(srvo365OwnedGroupsDf,disabledAccounts)
    # Excel file generation
    Path(session['msgraph'].directory/'download').mkdir(parents=True, exist_ok=True) # Create download directory if it does not exist
    writer = pd.ExcelWriter(session['msgraph'].directory/'download'/'inventory.xlsx', engine='xlsxwriter') # USES opnepyxl and xlsxWriter libraries
    excelInventory.to_excel(writer,sheet_name='Excel Groups',index=False)
    missingDf.to_excel(writer,sheet_name='Excel Missing ID',index=False)
    duplicatesDf.to_excel(writer,sheet_name='Excel Duplicates',index=False)
    uniqueGraphGroupsDf.to_excel(writer,sheet_name='ExcelNotFound ownedBySrvO365bi',index=False)
    disabledMembersDf.to_excel(writer,sheet_name='Terminated AD members',index=False)
    # Excel file formatting
    writer.sheets['Excel Groups'].conditional_format('A1:E1048576', {'type': '2_color_scale',
                              'min_color': '#FF5733',
                              'max_color': '#C7FF33'})
    writer.sheets['ExcelNotFound ownedBySrvO365bi'].conditional_format('A1:E1048576', {'type': '2_color_scale',
                              'min_color': '#FF5733',
                              'max_color': '#C7FF33'})
    writer.save()
    # Send Email
    with open(session['msgraph'].repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sql.html') as template:
        dataInserts = {
            "fileName":fileName,
            "filePath":fileLoc,
        }
        session['msgraph'].graphEmail(body= template.read().format(**dataInserts),  recipients=auditConfig['emailRecipients']['notification']['html'], attachment=session['msgraph'].directory/'download'/'inventory.xlsx')


def getCampaign(session,auditConfig):
    # Generates new campaignID and returns it
    def startCampaign(): 
        cursor = conn.cursor()    
        generatedId = id_generator() # Random ID generator
        while generatedId in previousCampaigns: # check if random generated Id was used before
            session.log("Generated Id was not unique. Trying again...")
            generatedId = id_generator()
        insertQ = "INSERT INTO {} (id,startDate) values ('{}','{}') ".format(auditConfig['tables']['campaignTable'],generatedId,today)
        cursor.execute(insertQ)
        session.log(insertQ)
        conn.commit()
        return generatedId

    # Random ID generator
    def id_generator(size=8, chars=string.ascii_uppercase + string.digits):
        today = str(datetime.datetime.now().strftime("%Y%m%d"))
        randomId = "".join(random.choice(chars) for _ in range(size)) # check if it repeasts a campaing ID
        generatedId = today+"_"+randomId
        return generatedId

    # Database connection
    conn = session.getDatabaseConnection(auditConfig['Database'])   
    # Get campaign from SQL
    campaignTableDF = pd.read_sql("SELECT * FROM {} WHERE endDate is NULL".format(auditConfig['tables']['campaignTable']),conn)
    previousCampaigns = pd.read_sql("SELECT id FROM {}".format(auditConfig['tables']['campaignTable']),conn)['id'].tolist()
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    todayInt = int(datetime.datetime.now().strftime("%Y%m%d"))
    currentCampaignData = campaignTableDF[(todayInt >= campaignTableDF['startDateInt']) & (campaignTableDF['endDateInt'].isnull() )] # If campaign start date is given and end date is not specified
    # If there is an active Ccampaign
    if len(currentCampaignData)==1:
        if  len(sys.argv)>1 and sys.argv[1]=='start':
            raise Exception("There is already an active campaign running. Please close the current campaign if you want to start a new one.")
        currentCampaign = currentCampaignData['id'].values[0]
        session.log(text="Current campaign: {}".format(currentCampaign))
        return currentCampaign
    else:
        session.log("There is no active campaign")
        # If Campaign does not exist, confirm if arg=='start' to start a new campaign
        if  len(sys.argv)>1 and sys.argv[1]=='start':
            session.log("Generating new campaign...")
            currentCampaign = startCampaign() # Generate new campaignID and return it
            session.log(text="Generated campaign Id : {}".format(currentCampaign))
            # Email to AIM: Information on the started campaign
            with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_groupaudit_sql_generate.html') as template:
                dataInserts = {
                    "campaignId": currentCampaign,
                    "start": today
                }
                session.graphEmail(body=template.read().format(**dataInserts),recipients= auditConfig['emailRecipients']['notification']['html'])
            return currentCampaign
        else:
            # Raise exception about argument
            raise Exception("There is no active campaign. Please use 'start' argument")


def getmembersGraph(session,groupIds,campaign): # Gets group members of each group form Graph API and stores in DataFrame. Returns members DataFrame
    memberRow = []
    for groupId in groupIds:
        ownerGraphData = session['msgraph'].graphGroupOwnersList(groupId,filters="id,displayName,surname,givenName,userPrincipalName,mail,accountEnabled")
        membersGraphData = session['msgraph'].graphGroupMembersList(groupId,filters="id,displayName,surname,givenName,userPrincipalName,mail,accountEnabled")
        groupOwnersList = []
        # Store group owners
        for owner in ownerGraphData: 
            memberRow.append([owner["id"],1,owner["givenName"],owner["surname"],groupId,owner["userPrincipalName"],campaign,owner['accountEnabled']])
            groupOwnersList.append(owner["id"])
        # Store group members
        for member in membersGraphData:
            if member["id"] in groupOwnersList: # Member already exists as an owner
                pass
            else:   # Check odata if they are a user or a group 
                if member["@odata.type"] == "#microsoft.graph.group":
                    memberRow.append([member["id"],0,member["displayName"],"Group",groupId,member["mail"],campaign,"True"])
                else:
                    memberRow.append([member["id"],0,member["givenName"],member["surname"],groupId,member["userPrincipalName"],campaign,member['accountEnabled']])
    # Generate a DrataFrame using memberRow values
    membersDF = pd.DataFrame(memberRow,columns = ["memberId","owner","first","last","groupId","userPrincipalName","campaignId","accountEnabled"])
    membersDF = membersDF.set_index(['memberId','groupId','campaignId'])
    return membersDF

def updateShareGroupMembers(session,auditConfig,membersDF,campaignId): # Updates members of InfraSec GroupOwners with current group owners 
    # PowerApps sharing group Id
    shareGroupId = auditConfig['shareGroup']['id']
    #shareGroupId = auditConfig['shareGroupTest']['id'] # For Testing
    # Get current members of the sharing group
    sharingGroupMembers =  [[userData["id"],userData["userPrincipalName"]] for userData in session['msgraph'].graphGroupMembersList(shareGroupId)] 
    # Get all owners of security groups from Graph API
    ownersDFgraph = membersDF[membersDF.owner !=0].drop_duplicates('userPrincipalName').reset_index().drop(['groupId','owner','first','last','campaignId','accountEnabled'],axis=1)
    ownersList = ownersDFgraph.values.tolist() 
    # Filter: excluded service accounts
    sharingGroupMembers = [tuple(item) for item in sharingGroupMembers if item[1] not in auditConfig['excludeUpn']]
    ownersList = [tuple(item) for item in ownersList if item[1] not in auditConfig['excludeUpn']]
    # Filter: Beta Test emails only
    # ownersList = [tuple(item) for item in ownersList if item[1] in auditConfig['betaTesters']]
    sgNewMembers = list(set(ownersList)-set(sharingGroupMembers)) # New owners to be added
    sgRemoveMembers = list(set(sharingGroupMembers)-set(ownersList)) # Old owners to be removed
    session['msgraph'].log("Current members in PowerApp Share group: {}".format(sharingGroupMembers))
    session['msgraph'].log("Owners in current campaign: {}".format(ownersList) )
    session['msgraph'].log("New members to be added to the PowerApp Share group: {}".format(sgNewMembers))
    session['msgraph'].log("Members to be removed from the PowerApp Share group: {}".format(sgRemoveMembers))
    # Access to Sharing group logic
    if sharingGroupMembers==ownersList: # No need to Add/Remove members from share group 
        session['msgraph'].log(" All owners present in the share group: "+ auditConfig['shareGroup']['groupName'])
    else:
        if sgNewMembers: # Add new owners to share group 
            session['msgraph'].log(" New members to "+ auditConfig['shareGroup']['groupName']+": {}".format(sgNewMembers))
            for user in sgNewMembers:
                body = {"@odata.id": "https://graph.microsoft.com/v1.0/directoryObjects/{}".format(user[0])}
                addResponse = session['msgraph'].graphAddGroupMember(shareGroupId,body) # Add member to group using graph api 
                session['msgraph'].log(addResponse.status_code)
                if addResponse.status_code == 204: # Append new row to membersDF                      
                    userDetails= session['msgraph'].graphUserDetails(user[0],filters="id,displayName,surname,givenName,userPrincipalName,mail,accountEnabled")
                    membersDF.loc(axis=0)[(userDetails['id'], shareGroupId,campaignId) ] = [0 ,userDetails['givenName'],userDetails['surname'],userDetails['userPrincipalName'],userDetails['accountEnabled']] 
                    session['msgraph'].log(" Added {} to group {} for campaign: {}".format(user[1],auditConfig['shareGroup']['groupName'],campaignId) )
                else:
                    session['msgraph'].log(" Adding {} to group {} for campaign {} failed: '{}'".format(user[1],auditConfig['shareGroup']['groupName'],campaignId ,addResponse.json()['error']['message'] ))
        if sgRemoveMembers: # Remove old owners from share group
            session['msgraph'].log(" Deleting members from "+ auditConfig['shareGroup']['groupName']+": {}".format(sgRemoveMembers))
            for user in sgRemoveMembers:
                delResponse = session['msgraph'].graphRemoveGroupMember(shareGroupId,user[0]) # Remove from group using graph api
                session['msgraph'].log(delResponse.status_code)
                if delResponse.status_code == 204: # Remove row from membersDF
                    membersDF.drop((user[0],shareGroupId,campaignId),inplace=True)
                    session['msgraph'].log(" Removed {} from {}".format(user[1],auditConfig['shareGroup']['groupName']))
                else:
                    session['msgraph'].log(" Removing {} from {} failed with error '{}'".format(user[1],auditConfig['shareGroup']['groupName'], delResponse.json()['error']['message'] ))
    # Convert "owner" column data-type from float to int
    membersDF['owner'] = membersDF['owner'].astype(int)


def membersCheck(session,graphMembersDF,deletedGroups,auditConfig,campaign): # Checks for updates/deletions/insertions into members SQL table
    # Database connection
    conn = session['msgraph'].getDatabaseConnection(auditConfig['Database'])
    # Members DataFrame retrieved from SQL 
    membersTableDF = pd.read_sql("SELECT memberId,owner,first,last,groupId,userPrincipalName,isDeleted,campaignId,accountEnabled FROM {} WHERE campaignId='{}' ".format(auditConfig['tables']['membersTable'],campaign),conn)
    membersTableDF = membersTableDF.set_index(['memberId','groupId','campaignId'])
    membersTableIndexList, graphMembersIndexList = membersTableDF.index, graphMembersDF.index
    # Update existing record's information with graph data
    membersTableUpdate(session,graphMembersDF,membersTableDF,conn,auditConfig,deletedGroups)
    if set(graphMembersIndexList) != set(membersTableIndexList): # Compare graph data vs SQL data. To check for New/Deleted members
        # Check for insertions / deletetions 
        newMemberIds =list(set(graphMembersIndexList)-set(membersTableIndexList)) 
        deletedMemberIds = list(set(membersTableIndexList)-set(graphMembersIndexList))
        session['msgraph'].log(text="New members in this campaign: {}".format(newMemberIds))
        session['msgraph'].log(text="Deleted members in this campaign: {}".format(deletedMemberIds))
        if len(newMemberIds)>=1: # Insert new groups to the members SQL Table
            membersTableinsertDelete(session,graphMembersDF,membersTableDF,conn,auditConfig,newMemberIds,None)    
        if len(deletedMemberIds)>=1: # Change isDeleted Flag in members SQL Table to TRUE
            membersTableinsertDelete(session,graphMembersDF,membersTableDF,conn,auditConfig,None,deletedMemberIds)


def membersTableinsertDelete(session,graphMembersDF,membersTableDF,conn,auditConfig,newMemberIds=None,deletedMemberIds=None): # Inserts and Deletes members in SQL table
    session['msgraph'].log("INSERT / DELETE members")
    if newMemberIds is not None: # Runs when there are new members that need to be added to SQL table
        for index, row in graphMembersDF.iterrows():    
            if index in newMemberIds:
                if row['first'] ==None or row['last']==None: # This case checks for "Name" inconsistencies of the member
                    if row['first']==None and row['last']==None:
                        insertValues = "'{}','{}',NULL,NULL,'{}','{}','{}','{}'".format(index[0],row["owner"],index[1],row["userPrincipalName"],index[2],row['accountEnabled']) # Case1: No firstName. No LastName.
                    elif row['first']==None and row['last']!=None:
                        insertValues = "'{}','{}',NULL,'{}','{}','{}','{}','{}'".format(index[0],row["owner"],row["last"],index[1],row["userPrincipalName"],index[2],row['accountEnabled']) # Case2: No firstName. 
                    elif row['first']!=None and row['last']==None:
                        insertValues = "'{}','{}','{}',NULL,'{}','{}','{}','{}'".format(index[0],row["owner"],row['first'],index[1],row["userPrincipalName"],index[2],row['accountEnabled']) # Case3: No LastName.
                else: # Base case for when there are no "Name" incosistencies
                    insertValues = "'{}','{}','{}','{}','{}','{}','{}','{}'".format(index[0],row["owner"],row["first"].replace("'", "''"),row["last"].replace("'", "''"),index[1],row["userPrincipalName"],index[2],row['accountEnabled'])
                insertFields = 'memberId,owner,first,last,groupId,userPrincipalName,campaignId,accountEnabled'
                populateDb(session['msgraph'],"INSERT",conn,auditConfig['tables']['membersTable'],insertFields,insertValues)
    if deletedMemberIds is not None: # Runs when there are members to be deleted from SQL table
        for index in deletedMemberIds:
            if membersTableDF.loc[index]['isDeleted'] != 'True':
                onIndex = "memberId='{}' AND groupId='{}' AND campaignId='{}'".format(index[0],index[1],index[2]) # SQL syntax for member to be removed   
                # Run query twice to show change in history table
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],"isDeleted='True'",onIndex)
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],"isDeleted='True'",onIndex)


def membersTableUpdate(session,graphMembersDF,membersTableDF,conn,auditConfig,deletedGroups=None): # Updates existing members records in SQL table
    session['msgraph'].log("UPDATING MEMBERS")
    for index,row in graphMembersDF.iterrows():
        onIndex = "memberId='{}' AND groupId='{}' AND campaignId='{}' ".format(index[0],index[1],index[2]) # Selected member
        if index in membersTableDF.index: 
            # Check for UPDATES in members SQL Table
            if row["owner"] != membersTableDF.loc[index]["owner"]: # Ownership update
                updateOwner = "owner='{}'".format(row['owner'])
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],updateOwner,onIndex)
            if row["first"] != membersTableDF.loc[index]["first"]: # First name update
                if row["first"]== None : # Handling no firstName case
                    updateFirst = "first=NULL"
                else:
                    updateFirst = "first='{}'".format(row['first'].replace("'", "''"))
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],updateFirst,onIndex)
            if row["last"] != membersTableDF.loc[index]["last"]: # Last name update
                if row["last"]== None : # Handling no lastName case
                    updateLast = "last=NULL"
                else:
                    updateLast = "last='{}'".format(row['last'].replace("'", "''"))
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],updateLast,onIndex)
            if row["userPrincipalName"] != membersTableDF.loc[index]["userPrincipalName"]: # upn Update
                updateEmail = "userPrincipalName='{}'".format(row['userPrincipalName'])
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],updateEmail,onIndex)
            # Special cases
            # Restore members that were removed previously
            if membersTableDF.loc[index]['isDeleted'] == 'True': 
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],"isDeleted='False'",onIndex)
            # If member is in a deleted group, update isDeleted to True
            if deletedGroups is not None: 
                if index[1] in deletedGroups:
                    if membersTableDF.loc[index]['isDeleted'] != 'True':
                        populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['membersTable'],"isDeleted='True'",onIndex)

             
def groupsCheck(session,groupIds,auditConfig):  # Checks for updates/deletions/insertions into ADgroups SQL table. Returns groups that were deleted
    # Database connection
    conn = session['msgraph'].getDatabaseConnection(auditConfig['Database'])   
    # Fetch ADgroups SQL Table and store it as a DataFrame
    ADgroupsTableDF = pd.read_sql("SELECT id,displayName,description,isDeleted FROM {}".format(auditConfig['tables']['groupsTable']),conn)
    ADgroupsTableDF = ADgroupsTableDF.set_index('id')
    groupRow = []
    deletedGroupIds = []
    for item in groupIds:
        graphGroupData = session['msgraph'].graphGroupInfo(item) # Get group info using Graph API
        groupRow.append([graphGroupData["id"], graphGroupData["displayName"], graphGroupData["description"]])
    graphDF = pd.DataFrame(groupRow,columns = ["id","displayName","description"]) # Store graph info into a DataFrame
    graphDF =  graphDF.set_index('id')
    ADgroupsIndexList, graphIndexList = ADgroupsTableDF.index , graphDF.index
    # Update existing table records with graph data
    groupsTableUpdate(session,graphDF,ADgroupsTableDF,conn,auditConfig)
    if set(graphIndexList) != set(ADgroupsIndexList):  # Compare graph data vs SQL data. To check for New/Deleted groups
        newGroupIds = list(set(graphIndexList)-set(ADgroupsIndexList)) 
        deletedGroupIds = list(set(ADgroupsIndexList)-set(graphIndexList))
        session['msgraph'].log(text="new groups: {}".format(newGroupIds))
        session['msgraph'].log(text="Deleted groups: {}".format(deletedGroupIds))
        if len(newGroupIds)>=1: # Insert new groups to the ADgroups Table
            groupsTableInsertDelete(session,graphDF,ADgroupsTableDF,conn,auditConfig,newGroupIds,None)    
        if len(deletedGroupIds)>=1: # change isDeleted Flag in ADgroups Table to TRUE
            groupsTableInsertDelete(session,graphDF,ADgroupsTableDF,conn,auditConfig,None,deletedGroupIds)
    return deletedGroupIds


def groupsTableInsertDelete(session,graphDF,ADgroupsTableDF,conn,auditConfig,newGroupIds=None,deletedGroupIds=None):  # Inserts and Deletes groups in SQL table
    if newGroupIds is not None: # Runs when there are groups that need to be added to SQL table
        for index, row in graphDF.iterrows():    
            if index in newGroupIds:
                desc = row['description'].replace("'", "''")  # Handling single quotes. To be SQL friendly 
                insertValues = "'{}','{}','{}'".format(index,row["displayName"],desc)
                populateDb(session['msgraph'],"INSERT",conn,auditConfig['tables']['groupsTable'],'id, displayName, description',insertValues)
    if deletedGroupIds is not None: # Runs when there are groups to be deleted from SQL table
        for index in deletedGroupIds:
            if ADgroupsTableDF.loc[index]['isDeleted'] != 'True':
                onIndex = "id='{}'".format(index)  
                # run query twice to show change in history table
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['groupsTable'],"isDeleted='True'",onIndex)
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['groupsTable'],"isDeleted='True'",onIndex)


def groupsTableUpdate(session,graphDF,ADgroupsTableDF,conn,auditConfig): # Updates existing group records in SQL table
    for index, row in graphDF.iterrows():
        onIndex = "id='{}'".format(index)
        if index in ADgroupsTableDF.index:
            # check for UPDATE in ADgroups Table
            if row['description'] != ADgroupsTableDF.loc[index]["description"]: # Description update
                desc = row['description'].replace("'", "''")
                updateDesc = "description='{}'".format(desc)
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['groupsTable'],updateDesc,onIndex)
            if row['displayName'] != ADgroupsTableDF.loc[index]["displayName"]: # Name update
                updateDisplayName = "displayName='{}'".format(row['displayName'])
                populateDb(session['msgraph'],"UPDATE",conn,auditConfig['tables']['groupsTable'],updateDisplayName,onIndex)
            # If the group needs to be restored
            if ADgroupsTableDF.loc[index]["isDeleted"] == 'True':
                session['msgraph'].log("Index present in ADGroupsTable, But deleted: {}".format(index))


def populateDb(session,queryType,conn,tableName,param1,param2): # Writes into Database
    cursor = conn.cursor()
    if queryType=="UPDATE": # Update query
        updateQ = "UPDATE {} SET {} Where {} ".format(tableName,param1,param2)
        session.log(updateQ)
        cursor.execute(updateQ)
    if queryType == "INSERT": # Insert query
        insertQ = "INSERT INTO {} ({}) VALUES ({})".format(tableName,param1,param2)
        session.log(insertQ)
        cursor.execute(insertQ)
    conn.commit()


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['msgraph'] = graphSession(Path(__file__).stem, taskName='update')
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem, '', logFileName=sessionContainer['msgraph'].logFileName)   # had to use Path() to fetch the scriptConfig in sesion.py
    try:
        if not (sessionContainer['msgraph'].login() and sessionContainer['mssharepoint'].login()):
            sessionContainer['msgraph'].log('Login error - aborted')
        else:
            sessionContainer['msgraph'].log('Login Complete')
            groupaudit_sql(sessionContainer)
            sessionContainer['msgraph'].log('Script execution complete')
    except Exception as e:
        sessionContainer['msgraph'].graphError(e,email=sessionContainer['msgraph'].scriptConfig['errorNotification'])