####################################################################################################
# Name:                 srvownedgroups.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/msgraph/srvownedgroups.vsdx
# Command line usage:   python start.py srvownedgroups
# Purpose:              Refreshes database of groups owned by srv-o365bi. 
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-11-18 Harsha Maddipati (harm344@kellyservices.com)  Original Author
####################################################################################################

# library imports
import json
import multiprocessing
import pandas as pd
from pathlib import Path
import sys
# Python ODBC
import pyodbc

# local imports
from msgraph.graphsession import graphSession

def srvownedgroups(session):
    if session.scriptConfig['disabled']:
        return False
    else:
        pbiGroups = generateGroupsDF(session,session.scriptConfig['serviceAccount']) # Get groups Dataframe using Graph API
        groupMembers = generatemembersDF(session,pbiGroups["Id"]) # Get members Dataframe using Graph API
        # SQL inserts
        # generate dataframes from data lists
        stgData = {
            'stg_groups': pbiGroups,
            'stg_members': groupMembers
        }
        # insert stage dataframes into stg tables
        for stgTableName in stgData:
            session.log(text='Inserting '+str(len(stgData[stgTableName].index))+' rows of staging data into '+stgTableName+'...')
            stgData[stgTableName].to_sql(
                name=stgTableName,
                con=session.getDatabaseConnection(session.scriptConfig['Database']['Admin']['dbName'],'sqlalchemy'), # Use Admin user connection to insert
                schema=session.scriptConfig['Database']['Admin']['schema'],
                if_exists='replace',
                index=False
            )
        session.log(text='Insert completed')
        devopsUserConn = session.getDatabaseConnection(session.scriptConfig['Database']['User']['dbName'],'sqlalchemy').raw_connection() # For upsert
        devopsCursor = devopsUserConn.cursor()
        procedures = session.scriptConfig['dbProcedures']
        for tableName in procedures['upsert']:
        # NOTE: keys are strings, same as each base table name
            session.log(text='Upserting '+tableName+' from stg_'+tableName+'...')
            session.executeSqlFile(
                fileName='storedProcedureExec.sql', 
                cursor=devopsCursor, 
                params=[procedures['upsert'][tableName]]
            )
        for tableName in procedures['delete']:
            session.log(text='Deleting rows in '+tableName+' using stg_'+tableName+'...')
            session.executeSqlFile(
                fileName='storedProcedureExec.sql', 
                cursor=devopsCursor, 
                params=[procedures['delete'][tableName]]
            )
        # commit stored procedure transactions
        devopsCursor.commit()


def generateGroupsDF(session,serviceAccount): # Gets all groups owned srv-O365bi. Returns DataFrame of groups Info 
    ownedGroups = session.ownedObjects(serviceAccount['id']) # API call: reutrns groups owned by service account
    groupRow = []
    for group in ownedGroups:
        groupRow.append([group['displayName'],group['id'],group['description'],group['securityEnabled']])
    groupsDF = pd.DataFrame(groupRow,columns = ["displayName","Id","description","securityEnabled"])
    session.log(text="Groups owned by {}: {}".format(serviceAccount['upn'],groupsDF["displayName"].values.tolist()))
    return groupsDF

def generatemembersDF(session,pbiGroupsIds):
    memberRow = pd.DataFrame(columns = ['displayName', 'Id', 'first','last', 'userPrincipalName',"groupId","isOwner","isMember"])
    for groupId in pbiGroupsIds:
        ownerGraphData = session.graphGroupOwnersList(groupId)
        membersGraphData = session.graphGroupMembersList(groupId)
        groupOwnersList = []
        # Store group owners
        for owner in ownerGraphData: 
            memberRow = memberRow.append({  'displayName' : owner["displayName"], 
                                            'Id' : owner["id"], 
                                            'first' : owner["givenName"] if "givenName" in owner else owner["displayName"],
                                            'last' : owner["surname"] if "surname" in owner else "",
                                            'userPrincipalName' : owner["userPrincipalName"] if "userPrincipalName" in owner else "" ,
                                            'groupId' : groupId ,
                                            'isOwner' : 1 ,
                                            'isMember' : 0}
                                        ,ignore_index = True)
            groupOwnersList.append(owner["id"])
        # Store group members
        for member in membersGraphData:
            if member["id"] in groupOwnersList: # Row already exists as an owner update "isMember" flag
                memberRow.loc[(memberRow['Id'] == member['id']) & (memberRow['groupId'] == groupId),["isMember"]] = 1
            else:
                memberRow = memberRow.append({  'displayName' : member["displayName"], 
                                                'Id' : member["id"], 
                                                'first' : member["givenName"] if "givenName" in member else member["displayName"],
                                                'last' : member["surname"] if "surname" in member else "",
                                                'userPrincipalName' : member["userPrincipalName"] if "userPrincipalName" in member else "",
                                                'groupId' : groupId ,
                                                'isOwner' : 0 ,
                                                'isMember' : 1 }
                                            ,ignore_index = True)  
    memberRow.fillna("",inplace=True)
    return memberRow

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['msgraph'] = graphSession(Path(__file__).stem,taskName=('_'.join(sys.argv[1:3])).replace(' ', '_'))
    try:
        if not sessionContainer['msgraph'].login():
            sessionContainer['msgraph'].log('Login error - aborted')
            sys.exit(1)
        else:
            srvownedgroups(sessionContainer['msgraph'])
            sessionContainer['msgraph'].log(text='Script execution complete')
    except Exception as e:
        sessionContainer['msgraph'].graphError(e, email=sessionContainer['msgraph'].scriptConfig['errorNotification'])