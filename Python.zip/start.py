# start.py
# Original Author: Jesse Rominske (jesr114@kellyservices.com)
# Python version 3.6.4
# Command Line Usage: python start.py scriptName [args]
# Function:
#   - Master entry point for AIM ETL scripts in Python repo
#   - Takes a script name and matches it to a script in the Python
#     package, then runs it with given arguments where applicable
# Revision History:
#   - 1.0 - 2018/09/18 by Jesse Rominske (jesr114@kellyservices.com)

# library imports
import json
import os
import subprocess
import sys

# main thread
if __name__ == "__main__":
    # declare variables
    scriptName = sys.argv[1]
    args = sys.argv[2:]
    for i in range(len(args)):
        args[i] = "\""+args[i]+"\"" if ' ' in args[i] else args[i]
    currentDirectory = os.path.dirname(os.path.abspath(__file__))
    # load module index
    print('Executing script '+scriptName)
    indexPath = os.path.join(currentDirectory, 'common', 'moduleindex.json')
    moduleIndex = json.load(open(indexPath))
    # generate command string from script module and list of args and run command
    cmdString = 'python -m '+moduleIndex[scriptName]+' '+' '.join(args)
    print('Executing command: '+cmdString)
    exitStatus = subprocess.call(cmdString, cwd=currentDirectory)
    # handle subprocess failure
    if exitStatus == 0:
        print('Script '+scriptName+' execution succeeded')
    else:
        print('Script '+scriptName+' execution failed')
    sys.exit(exitStatus)