####################################################################################################
# Name:                 session.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/16/session
# Command line usage:   N/A
# Purpose:              Class contains methods for "grunt work" of Python automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-30 J. Rominske (jesr114@kellyservices.com)      Original Author
# 2021-05-19 H. Maddipati (harm344@kellyservices.com)     Kelly logo attachment added to email template
# 2021-09-01 H. Maddipati (harm344@kellyservices.com)     Feature: Email retry incase of failure.
# 2022-02-08 H. Maddipati (harm344@kellyservices.com)     Feature: Bcc parameter to email method.
####################################################################################################

# library imports
import datetime
from email.message import EmailMessage
import json
import mimetypes
import os
from pathlib import Path
import pyodbc
import smtplib
import socket
import sys
import time
import traceback

# wrapper superclass, containing shared functions
class session(object):
    # generic initialization method
    def __init__(self, baseName, taskName, logDirectory=None, logFileName=None, args=None):
        self.repoDirectory = Path(__file__).absolute().parent.parent # "Python" folder
        # grab environment from system variables, otherwise get dev/sqa/prd folder name as string for environment
        if 'aim_env' in os.environ:
            self.env = os.environ['aim_env']
            self.sysVarFlag = True
        else:
            self.env = self.repoDirectory.parent.name
            self.sysVarFlag = False
        # throw error if invalid environment
        if self.env == 'vdi':
            self.secureDirectory = self.repoDirectory/'credentials' # change if param directory moves
            self.env = 'dev'
        elif self.env in ('sbx', 'dev', 'sqa', 'uat', 'prd'):
            self.serverEnv = 'dev' if self.env in ('sbx', 'sqa', 'uat') else self.env # dev and sqa are on the same server
            self.secureDirectory = Path('\\\\amer\\dfs\\aim'+self.serverEnv+'\\aim_infra\\secure\\'+self.env)
            self.configDirectory = Path('\\\\amer\\dfs\\aim'+self.serverEnv+'\\aim_infra\\secure\\'+self.env+'\\config')
        else:    
            raise ValueError('Environment variable '+self.env+' invalid!')
        self.infraDirectory = self.repoDirectory.parent.parent.parent # "aim-infra" folder
        self.emailConfig = json.load(open(self.configDirectory/(self.env+'_emailconfig.json')))
        self.scriptName = baseName
        self.taskName = taskName
        self.args = args
        # call specific setup tasks
        self._setup()
        # initialize log
        if logFileName is not None:
            # if log file path provided, simply set logFileName
            self.logFileName = Path(logFileName)
        else:
            # if log directory is specified, create log there
            if logDirectory:
                self.log(taskName=taskName, directory=logDirectory)
            # if no log directory specified, create log in default location
            else:
                self.log(taskName=taskName)
        # find and load config file if it exists
        self.scriptConfig = None
        scriptConfigPath = self.configDirectory/'scriptConfig'/(self.env+'_'+self.scriptName+'.json')
        if scriptConfigPath.exists():
            self.scriptConfig = json.load(open(scriptConfigPath))
            self.log(text='Config file '+str(scriptConfigPath)+' found and loaded')
        elif scriptConfigPath.stem != self.env+'_': # no message if baseName is passed as '' to avoid confusion with primary session class in log
            self.log(text='No config file for script '+self.scriptName+' found at '+str(scriptConfigPath))
    
    # placeholder function for overloading by subclasses 
    def _setup(self):
        self.directory = self.repoDirectory/'common'

    # creates beautified JSON file from provided data in dict format
    def createJsonFile(self, fileName, jsonData):
        # mandate .json file extension
        if fileName.split('.')[-1] != 'json':
            fileName = fileName.split('.')[0] + '.json'
        # format and save JSON file
        formattedJson = json.dumps(jsonData, indent=4, sort_keys=True)
        jsonFilename = self.directory/fileName
        jsonFilename.parent.mkdir(parents=True, exist_ok=True)
        with open(jsonFilename, 'w') as jsonFile:
            jsonFile.write(formattedJson)
        self.log(text='JSON written to file '+str(jsonFilename))
        return jsonFilename

    # function to log script events
    def log(self, text=None, taskName=None, directory=None, doPrint=False):
        # if taskName is specified, generate new log file
        if taskName != None:
            # generate preliminary file name from timestamp and taskName
            now = datetime.datetime.today()
            fileTimestamp = now.strftime('%Y-%m-%d_%H-%M-%S')
            if not directory:
                logDirectory = self.directory/'logs'
            else:
                logDirectory = Path(directory)
            # create logs folder if it does not already exist
            logDirectory.mkdir(parents=True, exist_ok=True)
            logFile = self.scriptName+'_'+taskName+'_'+fileTimestamp+'.log'
            logFileName = logDirectory/logFile
            # set session log file location
            self.logFileName = logFileName
            # write log header if log file does not already exist
            if not self.logFileName.exists():
                # specify timestamp and header
                timestamp = now.strftime('%Y/%m/%d at %H:%M:%S')
                envGetMethod = ' (from system variable)' if self.sysVarFlag else ' (from code path)'
                logHeader = 'Log file for script '+self.scriptName+'\nGenerated by '+os.getlogin()+' on '+timestamp+'\nEnvironment: '+self.env+envGetMethod+'\nHost: '+socket.gethostname()
                # write header to file
                with open(self.logFileName, 'w') as logFile:
                    logFile.write(logHeader)
                # alert user of new log file location
                print('Log file:', self.logFileName)
        # if text specified and taskName is not, just write to current log file
        elif text != None:
            with open(self.logFileName, 'a') as logFile:
                timestampPrefix = datetime.datetime.today().strftime('%H:%M:%S - ')
                logFile.write('\n'+timestampPrefix+str(text).encode('ascii', 'ignore').decode().replace('\n', '\n\t   '))
        # if doPrint is True, print the current log file to command line
        elif doPrint:
            print('\n\n\n================================================================')
            print('==========LOG_FILE================\n\n')
            with open(self.logFileName, 'r') as logFile:
                print (logFile.read())
            print('\n\n=========END_OF_LOG_FILE=============')
            print('================================================================')

    # generic email method
    def email(self, subject=None, body=None, color=None, attachment=None, recipients=None, bcc=None):
        # set default notification banner color to green
        if not color:
            # TODO: BACKWARDS COMPATIBILITY WITH OLD ERROR NOTIFICATIONS SHOULD BE REMOVED AS WE UPDATE SESSIONS
            color = 'red' if any(x in body for x in self.emailConfig['backwardsCompatibilityStrings']) else 'green'
        # default scriptName to empty string if not provided
        scriptTitle = ' '+self.scriptConfig['scriptTitle'] if self.scriptConfig is not None else ''
        # override subject argument TODO: remove subject argument after scripts no longer use it
        subject = self.env.upper()+scriptTitle+' | '+self.emailConfig['color'][color]['status']+' | '+self.scriptName
        # build inserts dict for template formatting
        inserts = {
            'header': subject,
            'body': body,
            'color': self.emailConfig['color'][color]['value'], # use color name passed to get color value
            'logoName':self.emailConfig['components']['logoName'],
            'infraSig': self.emailConfig['components']['infraSig'],
            'footerText': self.emailConfig['components']['footerText']
        }
        # open HTML template and populate with inserts
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody.html') as template:
            bodyHtml = template.read().format(**inserts)
        # check if email is allowed by configuration
        if not self.emailConfig['active']:
            self.log(text='WARNING - Configuration property "active" is currently False! No email sent.')
            return
        # if specified, save as HTML for logging
        if self.scriptConfig['saveEmailHtml']:
            emailTestDirectory = self.directory/'emailHtml'
            if not emailTestDirectory.exists():
                emailTestDirectory.mkdir(parents=True, exist_ok=True)
            with open(emailTestDirectory/(self.logFileName.stem+'.html'), 'w') as emailTestFile:
                emailTestFile.write(bodyHtml)
        # if allowed, send actual email
        if self.scriptConfig['sendEmail']:
            # get recipients from global config if not provided TODO: REMOVE WHEN UNNECESSARY
            if not recipients:
                recipients = self.emailConfig['recipients']
                self._sendEmail(self._buildEmail(subject, recipients, htmlBody=bodyHtml, attachment=attachment, bcc=bcc))
            # handle recipients when passed in
            else:
                # default case - append as list (for when scripts specify non-config recipients)
                if all(x not in recipients for x in ('html', 'sms')):
                    self.log(text='Preparing HTML email...')
                    self._sendEmail(self._buildEmail(subject, recipients, htmlBody=bodyHtml, attachment=attachment, bcc=bcc))
                else:
                    # if HTML email recipients specified, grab from config, build email, and send
                    if 'html' in recipients:
                        self.log(text='Preparing HTML email...')
                        print(recipients['html'])
                        self._sendEmail(self._buildEmail(subject, recipients['html'], htmlBody=bodyHtml, attachment=attachment, bcc=bcc))
                    # if SMS email recipients specified, grab from config, build email, and send
                    if 'sms' in recipients:
                        self.log(text='Preparing SMS email...')
                        self._sendEmail(self._buildEmail(subject, recipients['sms'], smsBody=body, attachment=attachment, bcc=bcc))
        
    # function for building an email message (private)
    def _buildEmail(self, subject, recipients, htmlBody=None, smsBody=None, attachment=None, bcc=None):
        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = self.emailConfig['sender']
        msg['To'] = recipients
        # use subtype HTML for HTML emails
        if htmlBody:
            msg.set_content(htmlBody, subtype='html')
        # use subtype text for SMS emails
        if smsBody:
            msg.set_content(smsBody, subtype='text')
        if bcc:
            msg['bcc'] = bcc
        # Attachment exists
        if attachment:
            if isinstance(attachment, list): # if attachement is a list, append kelly logo path
                attachmentList = attachment + [self.secureDirectory/'resources'/self.emailConfig['components']['logoName']]
            else: # if attachment is a string, make it a list and append kelly logo path
                attachmentList = [attachment] + [self.secureDirectory/'resources'/self.emailConfig['components']['logoName']]
        else: # If there are no attachment, attach only logo
            attachmentList = [self.secureDirectory/'resources'/self.emailConfig['components']['logoName']]
        # load in attachment
        self.log("Attaching files from {}".format(attachmentList))
        for attachment in attachmentList:
            with open(attachment, 'rb') as file:
                # infer type of attachment from path, defaulting to bytestream
                contentType, encoding = mimetypes.guess_type(str(attachment))
                if contentType is None or encoding is not None:
                    contentType = 'application/octet-stream'
                maintype, subtype = contentType.split('/', 1)
                # add attachment to message
                msg.add_attachment(file.read(), maintype=maintype, subtype=subtype, filename=Path(attachment).name)
        return msg

    # method to send an email message with SMTP
    def _sendEmail(self, msg):
        retryCounter = 1
        # Get retry configuration from scriptConfig else use global defaults from emailConfig
        retries = self.scriptConfig['emailRetryCounter'] if 'emailRetryCounter' in self.scriptConfig else self.emailConfig['emailRetryCounter']
        retryEnabled = self.scriptConfig['emailRetryEnabled'] if 'emailRetryEnabled' in self.scriptConfig else self.emailConfig['emailRetryEnabled'] 
        failAfterRetry = self.scriptConfig['emailFailAfterRetry'] if 'emailFailAfterRetry' in self.scriptConfig else self.emailConfig['emailFailAfterRetry']
        retryLimit = retries if retryEnabled else 1 
        while retryCounter <= retryLimit:
            self.log(text='INFO : Email retry Attempt '+str(retryCounter)+'/'+str(retryLimit))
            try:  
                with smtplib.SMTP(self.emailConfig['server'], self.emailConfig['port'], timeout=self.emailConfig['timeout']) as s:
                    smtpCreds = json.load(open(self.secureDirectory/(self.env+'_smtpcreds.json')))
                    s.ehlo()
                    s.starttls()
                    s.login(smtpCreds['userId'], smtpCreds['passwd'])
                    #s.set_debuglevel(1) # DEBUG
                    self.log(text='Sending email to '+msg['To']+' from '+ self.emailConfig['sender']+ ' using '+ smtpCreds['userId']+'.')
                    if msg['bcc']:
                        self.log(text='Bcc: '+msg['bcc']+'.')
                    s.send_message(msg)
                    self.log(text='Email successfully sent.')
                    break
            except Exception as e:
                self.log(text='ERROR:'+str(e))
                # Configure script termination if email retry fails
                if retryCounter==retryLimit and failAfterRetry:
                    self.log(text='Email retry limit reached.')
                    raise ValueError("Sending email Failed. Terminating script.")
            retryCounter+=1
            
        
    # method to handle errors by logging
    def error(self, error, exit=True):
        _, _, exc_traceback = sys.exc_info()
        # get would-be printed lines of error traceback
        traceLines = traceback.format_exc().splitlines()
        # start log record with first line of traceback
        traceString = traceLines[0]+'\n'
        # fill in traceback information
        for x in traceback.format_tb(exc_traceback):
            traceString = traceString + x
        # add finishing line giving error type and error value
        traceString = traceString + traceLines[-1]
        # actually log the error trace and raise to test error type and choose appropriate error code
        try:
            raise error
        except OSError:
            self.log(text='OS/Filesystem error:\n '+traceString)
            errorCode = 4
        except pyodbc.Error:
            self.log(text='Database error:\n '+traceString)
            errorCode = 8
        except Exception:
            self.log(text='Script error:\n '+traceString)
            errorCode = 1
        if exit:
            sys.exit(errorCode)
        else:
            return errorCode
        
   # timer function
    def timer(self, limit, logging=False):
        minutes, seconds = divmod(limit, 60)
        if logging:
            self.log(text='Waiting for '+str(minutes)+' minutes and '+str(seconds)+' seconds...')
        # count down minutes (if more than zero)
        for m in range(minutes):
            if logging:
                self.log(text=str(minutes-m)+' minutes and '+str(seconds)+' remaining')
            for _ in range(60):
                time.sleep(1)
        # count down seconds
        for _ in range(seconds):
            time.sleep(1)
        if logging:
            self.log(text='Wait time finished, resuming script...')

    # list-chunking method
    def chunkList(self, list, chunkSize):
        return [list[i:i+chunkSize] for i in range(0, len(list), chunkSize)]


# main thread
if __name__ == '__main__':
    print('Running...')
    # perform unit test
    try:
        S = session(Path(__file__).stem, 'test') # remove ".py" from script name
        S.log(text='Wrapper compile complete')
        print('Script execution complete')
    except Exception as e:
        S.error(e)