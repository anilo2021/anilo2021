####################################################################################################
# Name:                 emailscript.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/common/emailscript.vsdx
# Command line usage:   python start.py email <subject> <body> <recipients> <attachment> <bcc>
# Purpose:              Send email as a standalone action
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-07-26 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from pathlib import Path
import sys

# local imports
from common.session import session # import a more specific framework class in most cases

# email function
def email(session, body, color=None, recipients=None, attachment=None, bcc=None):
    # by default, attach log file
    if attachment is None:
        attachment = session.logFileName
    # send email with generic method
    with open(session.repoDirectory/'common'/'emailTemplates'/('emailbody_default.html')) as template:
        session.email(body=template.read().format(body), # replace "{}" in template file with values
                      color=color,
                      recipients=recipients,
                      attachment=attachment,
                      bcc=bcc) # call basic email function

# main thread
if __name__ == "__main__":
    print('Running...')
    S = session(Path(__file__).stem, taskName=sys.argv[1].replace(' ', '_'))
    try:
        # format body argument
        body = sys.argv[1].replace('\\n', '<br>').replace('\\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
        # handle command line args
        if len(sys.argv) == 2:
            email(S, body)
        elif len(sys.argv) == 3:
            email(S, body, sys.argv[2])
        elif len(sys.argv) == 4:
            email(S, body, sys.argv[2], sys.argv[3].split(','))
        elif len(sys.argv) >= 5:
            email(S, body, sys.argv[2], sys.argv[3].split(','), sys.argv[4], sys.argv[5].split(','))
        print('Script execution complete')
    except Exception as e:
        S.error(e)