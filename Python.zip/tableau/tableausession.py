####################################################################################################
# Name:                 tableausession.py
# Python version:       Python 3.6.4
# Wiki path:            
# Command line usage:   N/A
# Purpose:              Class contains methods to call Tableau API resources
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2020-05-14 J. Rominske (jesr114@kellyservices.com)      Original Author
####################################################################################################

# library imports
import json
from pathlib import Path
import requests
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to Azure Data Warehouse Automation  
class tableauSession(session):
    # specific initialization method
    def _setup(self):
        self.directory = self.repoDirectory/'tableau'
        # load stored credentials from JSON file
        self.tableauCreds = json.load(open(self.secureDirectory/(self.env+'_tableaucreds.json')))
        # load session config
        self.tableauConfig = json.load(open(self.configDirectory/(self.env+'_tableauconfig.json')))
        self.tabServerConfig = [s for s in self.tableauConfig['sites'] if s['name'] == self.args[0]][0]
        # session variables for Tableau API interface
        self.tableauUrl = self.tabServerConfig['serverUrl']+'/api/'+self.tableauConfig['version'] # URL for the TSCA Dev Portal
        self.loginUrl = self.tableauUrl+'/auth/signin' # login URL for the Tableau API Service
        self.hdrs = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        self.req = requests.Session()

    # session method for logging into Azure Portal
    def login(self):
        # toggle login behavior for default versus secondary sites
        if 'contentUrl' in self.tabServerConfig:
            loginData = {
                'credentials': {
                    'name': self.tableauCreds['username'],
                    'password': self.tableauCreds['password'],
                    'site': {
                        "contentUrl": self.tabServerConfig['contentUrl']
                    }
                }
            }
        else:
            loginData = {
                'credentials': {
                    'name': self.tableauCreds['username'],
                    'password': self.tableauCreds['password']
                }
            }
        loginResponse = self.req.post(self.loginUrl, headers=self.hdrs, json=loginData)
        if loginResponse.status_code == 200: 
            self.log(text='Login Success')
            self.hdrs['X-Tableau-Auth'] = loginResponse.json()['credentials']['token']
            # grab site id for use in API call if not available
            if 'siteId' not in self.tabServerConfig:
                siteGetUrl = self.tableauUrl+'/sites/'+self.tabServerConfig['siteName']+'?key=name'
                siteIdResponse = self.req.get(siteGetUrl, headers=self.hdrs)
                self.tabServerConfig['siteId'] = siteIdResponse.json()['site']['id']
                self.log(text='Site '+self.tabServerConfig['siteName']+' resolved to ID '+self.tabServerConfig['siteId'])
            # set URI prefix for site accordingly
            self.uriSitePrefix = '/sites/'+self.tabServerConfig['siteId']
            return True
        else:
            self.log(text='Login Failed')
            self.log(text=loginResponse.text)
            return False

    # method for sending emails specific to Tableau
    def tableauEmail(self, body, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_tableau.html') as template:
            self.email(subject='Notification from the AIM Tableau Automation System', 
                       body=template.read().format(body), # replace "{}" in template file with values
                       recipients=recipients,
                       attachment=attachment) # call basic email function

    # method to send error report email for Tableau
    def tableauError(self, error, email=True):
        errorCode = self.error(error, exit=False) 
        if email:
            self.log(text='Sending error notification email...')
            self.tableauEmail('An error occurred with code: '+str(errorCode)+'<br>Please check the logs.')
        sys.exit(errorCode)
            
    # generic method for using Tableau API methods
    def _doAPI(self, reqType, uri, jsonData={}, getList=None, headers=None):
        # deal with arguments
        url = self.tableauUrl+uri
        if not headers:
            headers = self.hdrs
        self.log(text='\tAccessing API resource at '+url)
        # switch method use based on request type
        if reqType == 'GET':
            getResponseJson = self.req.get(url, headers=headers).json()
            # activate pagination logic if applicable
            if 'pagination' in getResponseJson:
                fullGet = []
                # if there are elements to GET proceed with pagination
                if getList[1] in getResponseJson[getList[0]]:
                    fullGet = getResponseJson[getList[0]][getList[1]]
                    pageNumber = 1
                    # check the pagination object for need to get more pages
                    while int(getResponseJson['pagination']['totalAvailable']) > len(fullGet):
                        pageNumber += 1
                        paginationSuffix = '?pageSize='+getResponseJson['pagination']['pageSize']+'&pageNumber='+str(pageNumber)
                        pageResponseJson = self.req.get(url+paginationSuffix, headers=headers).json()
                        fullGet = fullGet+pageResponseJson[getList[0]][getList[1]]
                return fullGet
            else:
                return getResponseJson
        # perform POST request
        if reqType == 'POST':
            return self.req.post(url, headers=headers, json=jsonData)
        # perform PATCH request
        elif reqType == 'PATCH':
            return self.req.patch(url, headers=headers, json=jsonData)
        # perform PUT request
        elif reqType == 'PUT':
            return self.req.put(url, headers=headers, json=jsonData)
        # perform DELETE request
        elif reqType == 'DELETE':
            return self.req.delete(url, headers=headers)
    
    # method to get a data source by ID
    def dataSourceGet(self, dataSourceId):
        return self._doAPI('GET', self.uriSitePrefix+'/datasources/'+dataSourceId)
    # method to get the extract refresh tasks in a schedule
    def extractRefreshesScheduleGet(self, scheduleId):
        return self._doAPI('GET', self.uriSitePrefix+'/schedules/'+scheduleId+'/extracts', getList=['extracts', 'extract'])
    # method to get the extract refresh tasks in a schedule
    def extractRefreshGet(self, taskId):
        return self._doAPI('GET', self.uriSitePrefix+'/tasks/extractRefreshes/'+taskId)
    # method to get the extract refresh tasks in a schedule
    def extractRefreshRun(self, taskId):
        return self._doAPI('POST', self.uriSitePrefix+'/tasks/extractRefreshes/'+taskId+'/runNow')
    # method to get details of a job on a given site
    def jobGet(self, jobId):
        return self._doAPI('GET', self.uriSitePrefix+'/jobs/'+jobId)
    # method to get the active jobs on a given site
    def jobsGet(self):
        return self._doAPI('GET', self.uriSitePrefix+'/jobs', getList=['backgroundJobs', 'backgroundJob'])
    # method to get all schedules in the user subscription
    def schedulesGet(self):
        return self._doAPI('GET', '/schedules', getList=['schedules', 'schedule'])
    # method to get details of a workbook
    def workbookGet(self, workbookId):
        return self._doAPI('GET', self.uriSitePrefix+'/workbooks/'+workbookId)


# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    T = tableauSession(Path(__file__).stem, 'test')
    try:
        if not T.login():
            print('Login error - aborted')
        else: 
            T.log(text='Class compile test complete')
            print('Script execution complete')
    except Exception as e:
        T.error(e)