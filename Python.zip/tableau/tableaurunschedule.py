####################################################################################################
# Name:                 tableaurunschedule.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/tableau/tableaurunschedule.vsdx
# Command line usage:   python start.py tableaurunschedule <serverName> <scheduleName> <monitorTimeout>
# Purpose:              Execute a schedule on a given Tablaeu server
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2020-05-21 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
from pathlib import Path
import multiprocessing
import sys
import time
# local module imports
from tableau.tableausession import tableauSession

# main script logic
def tableauRunSchedule(session, scheduleName, indicatorTaskName, timeoutProcess, period):
    # disable script run according to config`
    if session.scriptConfig['disabled']:
        return False
    success = False
    # get the ID of the indicated schedule from thge list of schedules on the server
    schedulesList = session.schedulesGet()
    scheduleId = [s for s in schedulesList if s['name'] == scheduleName][0]['id']
    # get all the extract refresh tasks within the indicated schedule
    scheduleExtractsList = session.extractRefreshesScheduleGet(scheduleId)
    session.createJsonFile('json/sched.json', scheduleExtractsList)
    # run and monitor all the extract refresh tasks within the schedule in parrallel subprocesses
    if len(scheduleExtractsList) != 0:
        # find indicator task in list by getting each data source by ID and checking its name
        indicatorTaskId = None
        session.log(text='Isolating indicator task '+indicatorTaskName+'...')
        for task in scheduleExtractsList:
            # handle datasource type
            if 'datasource' in task:
                dataSource = session.dataSourceGet(task['datasource']['id'])
                # if the inidcator task is found, stop the loop
                if dataSource['datasource']['name'] == indicatorTaskName:
                    indicatorTaskId = task['id']
                    session.log(text='Task with ID '+indicatorTaskId+' isolated as indicator task')
                    break
            # handle workbook type
            elif 'workbook' in task:
                workbook = session.workbookGet(task['workbook']['id'])
                # if the inidcator task is found, stop the loop
                if workbook['workbook']['name'] == indicatorTaskName:
                    indicatorTaskId = task['id']
                    session.log(text='Task with ID '+indicatorTaskId+' isolated as indicator task')
                    break
            else:
                ValueError('Unsupported schedule task type! Terminating script...')
        # if indicator task not found, raise error
        if not indicatorTaskId:
            raise ValueError('Indicator task '+indicatorTaskName+' not found in schedule! Terminating script...')
        # generate list of tasks with status and return data fields
        taskIdList = [task['id'] for task in scheduleExtractsList if task['id'] != indicatorTaskId]
        # execute all tasks but the inidcator task
        session.log(text='Starting schedule tasks...')
        for taskId in taskIdList:
            runResponse = session.extractRefreshRun(taskId)
            if runResponse.status_code == 200:
                session.log(text='Task with ID '+taskId+' started successfully.')
            else:
                session.log(text=runResponse.content.decode('utf-8'))
                raise ValueError('Task with ID '+taskId+' failed to start! Terminating script...')
        # execute and monitor the indicator task
        session.log(text='Starting indicator task...')
        if extractRefreshMonitor(session, indicatorTaskId, timeoutProcess, period):
            # if indicator task succeeded, schedule likely did as well
            session.log(text='Schedule completed successfully.')
            success = True
        else:
            session.log(text='Schedule failed!')
    # if no tasks to run, report and end script
    else:
        session.log(text='Schedule contains no tasks!')
        success = True
    # kill the subprocess if necessary
    if timeoutProcess.is_alive():
        timeoutProcess.terminate()
    # handle failure
    if not success:
        sys.exit(1)

# method to run extract refresh task status
def extractRefreshMonitor(session, taskId, timeoutProcess, period):
    session.log(text='Executing task with ID '+taskId)
    success = False # default to failure
    # execute task with given ID and update status
    runResponse = session.extractRefreshRun(taskId)
    # if there is an error, report it and stop the subprocess
    if runResponse.status_code != 200:
        session.log(text='Exectuing task with ID '+taskId+' failed!')
        session.log(text=runResponse.content.decode('utf-8'))
        return success
    # if there is no error, monitor the job until it completes or the timeout elapses
    else:
        errorHappened = False
        jobId = runResponse.json()['job']['id']
        session.log(text='Monitoring status for job with ID '+str(jobId)+' with '+str(period)+'-second interval')
        while timeoutProcess.is_alive():
            try:
                # get job status and check if completed
                jobStatus = session.jobGet(jobId)['job']
                # reset error flag to indicate successful recovery, if applicable
                errorHappened = False
                # if job completed, report error or output
                if 'completedAt' in jobStatus:
                    # toggle status report based on response
                    jobExitStatus = int(jobStatus['finishCode'])
                    if jobExitStatus == 0:
                        session.log(text='Extract Refresh Job with ID '+taskId+' succeeded!')
                        success = True # report success
                    else:
                        session.log(text='Extract Refresh Job with ID '+taskId+' failed!')
                    session.log(text=jobStatus['extractRefreshJob']['notes'])
                    break
                # if job not completed, execute wait period
                else:
                    session.timer(period)
            except Exception as e:
                # fail if it has failed before
                if errorHappened:
                    raise e
                # try again if it has not yet failed
                else:
                    errorHappened = True
                    session.error(e, exit=False)
                    session.log('Exception handled. Attempting to resume monitoring...')
        return success


# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['tableau'] = tableauSession(Path(__file__).stem, sys.argv[1]+'_'+sys.argv[2], args=[sys.argv[1]])
    try:
        if not sessionContainer['tableau'].login():
            print('Login error - aborted')
        else:
            # handle command line args
            monitorTimeout = 300 if int(sys.argv[4]) < 5 else int(sys.argv[4])*60 # at least 5 minutes
            period = 60 if int(sys.argv[5]) < 1 else int(sys.argv[5])*60 # at least one minute
            # set timeout as secondary process using third argument
            timeoutProcess = multiprocessing.Process(target=sessionContainer['tableau'].timer, args=[monitorTimeout])
            timeoutProcess.start()
            tableauRunSchedule(sessionContainer['tableau'], sys.argv[2], sys.argv[3], timeoutProcess, period)
            print('Script execution complete')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        sessionContainer['tableau'].tableauError(e, email=sessionContainer['tableau'].scriptConfig['errorNotification'])