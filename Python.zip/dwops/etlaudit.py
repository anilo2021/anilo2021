####################################################################################################
# Name:                 etlaudit.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/dwops/etlaudit.vsdx
# Command line usage:   python start.py etljobstart <jobId> <batchId>
# Purpose:              Runs predefined audits on provided job in provided batch
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2018-10-10 J. Rominske (jesr114@kellyservices.com)       Major logic revision
####################################################################################################

# library imports
import os
import sys
# local module imports
from dwops.dwopssession import dwopsSession

# determines audit status based on severity and success/failure
def auditStatus(session, jobId, batchId, auditSeverity):
    session.log(text='Determining audit success for job '+str(jobId)+' from batch '+str(batchId))
    params = (
        jobId,
        batchId,
        auditSeverity
    )
    session.executeSqlFile('auditVarSel.sql', params=params)
    # return status based on AuditVariance result
    if session.cursor.fetchone().AuditVariance != 0.00:
        return False
    else:
        return True

# audits the data transferred by a job from source to target
def etlAudit(session, auditType, jobId, batchId, login=False):
    session.log(text='Beginning job audit...')
    # set default audit status to success
    status = 'S'
    # login if necessary
    if login:
        # login to db
        session.login('DWAUDIT')
    # check if audits exist for job
    session.log(text='Checking for audits to execute for job with ID '+str(jobId))
    session.executeSqlFile('auditCnt.sql', params=jobId)
    # if no audits, end script
    if session.cursor.fetchone().AuditCount == 0:
        session.log(text='No audits found for job with ID '+str(jobId)+'\n')
        return status if auditType == 'target' else None

    # use jobName and to get Audit from table
    session.executeSqlFile('auditSel.sql', params=jobId)
    jobRows = session.cursor.fetchall()
    for jobRow in jobRows:
        if auditType == 'source':
            # perform audit query on source
            session.log(text='Performing source audit on '+jobRow.SourceConnectionName)
            srcConnection = session.login(jobRow.SourceConnectionName)
            srcCursor = srcConnection.cursor()
            session.log(text='Executing SQL:\n'+jobRow.SourceSqlStatement)
            srcCursor.execute(jobRow.SourceSqlStatement)
            auditRows = srcCursor.fetchall()
            # insert data from source audit
            for auditRow in auditRows:
                session.log(text='Reconciling audit '+auditRow.AUDITIDENTIFIER+' with source results')
                params = (
                    auditRow.SOURCEMETRIC,
                    jobRow.AuditId,
                    jobId,
                    auditRow.AUDITTYPE,
                    auditRow.AUDITIDENTIFIER,
                    batchId,
                    auditRow.AUDITSEVERITY
                )
                session.executeSqlFile('auditSrcIns.sql', params=params, commit=True)
            srcCursor.close()
            srcConnection.close()

        elif auditType == 'target':
            # perform audit query on target
            session.log(text='Performing target audit on '+jobRow.TargetConnectionName)
            tgtConnection = session.login(jobRow.TargetConnectionName)
            tgtCursor = tgtConnection.cursor()
            session.log(text='Executing SQL:\n'+jobRow.TargetSqlStatement)
            tgtCursor.execute(jobRow.TargetSqlStatement)
            auditRows = tgtCursor.fetchall()
            for auditRow in auditRows:
                # update target column
                session.log(text='Reconciling audit '+auditRow.AuditIdentifier+' with target results')
                tgtParams = (
                    auditRow.TARGETMETRIC,
                    batchId,
                    jobId,
                    auditRow.AuditType,
                    auditRow.AuditIdentifier,
                    jobRow.AuditId
                    )
                session.executeSqlFile('auditTgtUpd.sql', params=tgtParams, commit=True)
                # update variance column for target audits
                session.log(text='Reconciling audit '+auditRow.AuditIdentifier+' with variance')
                varParams = (
                    batchId,
                    jobId,
                    auditRow.AuditType,
                    auditRow.AuditIdentifier
                    )
                session.executeSqlFile('auditVarUpd.sql', params=varParams, commit=True)
            tgtCursor.close()
            tgtConnection.close()
  
    # deal with status return for target audits 
    if auditType == 'target':
        # if any critical audits fail, set status to failed
        if not auditStatus(session, jobId, batchId, 'CRITICAL'):
            status = 'F'
        # if only non-critical audits fail, set status to warning
        if not auditStatus(session, jobId, batchId, 'WARNING'):
            if status == 'S':
                status = 'W'
        return status

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['dwops'] = dwopsSession(os.path.basename(__file__)[:-3], taskName=sys.argv[1]) # remove ".py" from script name
    try:
        etlAudit(sessionContainer['dwops'], sys.argv[1], sys.argv[2], sys.argv[3], True)
        sessionContainer['dwops'].logout()
        print('Script execution complete')
    except Exception as e:
        sessionContainer['dwops'].dwopsError(e)