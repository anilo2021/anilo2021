####################################################################################################
# Name:                 etlbatchendrpt.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/dwops/etlbatchendrpt.vsdx
# Command line usage:   python start.py etlbatchendrpt <batchName> <jobTaskflowName>
# Purpose:              Reports results of the last audits run using rpt_AuditResLastRun.sql
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-09-12 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import csv
import datetime
import os
from pathlib import Path
import sys
# local module imports
from dwops.dwopssession import dwopsSession

# runs Audit Last Run Results SQL report and sends in CSV file through email
def etlBatchEndRpt(session, batchName, jobTaskflowName):
    session.log(text='Beginning batch end report: Audit Results Data Load To SqlDw')
    # login to db
    session.login('DWAUDIT')
    # get batch ID
    session.log(text='Getting current batch ID')
    session.executeSqlFile('batchIdSel.sql')
    batchId = session.cursor.fetchone().JobParameterValue
    # run Audit Results Last run report
    session.executeSqlFile('rpt_AuditResLastRun.sql', params=[batchId, jobTaskflowName])
    auditRpt = session.cursor.fetchall()
    # create rpt directory if not existent
    rptDirectory = session.directory/'rpt'
    rptDirectory.mkdir(parents=True, exist_ok=True)
    # generate file name using timestamp
    now = datetime.datetime.today()
    fileTimestamp = now.strftime('%Y-%m-%d_%H-%M-%S')
    auditRptFileName = 'auditRptLastRun_'+fileTimestamp+'.csv'
    auditRptPath = rptDirectory/auditRptFileName
    # create CSV file and send as attachment in email
    with open(auditRptPath, 'w', newline='') as csvfile:
        session.log(text='Creating CSV report file at '+str(auditRptPath))
        csvWriter = csv.writer(csvfile, delimiter=',')
        csvWriter.writerow([c[0] for c in session.cursor.description]) # column headers
        for row in auditRpt:
            csvWriter.writerow(row)
    # send email
    session.log(text='Sending batch end report email')
    session.dwopsEmail(subject='Audit Result For '+batchName+' Data Load To SqlDw',
                        body='AIM ETL batch '+batchName+' complete. Review attached audit results report for any variance.',
                        attachment=auditRptPath,
                        recipients= ["AIMDataPlatformOps@kellyservices.com"])

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['dwops'] = dwopsSession(Path(__file__).stem, taskName=sys.argv[1])
    try:
        etlBatchEndRpt(sessionContainer['dwops'], sys.argv[1], sys.argv[2])
        sessionContainer['dwops'].logout()
        print('Script execution complete')
    except Exception as e:
        sessionContainer['dwops'].dwopsError(e)