--  Update status of given audit for given batch and identifier
UPDATE DwOpsAuditReconciliation 
SET 
    TargetMetric = {},
    DwLastModifiedDate = CURRENT_TIMESTAMP
FROM DwOpsAuditTopReconVW
WHERE DwOpsAuditReconciliation.BatchId = DwOpsAuditTopReconVW.BatchId
	AND DwOpsAuditReconciliation.JobId = DwOpsAuditTopReconVW.JobId
	AND DwOpsAuditReconciliation.AuditType = DwOpsAuditTopReconVW.AuditType
	AND DwOpsAuditReconciliation.AuditIdentifier = DwOpsAuditTopReconVW.AuditIdentifier
    AND DwOpsAuditReconciliation.AuditId = DwOpsAuditTopReconVW.AuditId
    AND DwOpsAuditReconciliation.AuditReconId = DwOpsAuditTopReconVW.AuditReconId
    AND DwOpsAuditReconciliation.BatchId = {}
	AND DwOpsAuditReconciliation.JobId = {}
	AND DwOpsAuditReconciliation.AuditType = '{}'
	AND DwOpsAuditReconciliation.AuditIdentifier = '{}' 
    AND DwOpsAuditReconciliation.AuditId = {} ;