-- Select audit having given AuditId, JobId and BatchId 
SELECT Coalesce(SUM(AuditVariance),0) AS AuditVariance FROM 
(SELECT AuditIdentifier, AuditVariance, ROW_NUMBER() OVER (PARTITION BY AuditIdentifier, AuditId ORDER BY  DwLastModifiedDate DESC) AS RNK FROM
DwOpsAuditReconciliation
WHERE JobId = {} -- JobId
  AND BatchId = {}  -- BatchId
  AND AuditSeverity = '{}'
  ) A 
  WHERE RNK = 1 
;