-- Select jobId given jobName
SELECT
    *
FROM DwOpsJobDescription
WHERE JobTaskName = '{}'