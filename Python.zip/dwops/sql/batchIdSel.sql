-- Select batch with given batchId if open
SELECT
    JobParameterValue
FROM DwOpsJobParameter
WHERE JobParameterName = 'CurrentBatchId'