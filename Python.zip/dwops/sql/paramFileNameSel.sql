-- Select jobId given jobName
SELECT
    JobParameterFileName
FROM DwOpsJobDescription
WHERE JobId = '{}'