-- Select jobId given jobName
SELECT
    JobId
FROM DwOpsJobDescription
WHERE {} = '{}' 
  AND JobParameterFileAvailableIndicator = 'Y'