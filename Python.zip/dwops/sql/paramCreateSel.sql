-- Select param given jobId
SELECT
    JobParameterName,
    JobParameterValue
FROM DwOpsJobParameter
WHERE JobId IS NULL OR JobId = {} ; -- jobId