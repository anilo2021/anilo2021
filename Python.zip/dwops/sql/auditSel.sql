-- Select audit having given jobId and audit severity
SELECT * FROM DwOpsAuditDefinition  
WHERE JobId = {} OR JobId IS NULL;