--  Update status of given audit for given batch and identifier
UPDATE DwOpsAuditReconciliation
SET
    AuditVariance = a.SourceMetric + a.TargetMetric * -1
FROM DwOpsAuditReconciliation AS a
WHERE 
    a.BatchId = {} -- batchId
    AND (a.JobId = {} OR a.JobId IS NULL)
    AND a.AuditType = '{}' -- AuditType 
    AND a.AuditIdentifier = '{}' -- auditIdentifier
    AND a.AuditVariance is null; 