-- Insert contents of an audit file (.rdy) into the database during file audit
INSERT INTO DwOpsFileAuditLog (
    [BatchId],
    [FileName],
    [FileDate],
    [RowCount],
    [Amount],
    [DwLastModifiedDate]
) 
SELECT 
    {} AS BatchId,    -- BatchId 
    '{}' AS FileName, -- first column of file
    '{}' AS FileDate, -- second column of file
    '{}', --AS RowCount, -- third column of file
    '{}' AS Amount,    -- fourth column of file
    CURRENT_TIMESTAMP AS DwLastModifiedDate
; 
