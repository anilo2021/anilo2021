-- Select audit having given jobId
SELECT count(*) as AuditCount
 FROM DwOpsAuditDefinition  
WHERE JobId = {} OR JobId IS NULL;