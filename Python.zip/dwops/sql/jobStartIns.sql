-- Insert new job instance record on job start
INSERT INTO DwOpsLoadJob
(JobStartTime
      ,JobEndTime
      ,JobStatus
      ,SourceRecordCount
      ,TargetinsertRecordCount
      ,TargetupdateRecordCount
      ,TargetdeleteRecordCount
      ,BatchId
      ,JobId
      ,DwLastModifiedUserId
      ,DwLastModifiedDate)
SELECT
    CURRENT_TIMESTAMP AS JobStartTime, -- JobStartTime
    NULL AS JobEndTime, -- JobEndTime
    'P' JobStatus, -- JobStatus
    NULL AS SourceRecordCount, -- SourceRecordCount (CHANGE LATER)
    NULL AS TargetInsertRecordCount, -- TargetinsertRecordCount (CHANGE LATER)
    NULL AS TargetUpdateRecordCount, -- TargetupdateRecordCount (CHANGE LATER)
    NULL AS TargetDeleteRecordCount, -- TargetdeleteRecordCount (CHANGE LATER)
    {} AS BatchId, -- batchId
    {} AS JobId, -- jobId
    'DwAudit' AS DwLastModifiedUserId, 
    CURRENT_TIMESTAMP AS DwLastModifiedDate  
;