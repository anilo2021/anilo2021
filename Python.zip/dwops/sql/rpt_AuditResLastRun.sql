/*** Query to last CDC audit report - order by Tablename ***/

SELECT A.*, CASE WHEN a.variance <> 0 THEN 'AUDIT FAILED' WHEN a.variance = 0 THEN 'AUDIT PASS' END AS AuditResult FROM 
(SELECT CAST(btch.DwlastmodifiedDate as date) as AuditAsOf, 
              CASE WHEN vw.SourceDesc ='FN' THEN 'PeopleSoft FN' WHEN vw.SourceDesc ='HR' THEN 'PeopleSoft HR' END AS SourceSystem, 'SqlDw' AS TargetSystem, 
              UPPER(vw.AuditIdentifier) AS TableName, 
              Recon.AuditSeverity, 
              vw.AuditType, 
        CAST(recon.SourceMetric AS decimal(38,5)) - CAST(recon.TargetMetric AS decimal(38,5)) as Variance
   FROM DwOpsAuditTopReconVW VW JOIN DwOpsLoadBatch btch on VW.batchid = btch.batchid and btch.batchid = {}
              JOIN DwOpsAuditReconciliation Recon on recon.AuditReconId = VW.AuditReconId 
              JOIN DwOpsJobDescription Jdesc on Jdesc.JobId = Recon.JobId
              and Jdesc.JobTaskflowname = '{}' )  A
                     order by a.TableName, a.AuditType;