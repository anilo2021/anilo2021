--  Update status of given job for given batch
UPDATE DwOpsLoadJob
SET
    JobEndTime = CURRENT_TIMESTAMP,
    DwLastModifiedDate = CURRENT_TIMESTAMP, 
    JobStatus = '{}' -- res.JobStatus
WHERE 
    BatchId = {} -- batchId
    AND JobId = {} -- jobId