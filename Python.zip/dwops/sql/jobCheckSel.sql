-- Select job from given batch if open
SELECT
    *
FROM DwOpsLoadJob
WHERE  
    BatchId = {} -- batchId
    AND JobId = {} -- jobId