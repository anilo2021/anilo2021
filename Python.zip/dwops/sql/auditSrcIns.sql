-- Insert audit reconciliation when databases are not the same
INSERT INTO DwOpsAuditReconciliation
(SourceMetric, 
     TargetMetric, 
     AuditVariance, 
     AuditId,
     JobId,
     AuditType,
     AuditIdentifier,
     BatchId,
     AuditSeverity,
     DwCreatedDate,
     DwLastModifiedUserId, 
     DwLastModifiedDate)
SELECT
    {} AS SourceMetric,
    null AS TargetMetric,
    null AS AuditVariance,
    {} AS AuditId,
    {} AS JobId,
    '{}' AS AuditType,
    '{}' AS AuditIdentifier,
    {} AS BatchId,
    '{}' AS AuditSeverity,
    CURRENT_TIMESTAMP AS DwCreatedDate,
    'DwAudit' AS DwLastModifiedUserId,
    CURRENT_TIMESTAMP AS DwLastModifiedDate
;