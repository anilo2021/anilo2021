####################################################################################################
# Name:                 dwopssession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/5/dwopssession
# Command line usage:   N/A
# Purpose:              Class contains methods for Data Warehouse Operations automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)      Original Author
####################################################################################################

# library imports
import json
import os
import pyodbc
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to DW Operations
class dwopsSession(session):    
    # overloaded setup function
    def _setup(self):
        self.creds = json.load(open(self.secureDirectory/(self.env+'_dwopscreds.json'))) # self.secureDirectory/(self.env+'_dwopscreds.json')
        self.config = json.load(open(self.configDirectory/(self.env+'_dwopsconfig.json')))
        self.directory = self.repoDirectory/'dwops'

    # logs user in and adds an authenticated session id to header              
    def login(self, connName):
        self.log(text='Logging into '+connName+'...')
        creds = self.creds[connName]
        # retry as configured
        succeeded = False
        loginConfig = self.config['login']
        retryCount = 0
        while not succeeded:
            try:
                # switch object structure based on given dbType
                if creds['dbType'] == 'Microsoft':
                    if 'dsn' in creds:
                        c = pyodbc.connect('DSN='+creds['dsn']+';'+
                                        'UID='+creds['userId']+';'+
                                        'PWD='+creds['passwd'],
                                        timeout=loginConfig['timeout'])
                    else:
                        c = pyodbc.connect('DRIVER={'+creds['driver']+'};'+
                                        'SERVER='+creds['server']+';'+
                                        'DATABASE='+creds['dbName']+';'+
                                        'UID='+creds['userId']+';'+
                                        'PWD='+creds['passwd'],
                                        timeout=loginConfig['timeout'])
                elif creds['dbType'] == 'Teradata':
                    c = pyodbc.connect('DRIVER={'+creds['driver']+'};'+
                                    'DBCNAME='+creds['dbcName']+';'+
                                    'UID='+creds['userId']+';'+
                                    'PWD='+creds['passwd'],
                                    timeout=loginConfig['timeout'])
                elif creds['dbType'] == 'Oracle':
                    c = pyodbc.connect('DRIVER={'+creds['driver']+'};'+
                                    'DBQ='+creds['dbq']+';'+
                                    'UID='+creds['userId']+';'+
                                    'PWD='+creds['passwd'],
                                    timeout=loginConfig['timeout'])
                elif creds['dbType'] == 'Snowflake':
                    c = pyodbc.connect('DRIVER={'+creds['driver']+'};'+
                                       'SERVER='+creds['server']+';'+
                                       'DATABASE='+creds['dbName']+';'+
                                       'UID='+creds['userId']+';'+
                                       'PWD='+creds['passwd'],
                                       timeout=loginConfig['timeout'])
                succeeded = True
                self.log(text='Login Success')
            except Exception as e:
                retryCount += 1
                # if still within retryMax, log error, wait, and continue
                if retryCount <= loginConfig['retryMax']:
                    self.error(e, exit=False)
                    self.log(text='Login failure! Retrying in '+str(loginConfig['retryWait'])+' seconds...')
                    self.timer(loginConfig['retryWait'])
                # if retryMax reached, simply raise error again for default error handling
                else:
                    raise e
        # if main session login, store connection, cursor in session instance
        if connName == 'DWAUDIT':
            self.connection = c
            self.cursor = c.cursor()
        # for normal login, return connection
        else:
            return c
    
    # logs user out to end session (best practice)
    def logout(self, connection=None):
        if not connection:
            connection = self.connection
        connection.close()
        self.log(text='Logout successful')

    # method to run query defined in a given file provided with appropriate params
    def executeSqlFile(self, fileName, cursor=None, params=(), commit=False):
        # use session cursor by default
        if not cursor:
            cursor = self.cursor
        # open file from sql directory and execute contents on cursor
        with open(self.directory/'sql'/fileName) as q:
            # fill in param markers with values, unpacking lists if needed
            query = q.read().format(*params) if isinstance(params, (list, tuple)) else q.read().format(params)
            try: 
                self.log(text='Executing SQL from '+fileName+':\n'+query+'\n')
                cursor.execute(query)
            except Exception as e:
                self.error(e)
        # commit to the db if specified
        if commit:
            self.connection.commit()

    # method for sending emails specific to DW Ops
    def dwopsEmail(self, subject, body, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # by default, use dwopsRecipients
        if recipients is None:
            recipients = self.emailConfig['dwopsRecipients']
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_secureagent.html') as template:
            self.email(subject=subject,
                       body=template.read().format(body), # replace "{}" in template file with values
                       attachment=attachment, recipients=recipients) # call basic email function

    # method for send error report email for DW Ops
    def dwopsError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.dwopsEmail('Notification from AIM ETL Audit System',
                            'An error occurred with code: '+str(errorCode)+'<br>Please check the logs.')
        sys.exit(errorCode)

# regression test for class methods
def test(session):
    # test login credentials/drivers
    loginErrors = []
    for cred in session.creds:
        try:
            conn = session.login(cred)
            session.logout(conn)
        except Exception as e:
            session.error(e, exit=False)
            loginErrors.append(cred)
    if len(loginErrors) > 0:
        for credEntry in loginErrors:
            session.log(text='Login error for credential: '+credEntry)
        raise pyodbc.Error('Connection tests failed.') 

# main thread
if __name__ == '__main__':
    print('Running...')
    # perform unit test
    try:
        D = dwopsSession(os.path.basename(__file__)[:-3], 'test')
        test(D)
        print('Script execution complete')
    except Exception as e:
        D.dwopsError(e, email=False)