# etlparamfilecreate.py
# Original Author: Jesse Rominske (jesr114@kellyservices.com)
# Python version 3.6.4
# Command Line Usage: python etlparamfilecreate.py jobTaskFlowName
# Function:
#   - Creates parameter file for given IICS taskflow 
#   - Gets parameters relevant to taskflow with given name and generates files
#     containing parameters and named based on each job name
# Revision History:
#   - 1.0 - 2018/08/16 by Jesse Rominske (jesr114@kellyservices.com)

# library imports
import os
from pathlib import Path
import sys
# local module imports
from dwops.dwopssession import dwopsSession

# starts/restarts a batch with given jobName and jobId
def etlParamFileCreate(session, jobTaskFlowName=None, jobName=None):
    # login to db
    session.login('DWAUDIT')
    # Get list of all jobTaskId for which parameter files need to be created
    session.log(text='Getting jobs for which to create parameter files...')
    if jobName is not None:
        session.executeSqlFile('paramJobIdSel.sql', params=('JobTaskName', jobName))
    else:
        session.executeSqlFile('paramJobIdSel.sql', params=('JobTaskflowName', jobTaskFlowName))
    jobs = session.cursor.fetchall()
    # generate all relevant param files
    for job in jobs:
        # get list of params
        jobId = job.JobId
        session.log(text='Getting list of parameters')
        session.executeSqlFile('paramCreateSel.sql', params=jobId)
        params = session.cursor.fetchall()
        # get param file name based on job ID
        session.log(text='Getting param file name based on job ID '+str(jobId))
        session.executeSqlFile('paramFileNameSel.sql', params=jobId)
        paramFileName = session.cursor.fetchone().JobParameterFileName
        if paramFileName.split('.')[-1] != 'param':
            paramFileName = paramFileName+'.param'
        # create parameters folder if it does not already exist
        # ../../../UserParameters represented in terms of pathlib
        paramPath = Path('\\\\amer\\dfs\\aim'+session.serverEnv+'\\iics\\infa'+session.env+'\\sa_aim\\data\\userparameters') # change if param directory moves
        paramPath.mkdir(parents=True, exist_ok=True)
        # write params to file, one param per line
        with open(paramPath/paramFileName, 'w') as paramFile:
            session.log(text='Creating parameter file '+paramFileName+' in directory '+str(paramPath))
            for param in params:
                paramFile.write('$$'+param.JobParameterName+'='+param.JobParameterValue+'\n')

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['dwops'] = dwopsSession(Path(__file__).stem, taskName=sys.argv[1])
    try:
        if sys.argv[1] == '-mct':
            etlParamFileCreate(sessionContainer['dwops'], jobName=sys.argv[2])
        else:
            etlParamFileCreate(sessionContainer['dwops'], jobTaskFlowName=sys.argv[1])
        sessionContainer['dwops'].logout()
        print('Script execution complete')
    except Exception as e:
        sessionContainer['dwops'].dwopsError(e, email=sessionContainer['dwops'].scriptConfig['errorNotification'])