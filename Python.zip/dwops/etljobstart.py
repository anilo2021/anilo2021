####################################################################################################
# Name:                 etljobstart.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/dwops/etljobstart.vsdx
# Command line usage:   python start.py etljobstart <jobName>
# Purpose:              Records the start of an IICS job in Audit database
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import csv
from pathlib import Path
import sys
from tarfile import TarFile
from zipfile import ZipFile
# local module imports
from dwops.dwopssession import dwopsSession
from fileops.fileopssession import fileopsSession 
from dwops.etlaudit import etlAudit
from dwops.etlparamfilecreate import etlParamFileCreate

# function for performing file audit on load
def etlLoadFileAudit(session, jobDesc, batchId):
    # define file path constants
    aimenv = 'dev' if session['dwops'].env != 'prd' else session['dwops'].env
    inboundRoot = Path('//amer/dfs/aim'+aimenv+'/iics/infa'+session['dwops'].env+'/file_transfer/aim/inbound')
    inboundDirectory = inboundRoot/(jobDesc.JobSourceDirectorySufix.replace('\\', '/'))
    fileFormat = jobDesc.JobFilePreFix
    filePrefix = fileFormat[:fileFormat.find('*')] # prefix is everything before the asterisk
    fileSuffix = fileFormat[fileFormat.find('*')-1:] # suffix is everything after the asterisk
    
    # handle extracting from compressed archive if applicable
    if jobDesc.JobIsCompressIndicator == 'Y':
        # get list of compressed files in inbound directory
        compressedFileList = session['fileops'].fileList(inboundDirectory, prefixes=[filePrefix], includeExts=['.zip', '.tar'])
        # extract all in archive for every archive in list
        for compressed in compressedFileList:
            if compressed.name.endswith('.zip'):
                with ZipFile(compressed, 'r') as zipFile:
                    zipFile.extractall(inboundDirectory)
            elif compressed.name.endswith('.tar'):
                with TarFile(compressed, 'r') as tarFile:
                    tarFile.extractall(inboundDirectory)
            session['fileops'].fileArchive(compressed, archiveDirectory=inboundRoot/'_archive', zip=False, delete=True)
    
    # handle converting to CSV if applicable
    if jobDesc.JobIsConvert2CsvIndicator == 'Y':
        # get all relevant Excel files in inbound directory and convert them to CSV (archiving and deleting Excel files)
        excelFiles = session['fileops'].fileList(inboundDirectory, prefixes=[filePrefix], includeExts=[fileSuffix])
        for excelFile in excelFiles:
            session['fileops'].fileExcelToCSV(excelFile, archive=inboundRoot/'_archive', zip=True, delete=True)
    
    # list non-audit files in directory, generate list file, and archive
    fileList = session['fileops'].fileList(inboundDirectory, fileName=inboundRoot/(filePrefix+'.lst'), prefixes=[filePrefix], excludeExts=['.rdy'])
    for f in fileList:
        session['fileops'].fileArchive(f, archiveDirectory=inboundRoot/'_archive', zip=True)
    
    # list audit files in directory and deal with each one
    auditList = session['fileops'].fileList(inboundDirectory, prefixes=[filePrefix], includeExts=['.rdy'])
    for auditFile in auditList:
        # load second row of each audit file into database
        rdy = csv.reader(open(auditFile))
        _ = next(rdy) # discard column names
        values = next(rdy) # grab audit values
        session['dwops'].executeSqlFile('auditFileIns.sql', params=[batchId]+values, commit=True)
        session['fileops'].fileArchive(auditFile, archiveDirectory=inboundRoot/'_archive', zip=True)

# starts/restarts a batch with given batchId and jobName
def etlJobStart(session, jobName, paramFile=False, audit=True):
    # login to db
    session['dwops'].login('DWAUDIT')
    # get job ID and Desc based on job name
    session['dwops'].log(text='Getting job ID based on job name '+jobName)
    session['dwops'].executeSqlFile('jobDescSel.sql', params=jobName)
    jobDesc = session['dwops'].cursor.fetchone()
    jobId = jobDesc.JobId
    # get batch ID
    session['dwops'].log(text='Getting current batch ID')
    session['dwops'].executeSqlFile('batchIdSel.sql')
    batchId = session['dwops'].cursor.fetchone().JobParameterValue
    # check if job with batchId, jobId exists
    session['dwops'].log(text='Checking if job is currently running')
    params = (
        batchId, 
        jobId
    )
    session['dwops'].executeSqlFile('jobCheckSel.sql', params=params)
    topResult = session['dwops'].cursor.fetchone()
    # if entry exists
    if topResult != None:
        session['dwops'].log(text='Restarting job '+jobName)
        params = (
            'P', 
            batchId, 
            jobId
        )
        session['dwops'].executeSqlFile('jobStatusUpd.sql', params=params, commit=True)
    # if entry does not exist
    else:
        session['dwops'].log(text='Starting job '+jobName)
        params = (
            batchId, 
            jobId
        )
        session['dwops'].executeSqlFile('jobStartIns.sql', params=params, commit=True)
    # if necessary, create param file
    if paramFile:
        etlParamFileCreate(session['dwops'], jobId)
    # if necessary, run source audit
    if audit:
        # if necessary, run file audit first
        session['dwops'].executeSqlFile('jobDescSel.sql', params=jobName)
        if jobDesc.JobIsFileLoad == 'Y' and jobDesc.JobIsFileExtract == 'N':
            etlLoadFileAudit(session, jobDesc, batchId)
        # run DB audit
        etlAudit(session['dwops'], 'source', jobId, batchId)
        

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['dwops'] = dwopsSession(Path(__file__).stem, taskName=sys.argv[1])
    sessionContainer['fileops'] = fileopsSession('', '', logFileName=sessionContainer['dwops'].logFileName)
    try:
        auditFlag = False if '-noaudit' in sys.argv[2:] else True
        paramFlag = True if '-param' in sys.argv[2:] else False
        etlJobStart(sessionContainer, sys.argv[1], paramFile=paramFlag, audit=auditFlag)
        sessionContainer['dwops'].logout()
        print('Script execution complete')
    except Exception as e:
        sessionContainer['dwops'].dwopsError(e)