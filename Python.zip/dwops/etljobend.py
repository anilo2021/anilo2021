####################################################################################################
# Name:                 etljobend.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/dwops/etljobend.vsdx
# Command line usage:   python start.py etljobend <jobName>
# Purpose:              Records the end of an IICS job in Audit database
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from pathlib import Path
import sys
# local module imports
from dwops.dwopssession import dwopsSession
from fileops.fileopssession import fileopsSession
from dwops.etlaudit import etlAudit

# starts/restarts a batch with given batchId and jobName
def etlJobEnd(session, jobName, audit=True):
    # login to db
    session['dwops'].login('DWAUDIT')
    # get job ID based on job name
    session['dwops'].log(text='Getting job ID based on job name '+jobName)
    session['dwops'].executeSqlFile('jobIdSel.sql', params=jobName)
    jobId = session['dwops'].cursor.fetchone().JobId
    # get batch ID
    session['dwops'].log(text='Getting current batch ID')
    session['dwops'].executeSqlFile('batchIdSel.sql')
    batchId = session['dwops'].cursor.fetchone().JobParameterValue
    # run audit script and record success or failure
    if audit:
        # if necessary, run file audit first
        session['dwops'].executeSqlFile('jobDescSel.sql', params=jobName)
        jobDesc = session['dwops'].cursor.fetchone()
        # if job is an load, delete files from the list and their rdys
        if jobDesc.JobIsFileExtract == 'N' and jobDesc.JobIsFileLoad == 'Y':
            filePrefix = jobDesc.JobFilePreFix[:jobDesc.JobFilePreFix.find('*')]
            aimenv = 'dev' if session['dwops'].env != 'prd' else session['dwops'].env
            inboundDirectory = Path('//amer/dfs/aim'+aimenv+'/iics/infa'+session['dwops'].env+'/file_transfer/aim/inbound')
            # delete files from inbound file list (since they eixst in archive already)
            with open(inboundDirectory/(filePrefix+'.lst'), 'r') as listFile:
                for line in listFile:
                    filePath = Path(line.strip('\n')) # throw away newlines
                    session['dwops'].log(text='Deleting file: '+str(filePath))
                    filePath.unlink()
        # if job is an extract, archive the file and the rdy
        elif jobDesc.JobIsFileExtract == 'Y' and jobDesc.JobIsFileLoad == 'N':
            filePrefix = jobDesc.JobFilePreFix[:jobDesc.JobFilePreFix.find('*')]
            aimenv = 'dev' if session['dwops'].env != 'prd' else session['dwops'].env
            outboundDirectory = Path('//amer/dfs/aim'+aimenv+'/iics/infa'+session['dwops'].env+'/file_transfer/aim/outbound')
            # generate list of files from prefix and archive and/or move
            fileList = session['fileops'].fileList(outboundDirectory, prefixes=[filePrefix])                
            for f in fileList:
                # if source and target specified, move file as instructed
                if jobDesc.JobTargetDirectorySufix != None:
                    session['fileops'].fileMove(f, Path(jobDesc.JobTargetDirectorySufix)/f.name, doArchive=True)
                # if source or target not specified, simply archive file
                else:
                    session['fileops'].fileArchive(f, archiveDirectory=outboundDirectory/'_archive', zip=True, delete=True)
        # perform DB audit
        auditStatus = etlAudit(session['dwops'], 'target', jobId, batchId)
        session['dwops'].log(text='Audits executed with overall status: '+auditStatus)
        session['dwops'].log(text='Updating status of job with ID '+str(jobId))
        params = (
            auditStatus,
            batchId, 
            jobId
        )
        session['dwops'].executeSqlFile('jobStatusUpd.sql', params=params, commit=True)
        # exit with flag code 16 if audit failed
        if auditStatus == 'F':
            session['dwops'].log(text='Sending failure notification email...')
            # send email
            session['dwops'].dwopsEmail(subject='Notification from AIM ETL Audit System',
                               body='ETL job '+jobName+': CRITICAL variance in SqlDw CDC Tables. Please review the attached log.',
                               recipients= ["AIMDataPlatformOps@kellyservices.com"])
            sys.exit(16)
    else:
        params = (
            'S',
            batchId, 
            jobId
        )
        session['dwops'].executeSqlFile('jobStatusUpd.sql', params=params, commit=True)

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['dwops'] = dwopsSession(Path(__file__).stem, taskName=sys.argv[1])
    sessionContainer['fileops'] = fileopsSession('', '', logFileName=sessionContainer['dwops'].logFileName)
    try:
        auditFlag = False if '-noaudit' in sys.argv[2:] else True
        etlJobEnd(sessionContainer, sys.argv[1], audit=auditFlag)
        sessionContainer['dwops'].logout()
        print('Script execution complete')
    except Exception as e:
        sessionContainer['dwops'].dwopsError(e)