####################################################################################################
# Name:                sharepointsession
# Python version:      Python 3.6.4
# Wiki path:           https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/33/sharepointsession
# Command line usage:  python start.py classtest-sharepointsession
# Purpose:             Class that contains methods for SharePoint API automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-11-13 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2022-09-28 J. Rominske (jesr114@kellyservices.com)       Switched to OAuth authentication
####################################################################################################

# library imports
import datetime
import json
import msal
from pathlib import Path
import requests
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to SharePoint Automation  
class sharepointSession(session):
    # specific initialization method
    def _setup(self):
        self.directory = self.repoDirectory/'mssharepoint'
        # load stored credentials and config from JSON files
        self.spCreds = json.load(open(self.secureDirectory/(self.env+'_sharepointcreds.json')))
        self.spConfig = json.load(open(self.configDirectory/(self.env+'_sharepointconfig.json')))
        # session variables for SharePoint API interface
        self.adAuthUrl = "https://login.microsoftonline.com/{}".format(self.spCreds['tenantId']) # login URL for the Azure API Service
        self.adLoginUrl = "https://login.microsoftonline.com/{}/oauth2/token".format(self.spCreds['tenantId']) # login URL for the Azure API Service
        self.serverUrl = self.spConfig['server'] # URL for our SharePoint server
        self.loginUrl = self.serverUrl+'/_forms/default.aspx?wa=wsignin1.0' # login URL for our SharePoint tenant
        self.certsDirectory = self.secureDirectory/'certs'
        self.hdrs = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/x-www-urlencoded;charset=UTF-8'
        }
        self.authHdrs = {
            'Accept': 'application/x-www-form-urlencoded',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        self.req = requests.Session()

    # login with AD Service Principal and 
    def login(self, principal=None):
        # set variables that depend on scriptConfig (must come after setup method)
        self.pathPrefix = self.spConfig['site'][self.scriptConfig['sharepointGroup']]
        self.siteUrl = self.serverUrl+self.pathPrefix
        # use or define principal selection dict
        self.log(text='Logging into '+self.serverUrl+'...')
        if principal is None:
            principal = {
                'type': 'ServicePrincipal',
                'label': 'ACE_SharePoint'
            }
        # load creds based on the principal selected
        creds = self.spCreds[principal['type']][principal['label']+'_'+self.env]
        # use MSAL to acquire token via certificate
        tokenResultJson = msal.ConfidentialClientApplication(
            client_id = creds['clientId'],
            authority = self.adAuthUrl,
            client_credential = {
                'thumbprint': creds['thumbprint'],
                'private_key': open(self.certsDirectory/creds['certFileName']).read(),
                'passphrase': creds['certPassword']
            },
        ).acquire_token_for_client(scopes=[self.serverUrl+'/.default'])
        # check for errors
        if 'access_token' not in tokenResultJson:
            # report error details if possible
            if 'error' in tokenResultJson:
                self.log(text='Login error "'+tokenResultJson['error']+'": '+tokenResultJson['error_description'])
            else:
                self.log(text='Login error! No JSON response captured.')
            return False
        # extract token
        else:
            self.hdrs['Authorization'] = "Bearer "+tokenResultJson['access_token']
            self.log(text='Login successful')
            return True        

    # method for sending emails specific to SharePoint
    def sharepointEmail(self, body, color, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_filetransfer.html') as template:
            self.email(
                body=template.read().format(body), # replace "{}" in template file with values
                color=color,
                recipients=recipients,
                attachment=attachment) # call basic email function

    # method to send error report email for SharePoint
    def sharepointError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.sharepointEmail(
                body='An error occurred with code: '+str(errorCode)+'<br>Please check the logs.',
                color='red')
        sys.exit(errorCode)
            
    # generic API Resource method (private)
    def _doAPI(self, reqType, uri, data=None, jsonData=None, headers=None):
        # deal with arguments
        url = self.siteUrl+'/_api/web/'+uri
        if not headers:
            headers = self.hdrs
        self.log(text='\tAccessing API resource at '+url)
        # switch method use based on request type
        if reqType == 'GET':
            response = self.req.get(url, headers=headers)
        elif reqType in ('POST', 'UPDATE'): # catch None object for both POST and UPDATE
            # refresh Request Digest for security reasons
            self.log(text='\tRefreshing Session Request Digest...')
            refreshJson = self.req.post(self.siteUrl+'/_api/contextinfo', data='', headers=self.hdrs).json()
            self.hdrs['X-RequestDigest'] = refreshJson['d']['GetContextWebInformation']['FormDigestValue']
            self.log(text='\tSession Request Digest refreshed.')
            # enforce not-None postObject
            if data is None and jsonData is None:
                raise ValueError('When using POST method, data or JSON must be included in request')
            # just do normal request call on POST
            if reqType == 'POST':
                response = self.req.post(url, headers=headers, json=jsonData, data=data)
            # extra logic for handling headers for UPDATE modes
            elif reqType == 'UPDATE':
                # copy normal header and add update mode flag
                updateHeaders = headers.copy()
                updateHeaders['X-HTTP-Method'] = 'PUT'
                # call API resource
                response = self.req.post(url, headers=updateHeaders, json=jsonData, data=data)
        elif reqType == 'DELETE':
            # copy normal header and add update mode flag
            deleteHeaders = headers.copy()
            deleteHeaders['X-HTTP-Method'] = 'DELETE'
            response = self.req.delete(url, headers=deleteHeaders)
        # attempt parsing and accessing "error" member of JSON response to check for error return
        try:
            self.log(text='SharePoint API at '+self.siteUrl+' returned an error: '+str(json.loads(response.content)['error']))
            raise ValueError('SharePoint returned an error! Erroring out script...')
        # if error relevant to JSON decoding and 'error' member access raised, check to see if the error is the one we raised artificially
        except (UnicodeError, ValueError, KeyError) as e:
            # if the error message checks out, pass to normal error handling
            if 'SharePoint' in str(sys.exc_info()[1]):
                raise e
            # if exception is not the one we raised, no JSON error returned, so proceed normally
            else:
                return response

    # simple wrapping methods
    # method to get the author of a file
    def fileAuthorGet(self, sitepath):
        return self._doAPI('GET', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/Author")
        # method to get the last editor of a file
    def fileModifiedByGet(self, sitepath):
        return self._doAPI('GET', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/ModifiedBy")
    # method to copy a file on the site to another directory
    def fileCopy(self, sitepath, copypath):
        return self._doAPI('POST', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/copyto(strnewurl='"+self.pathPrefix+copypath+"', boverwrite=true)", data='')
    # method to get a file given path
    def fileDetailsGet(self, sitepath):
        return self._doAPI('GET', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')")
    # method to get a file given path
    def fileGet(self, sitepath):
        return self._doAPI('GET', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/$value")
    # method to get all files in given folder
    def fileGetInFolder(self, sitepath):
        return self._doAPI('GET', "GetFolderByServerRelativeUrl('"+self.pathPrefix+sitepath+"')?$expand=Files")
    # method to get a file given path
    def fileDelete(self, sitepath):
        return self._doAPI('DELETE', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/$value")
    # method to move a file on the site to another directory
    def fileMove(self, sitepath, movepath):
        return self._doAPI('POST', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/moveto(newurl='"+self.pathPrefix+movepath+"', flags=1)", data='')
    # method to get a file given path
    def filePost(self, sitepath, fileData):
        folder = '/'.join(sitepath.split('/')[:-1])
        filename = sitepath.split('/')[-1]
        return self._doAPI('POST', "GetFolderByServerRelativeUrl('"+self.pathPrefix+folder+"')/Files/add(url='"+filename+"',overwrite=true)", data=fileData)
    # method to get a file given path
    def fileUpdate(self, sitepath, fileData):
        return self._doAPI('UPDATE', "GetFileByServerRelativeUrl('"+self.pathPrefix+sitepath+"')/$value", data=fileData)
    # method to create a folder
    def folderCreate(self, sitepath):
        parentFolder = '/'.join(sitepath.split('/')[:-1])
        newFolder = sitepath.split('/')[-1]
        return self._doAPI('POST', "GetFolderByServerRelativeUrl('"+self.pathPrefix+parentFolder+"')/Folders/add(url='"+newFolder+"')", data='')
    # method to delete a folder
    def folderDelete(self, sitepath):
        return self._doAPI('DELETE', "GetFolderByServerRelativeUrl('"+self.pathPrefix+sitepath+"')")

    # composite wrapping methods
    # method to return the email address of a file's author as a string
    def fileUploaderEmail(self, sitepath):
        return self.fileModifiedByGet(sitepath).json()['d']['Email']
    # method to download a file from the site to a given location
    def fileDownload(self, sitepath, filepath=None):
        if not filepath:
            (self.directory/'download').mkdir(parents=True, exist_ok=True)
            filepath = self.directory/'download'/sitepath.split('/')[-1]
        with open(filepath, 'wb') as spFile:
            response = self.fileGet(sitepath)
            # save content as file
            spFile.write(response.content)
            self.log(text='File saved to '+str(filepath))
        return filepath
    # method to upload a file from a given location to the site
    def fileUpload(self, sitepath, filepath=None):
        if not filepath:
            filepath = self.directory/'upload'/sitepath.split('/')[-1]
        with open(filepath, 'rb') as spFile:
            _ = self.filePost(sitepath, spFile.read())
            # TODO: Do stuff with the response, like notify the uploader or something
            self.log(text='File '+str(filepath)+' uploaded successfully.')
    # method to archive a file on SharePoint
    def sharepointArchive(self, path, archiveFolder=None):
        # generate archival datestamp
        datestamp = datetime.datetime.today().strftime('_%Y-%m-%d_%H-%M-%S')
        # generate list from path
        splitPath = path.split('/') # use string split for SharePoint URI
        # generate file and folder name for archived file on SharePoin
        splitFile = splitPath[-1].split('.') # split filename by extension radix
        splitFile[-2] += datestamp # append datestamp to file base name
        archiveFile = '.'.join(splitFile) # rejoin filename together for later use
        if archiveFolder is None:
            splitPath[-1] = '_archive' # change final element in path list to archive folder (adds it inside current folder)
            archiveFolder = '/'.join(splitPath) # join path list back together for later use
        # create SharePoint folder (will leave alone if it exists)
        self.log(text='Attempting to create SharePoint archive folder at '+archiveFolder+' (will leave intact if already exists)')
        self.folderCreate(archiveFolder)
        # archive current version of the file on SharePoint
        archivePath = archiveFolder+'/'+archiveFile
        self.log(text='Archiving SharePoint file '+path+' to '+archivePath)
        self.fileMove(path, archivePath)
        self.log(text='SharePoint file archive complete')

# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    try:
        S = sharepointSession('classtest-'+Path(__file__).stem, 'test') # remove ".py" from script name
        testPrincipal = {
            'type': 'ServicePrincipal',
            'label': 'ACE_SharePoint'
        }
        if not S.login(principal=testPrincipal):
            print('Login error - aborted')
            raise ValueError('Login error - aborted')
        else:
            S.log(text='Login test complete')
            print('Script execution complete')
    except Exception as e:
        S.sharepointError(e)