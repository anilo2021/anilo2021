####################################################################################################
# Name:                 intftpbatch.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/mssharepoint/intftpbatch.vsdx
# Command line usage:   python start.py intftpbatch
# Purpose:              Transfer files from SharePoint folder to Inbound folder as a batch
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-01-21 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
from pathlib import Path
import sys
# local module imports 
from mssharepoint.sharepointsession import sharepointSession

# function to transfer a folder to a given inbound folder and archive at both ends
def inboundFile(session, sitepath, serverpath): 
    # download file from SharePoint location to server location
    session.log(text='Downloading SharePoint file '+sitepath+' to server folder '+str(serverpath))
    session.fileDownload(sitepath, serverpath)
    # archive the file on SharePoint side
    session.sharepointArchive(sitepath)

# function to transfer and archive all files in a given folder
def inboundFolder(session, transfer):
    # get list of SharePoint files in folder (not directories)
    session.log(text='Acquiring list of files in SharePoint folder '+transfer['sharepoint'])
    siteFiles = session.fileGetInFolder(transfer['sharepoint']).json()
    siteFileList = []
    filesExist = False
    for siteFile in siteFiles['d']['Files']['results']:
        filesExist = True # set flag for future loop
        siteFileList.append('/'.join(siteFile['ServerRelativeUrl'].split('/')[3:]))
    # iterate through list of files and transfer/archive
    if filesExist: # only archive through list and send email if files exist
        fileOwners = []
        for file in siteFileList:
            session.log(text='\nArchiving SharePoint file '+file)
            # get file owner email for later
            session.log(text='Acquiring file creator email address')
            fileOwners.append(session.fileAuthorEmail(file))
            # transfer file from SharePoint to server
            serverFile = Path(transfer['destination'])/file.split('/')[-1]
            inboundFile(session, file, serverFile)
        # send notification email that the files have been moved
        emailRecipients = []
        # append file owner if applicable
        if transfer['emailFlag']:
            emailRecipients += fileOwners
        # append speicied email if applicable
        if transfer['emails']:
            emailRecipients += transfer['emails']
        # send email if there are people to send it to
        if len(emailRecipients) > 0:
            session.log(text='Sending notification email to '+', '.join(emailRecipients))
            fileListString = '\n - '.join([f.split('/')[-1] for f in siteFileList])
            session.sharepointEmail(body=transfer['description']+'\n - '+fileListString, color='green',
                                    recipients=emailRecipients)
            session.log(text='\nSharePoint folder '+transfer['sharepoint']+' archive complete')
    else:
        session.log(text='No files found in SharePoint folder')

# function to check all endpoints in the JSON file for files to transfer, archiving them as it goes
def intftpBatch(session):
    # load JSON file
    transferList = session.scriptConfig['transferBatch']
    # iterate through JSON with inboundFolder()
    for t in transferList:
        session.log(text='\nPerforming transfer '+t+'...\n')
        inboundFolder(session, transferList[t])
    # note end of run in log
    session.log(text='\nInbound folder transfer check completed')

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem, 'check', args=['intftp'])
    try:
        if not sessionContainer['mssharepoint'].login():
            print('Login error - aborted')
        else:
            intftpBatch(sessionContainer['mssharepoint'])
            print('Script execution complete')
    except Exception as e:
        sessionContainer['mssharepoint'].sharepointError(e)