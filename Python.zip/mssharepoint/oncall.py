####################################################################################################
# Name:                 oncall.py
# Python version:       Python 3.6.4
# Source file:          AIM/Infrastructure/Operations/AIM Infra_On Call Schedule.xlsx
# Command line usage:   python start.py oncall
# Purpose:              Sends notification emails to AIM Infrastructure, information on-call personnel 
#                       for upcoming weeks.
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-03-31 H. Maddipati (harm344@kellyservices.com)      Original Author
# 2021-08-04 H. Maddipati (harm344@kellyservices.com)      Resolved problems with openpyxl module
####################################################################################################

# library imports
import json
import io
import os
from pathlib import Path
import sys
import datetime
import pandas as pd
import numpy as np
# library import check
try:
    import openpyxl
    excelEngine = 'openpyxl'
except ModuleNotFoundError as e:
    excelEngine = 'xlrd'

# local module imports 
from mssharepoint.sharepointsession import sharepointSession


def oncall(session):
    # Get file location and file name from config
    fileName = session.scriptConfig['fileName']
    fileLoc = session.scriptConfig['SharePointPath'] + fileName
    with open(session.fileDownload(fileLoc),'rb') as excelFile:
        session.log(text="Reading File from {}".format(fileLoc))
        onCallPerson = []
        nextOnCallPerson = []  
        # Load excel data into dataFrame
        df = pd.read_excel(excelFile,"On-Call Cal",usecols="E,G",engine=excelEngine) # Dataframe with on-call schedule   # , encoding="utf8"
        df = df.iloc[3:] # remove irrelevant rows
        df = df.set_index(['Start of On-Call Year'])
        df.columns = ["Name"]
        personnelDf = pd.read_excel(excelFile,"Cover Sheet",usecols="I,J,K,L",engine=excelEngine) # Dataframe with personnel details
        personnelDf.columns = personnelDf.iloc[0]
        personnelDf = personnelDf.replace(np.nan,"None")
        # Dates calculation
        today = datetime.date.today()
        nextWeekStart = today + datetime.timedelta(days=-today.weekday(), weeks=1)
        nextWeekEnd = nextWeekStart +  datetime.timedelta(days=6)
        currentWeekEnd, currentWeekStart = nextWeekStart - datetime.timedelta(days=1) , nextWeekStart - datetime.timedelta(days=7)
        previousWeekStart = currentWeekStart - datetime.timedelta(days=7)
        # Fetching person on-call for current, next and previous week
        for index,row in df.iterrows():
            if index.date()==currentWeekStart:
                onCallPerson = personnelDf.loc[personnelDf['Team Member(s)'] ==row['Name']].values.tolist()[0]
            if index.date() == nextWeekStart:
                nextOnCallPerson = personnelDf.loc[personnelDf['Team Member(s)'] ==row['Name']].values.tolist()[0]
            if index.date() == previousWeekStart:
                previousOnCallPerson = row['Name']
        session.log(text="on-call: "+onCallPerson[0])    
        session.log(text="next on-call: "+ nextOnCallPerson[0])    
    # Email template
    with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_oncall.html') as template:
        dataInsert = {  "currentWeekStart":currentWeekStart.strftime("%d %B, %Y"), 
                        "currentWeekEnd": currentWeekEnd.strftime("%d %B, %Y"),
                        "onCallPersonName": onCallPerson[0],
                        "onCallPersonPhone":onCallPerson[1],
                        "onCallPersonRing":onCallPerson[2],
                        "nextWeekStart": nextWeekStart.strftime("%d %B, %Y"),
                        "nextWeekEnd":nextWeekEnd.strftime("%d %B, %Y"),
                        "nextOnCallPersonName":nextOnCallPerson[0],
                        "nextOnCallPersonPhone":nextOnCallPerson[1],
                        "nextOnCallPersonRing":nextOnCallPerson[2],
                        "previousOnCallPerson":previousOnCallPerson,
                        "guideLines":session.scriptConfig['guideLines'],
                        "calender":session.scriptConfig['calenderLink']
                    }
        recipients = session.scriptConfig['emailRecipients']['notification']['html'] + [onCallPerson[3],nextOnCallPerson[3]] # append AIM Infrastructure to recipients
        session.sharepointEmail(body=template.read().format(**dataInsert), color='green' , recipients=recipients) # sends email

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem,taskName='notification')
    try:
        if not (sessionContainer['mssharepoint'].login()):
            sessionContainer['mssharepoint'].log(text='Login error - aborted')
        else:
            sessionContainer['mssharepoint'].log(text='Login Complete')
            oncall(sessionContainer['mssharepoint'])
            sessionContainer['mssharepoint'].log(text='Script execution complete')
    except Exception as e:
        sessionContainer['mssharepoint'].sharepointError(e,email=sessionContainer['mssharepoint'].scriptConfig['errorNotification'])
