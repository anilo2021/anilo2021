# Variables:
# - <password>
# - - the password used to encrypt the original PFX via the PS script - will be used to decrypt so the PEM can be made, and will be used to encrypt the resulting PEM
# - - MUST be in CyberArk - if not already, place in CyberArk once complete - will need this for script credentials
# - - MUST NOT have special characters - this will cause Bash to not parse correctly, and the PFX cannot be decrypted
# - <keyFileStem>
# - - the name of the PFX file, minus the extension - use this to ensure the PFX and PEM have the same name (other than their extensions, of course)
#
# Usage:
# - copy command template from below
# - fill in variables with values as described above
# - execute from Bash/Git Bash in appropriate folder

winpty openssl pkcs12 -passin pass:<password> -in output/<keyFileStem>.pfx -nocerts -passout pass:<password> -out output/<keyFileStem>.pem