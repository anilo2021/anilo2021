####################################################################################################
# Name:                 intftpondemand.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/mssharepoint/intftpondemand.vsdx
# Command line usage:   python start.py intftpondemand <partialPath>
# Purpose:              Transfer file between AMER DFS and SharePoint on demand
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-01-21 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from fnmatch import filter as fnFilter
from pathlib import Path 
import sys
# local module imports
from fileops.fileopssession import fileopsSession
from mssharepoint.sharepointsession import sharepointSession

# function to transfer between SharePoint and a DFS location on demand using a patrial Aim_FTP path
def transferOnDemand(session, partialPath):
    partialPathList = partialPath.split('/') # creates a list out of the partial Sharepoint path
    # fail if filename has no suffix
    if len(partialPathList[-1].split('.')) is 1:
        raise ValueError('Filename "'+partialPathList[-1]+'" has no extension! Terminating script...')
    # fail if folder has underscore
    if partialPathList[-2].startswith('_'):
        raise ValueError('Folder name "'+partialPathList[-2]+'" contains an underscore! Terminating script...')

    # generate Sharepoint path from partial path
    aimEnv = 'prd' if session['mssharepoint'].env == 'prd' else 'dev'
    # generate server path from partialPathList
    partialServerPath = '/'.join([y for x in [partialPathList[:2], ['intftp'], partialPathList[2:-1]] for y in x]) # inserts intftp into the path by making a list of sublists and flattening it
    serverPath = Path('//amer/dfs')/('aim'+aimEnv)/'iics'/('infa'+session['mssharepoint'].env)/'file_transfer'/partialServerPath
    
    # if inbound, download from SharePoint
    if partialPathList[1] == 'inbound':
        # generate sharepoint folder path
        siteFolderPath = '/aim'+aimEnv+'/iics/infa'+session['mssharepoint'].env+'/'+'/'.join(partialPathList[:-1]) #exclude last element (file name)
        # use wildcard to find all files to upload if applicable
        if '*' in partialPathList[-1]:
            # get files in folder
            fileListRaw = session['mssharepoint'].fileGetInFolder(siteFolderPath).json()['d']['Files']['results']
            # filter file list by wildcard (last element of path list)
            fileList = [siteFolderPath+'/'+fName for fName in fnFilter([f['Name'] for f in fileListRaw], partialPathList[-1])]
        else:
            fileList = [siteFolderPath+'/'+partialPathList[-1]]
        # fail if no files found
        if len(fileList) == 0:
            raise ValueError('No files found on SharePoint in folder "'+siteFolderPath+'" that match wildcard format "'+partialPathList[-1]+'"! Terminating script...')
        # otherwise, iterate through all relevant files
        else:
            for f in fileList:
                serverFilePath = serverPath/f.split('/')[-1]
                # grab SharePoint file uploader (last modifier)
                fileUploader = session['mssharepoint'].fileUploaderEmail(f)
                # create server directory if it does not exist
                serverFilePath.parent.mkdir(parents=True, exist_ok=True) 
                # download file from SharePoint location to server location
                session['mssharepoint'].log(text='Downloading SharePoint file '+f+' to server folder '+str(serverFilePath.parent))
                session['mssharepoint'].fileDownload(f, serverFilePath)
                # archive the file on SharePoint side
                session['mssharepoint'].sharepointArchive(f)
                # send notification email to file uploader (last modifier)
                try:
                    session['mssharepoint'].sharepointEmail(
                        body='Moved inbound file '+serverFilePath.name+' from SharePoint to AMER DFS.', 
                        color='green',
                        recipients=[fileUploader])
                except Exception as e:
                    session['mssharepoint'].log('WARNING - email notification failed! See stack trace below:')
                    session['mssharepoint'].error(e, exit=False)
    # if outbound, upload to SharePoint
    elif partialPathList[1] == 'outbound':
        # use wildcard to find all files to upload if applicable
        if '*' in partialPathList[-1]:
            fileList = session['fileops'].fileList(serverPath, formats=[partialPathList[-1]])
        else:
            fileList = [serverPath/partialPathList[-1]]
        # iterate through all relevant files
        for f in fileList:
            # generate sharepoint path
            sitePath = '/aim'+aimEnv+'/iics/infa'+session['mssharepoint'].env+'/'+('/'.join(partialPathList[:-1]+[f.name]))
            # upload file from SharePoint location to server location
            session['mssharepoint'].log(text='Uploading file '+str(f)+' to SharePoint location '+sitePath)
            session['mssharepoint'].fileUpload(sitePath, f)
            # archive the file on filesystem side
            session['fileops'].fileArchive(f, delete=True)

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem, sys.argv[1].replace('/', '_').replace('*', ''), args=['intftp'])
    sessionContainer['fileops'] = fileopsSession('', '', logFileName=sessionContainer['mssharepoint'].logFileName)
    try:
        if not sessionContainer['mssharepoint'].login():
            print('Login error - aborted')
        else:
            transferOnDemand(sessionContainer, sys.argv[1])
            print('Script execution complete')
    except Exception as e:
        sessionContainer['mssharepoint'].sharepointError(e)