# exportpackage.py
# Original Author: Sanju Joseph (sanj827@kellyservices.com)
# Python version 3.6.4
# Command Line Usage: python exportproject.py DEV
# Function:
#   - Exports IICS Project from IICS
# Revision History:
#   - 1.0 - 2018/12/11 by Sanju Joseph - (sanj827@kellyservices.com)


import json
import threading
import time
import os
import sys
from pathlib import Path
import datetime
import tempfile
import zipfile
import shutil

# local module imports
from iics.iicssession import iicsSession

# create directory if directory doesn't exist and returns directory path
def checkAndCreateDirectory(iics, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                iics.log(text="created new directory name: " + eachDirectory)
            except OSError:
                iics.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath

# download IICS project based on given project id
def exportIICSProjectById(iics, projectId, tempPath, waiting_seconds, exportProjectRetry):
    # download IICS project zip file
    projectMetadataFileName = 'exportMetadata.v2.json'
    directoryList = []
    directoryList.append('IICS')
    directoryList.append(projectId)
    exportPackagePath = checkAndCreateDirectory(iics, tempPath, directoryList)
    exportPackageJob(iics, projectId, projectId, exportPackagePath, 'metadata', waiting_seconds, exportProjectRetry)
    projectName = projectId + '.zip'
    
    #extract 'exportMetadata.v2.json' file from zip and returns file path 
    zip = zipfile.ZipFile(os.path.join(exportPackagePath, projectName))
    zip.extract(projectMetadataFileName, exportPackagePath)
    return projectId, os.path.join(exportPackagePath, projectMetadataFileName)

# download IICS project and reads metadata file
def exportIICSProject(iics, filePath, tempPath, archiveDirectoryPath, fileName, waiting_seconds, exportProjectRetry):
    projectId = ''
    with open(filePath, "r") as fileObject:
        for eachLine in fileObject:
            if eachLine != None and eachLine.replace('\n','').strip() != '':
                projectId = eachLine.replace('\n','')
            else:
                continue
            break
    
    if projectId.strip() == '':
        iics.log(text='Error: IICS project id is empty, hence throwing exception')
        raise Exception('IICS project id is empty')

    now = datetime.datetime.today()
    fileTimestamp = now.strftime('%Y-%m-%d_%H-%M-%S')
    
    # moving '.project.txt' file to archive directory
    newDirInArchiveDirectory = []
    newDirInArchiveDirectory.append('_request_file') 
    archiveDirectoryPath = checkAndCreateDirectory(iics, archiveDirectoryPath, newDirInArchiveDirectory)
    
    newFileNamePath = os.path.join(archiveDirectoryPath, fileName.replace('.txt', '_' + fileTimestamp + '.txt'))
    os.rename(filePath, newFileNamePath)

    iics.log(text='main-> ' + 'Request file moved to _archive directory: ' + newFileNamePath)

    # download IICS project zip file
    projectMetadataFileName = 'exportMetadata.v2.json'
    directoryList = []
    directoryList.append('IICS')
    directoryList.append(projectId)
    exportPackagePath = checkAndCreateDirectory(iics, tempPath, directoryList)
    exportPackageJob(iics, projectId, projectId, exportPackagePath, 'metadata',  waiting_seconds, exportProjectRetry)
    projectName = projectId + '.zip'
    
    #extract 'exportMetadata.v2.json' file from zip and returns file path 
    zip = zipfile.ZipFile(os.path.join(exportPackagePath, projectName))
    zip.extract(projectMetadataFileName, exportPackagePath)
    return projectId, os.path.join(exportPackagePath, projectMetadataFileName)

def fail(session, requestFilePath, failDirectoryPath, requestFileName, failureMessage):
    timeStamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
    newFailedFileName = requestFileName.replace('.txt', '_' + timeStamp + '.txt')
    newLocation = os.path.join(failDirectoryPath, newFailedFileName)
    os.rename(requestFilePath, newLocation)
    session.log(text="requested file '" + requestFileName + "' content is not valid, hence moved to _fail directory path: " + newLocation)
    session.log(text=failureMessage)

    failureMessage = 'Invalid request file. ' + failureMessage

    with open (newLocation.replace('.txt', '_failed_details.txt'), 'w') as failedFileHandler:
        failedFileHandler.write(failureMessage)
        failedFileHandler.close()
    
    raise Exception(failureMessage)

# download IICS asset
def exportPackageJob(iics, assetId, assetName, exportPackagePath, exportName, waiting_seconds, exportProjectRetry):
    iics.log()
    jsonString = '{"objects":[{"id": "' + assetId + '"}]}'
    iics.log(text=exportName + '-> ' + 'Request: ' + jsonString)
    postObject = json.loads(jsonString)
    exportJobResponse = iics.exportJobStart(postObject)
    exportJobResponseJson = exportJobResponse.json()
    if exportJobResponse.status_code != 200:
            iics.log(text=exportName + '-> ' + 'Error: failed exportJob api for asset Name:' + assetName)
            iics.log(text=exportName + '-> ' + json.dumps(exportJobResponseJson))
    else:
        iics.log(text=exportName + '-> ' + 'Response: ' + json.dumps(exportJobResponseJson))
        retry = exportProjectRetry
        time.sleep(waiting_seconds)
        exportJobObjectId = exportJobResponseJson["id"]    
        while True:
            if retry > 0:
                retry = retry - 1
                iics.log(text=exportName + '-> ' + "checking asset objectid status:"+ exportJobObjectId)
                exportJobResponse = iics.exportJobStatusGet(exportJobObjectId)
                if exportJobResponse.status_code != 200:
                    iics.log(text=exportName + '-> ' + "Error: failed exportJobStatusGet api for asset objectid: " 
                                    + exportJobObjectId)
                    exportJobResponseJsonError = exportJobResponse.json()
                    iics.log(text=exportName + '-> ' + json.dumps(exportJobResponseJsonError))

                    if exportJobResponseJsonError['error']['code'] == 'AUTH_01':
                        iics.log(text=exportName + '-> ' + 'Authentication failure, hence trying to re-login to IICS')
                        iics.login()
                        continue
                    else:
                        break

                exportJobResponseJson = exportJobResponse.json()

                # if export job status is 'in progress' then retry again
                if exportJobResponseJson["status"]["state"] == "IN_PROGRESS":
                    iics.log(text=exportName + '-> ' + 'Job id: ' + exportJobObjectId +  
                        ' is in "IN_PRORESS" state, hence checking again after ' + 
                        str(waiting_seconds) + ' seconds')
                    time.sleep(waiting_seconds)
                
                # if export job status is 'successful' then download the asset zip file to network drive
                elif exportJobResponseJson["status"]["state"] == "SUCCESSFUL":
                    iics.log(text=exportName + '-> ' + 'Job id: ' + exportJobObjectId + ' is already in "SUCCESS" state, hence started downloading...')
                    exportPackageResponse = iics.exportPackageGet(exportJobObjectId)
                    
                    iics.log(text=exportName + '-> ' + 'downloading package: "' + assetName +'.zip"')
                    zipFilePath = os.path.join(exportPackagePath, assetName + '.zip')
                    with open(zipFilePath, 'wb') as zip:
                        zip.write(exportPackageResponse.content)

                    iics.log(text=exportName + '-> ' + "downloaded package: " + assetName + ".zip successfully")
                    
                    exportZipFile = zipfile.ZipFile(zipFilePath)
                    
                    with open(zipFilePath.replace('.zip', '.txt'), 'w') as filehandle:  
                        for eachFileName in exportZipFile.namelist():
                            filehandle.write('%s\n' % eachFileName)
                        filehandle.close()

                    iics.log(text="'" + assetName + ".txt' has been created successfully")
                    
                    break
                # if export job status is 'failed'
                else:
                    iics.log(text=exportName + '-> ' + exportJobResponseJson["id"] + 'status is in "FAILED" state')
                    iics.log(text=exportName + '-> ' + exportJobResponseJson)
                    break
            else:
                iics.log(text=exportName + '-> ' + 'Tried ' + str(exportProjectRetry) + ' times to export job id:' + exportJobObjectId + 
                                ', but still in IN_PROGRESS state')
                break

def exportIICSProjectToNetworkDrive(session, env, emailAddress, isPullRequestRequired, projectId):
    with open(os.path.join(session.rootDirectory, 'iics', 'exportpackage-config.json')) as configFile:
        config = json.load(configFile)

    directoryPath = config[env]['requestfilepath']
    exportPackagePath = config[env]['exportpackagepath']
    logPath = config[env]['logpath']
    archiveDirectoryPath = config[env]['archivepath']
    project_waiting_seconds = int(config['project']['waitseconds'])
    exportProjectRetry = int(config['project']['retrycount'])
    package_waiting_seconds = int(config['package']['waitseconds'])
    exportPackageRetry = int(config['package']['retrycount'])
    failDirectoryPath = config[env]['faildirectorypath']    
    exportProjectFileExtension = config['project']['fileextension']
    allowAssetTypes = config['project']['allowassettypes']
    fileNameStartsWith = config['project']['filenamestartswith']

    # fileList = []
    # for (_, _, filenames) in os.walk(directoryPath):
    #     fileList.extend(filenames)
    #     break

    # looping every '.project.txt' file inside '_request_file' folder
    # for fileName in fileList:
    I = iicsSession(baseName=session.scriptName, taskName=session.taskName)
    # filePath = os.path.join(directoryPath, fileName)

    # if (not str(fileName).startswith(config['project']['filenamestartswith'])) and str(fileName).endswith(exportProjectFileExtension):
    #     try:
    #         fail(I, filePath, failDirectoryPath, fileName, 'File name must starts with ' + config['project']['filenamestartswith'])
    #     except Exception as validationException:
    #         I.log(text=str(validationException))
    # elif not str(fileName).startswith(config['project']['filenamestartswith']):
    #     continue
    # elif not str(fileName).endswith(exportProjectFileExtension):
    #     continue        

    maxThreadRun = 50
    
    # I.log(taskName=os.path.splitext(fileName)[0], directory=logPath)
    # I.log(text='main-> ' + 'Request file name: ' + fileName)
    I.log(text='main-> ' + 'Request file directory path: ' + directoryPath)
    I.log(text='main-> ' + 'Export package directory path: ' + exportPackagePath)
    I.log(text='main-> ' + 'Archive directory path: ' + exportPackagePath)
    I.log(text='main-> ' + 'Temporary directory path: ' + tempfile.gettempdir())
    I.log(text='main-> ' + 'Fail directory path: ' + failDirectoryPath)
    I.log(text='')

    if not I.login():
        print('Login error - aborted')
    else:
        try:
            # if fileName.find(' ') != -1:
            #     fail(I, filePath, failDirectoryPath, fileName, 'File name must not have space character')
                
            I.log(text='main-> ' + 'Started processing request file...')
            
            # reading '.project.txt' file
            # projectId, projectMetadataFilePath = exportIICSProject(I, filePath, tempfile.gettempdir(), archiveDirectoryPath, fileName, project_waiting_seconds, exportProjectRetry)
            projectMetadataFilePath = exportIICSProjectById(I, projectId, tempfile.gettempdir(), project_waiting_seconds, exportProjectRetry)
            with open(projectMetadataFilePath, "r") as fileObject:
                projectObjects = json.load(fileObject)

            I.logout()

            for eachAsset in projectObjects['exportedObjects']:
                if eachAsset['objectGuid'].lower() == projectId.lower():
                    projectName = eachAsset['objectName']
                    break

            threads = []
            threadCount = 1
            objectCount = 0
            fileNameDirectory = fileNameStartsWith + projectName.lower()
            featureDirectoryPath = os.path.join(exportPackagePath, projectName, fileNameDirectory)
            for eachAsset in projectObjects['exportedObjects']:
                if allowAssetTypes.find(eachAsset['objectType'].lower()) == -1:
                    I.log(text="main-> Asset name '" + eachAsset['objectName'] + "' is not allowed to export due to it's asset type: " + eachAsset['objectType'])
                    continue

                if threadCount == 1:
                    I.login()

                directoryList = []
                assetPath = str(eachAsset['path']).lower()
                I.log(text="\n" + 'main-> ' + 'Processing asset name: ' + eachAsset['objectName'])
                I.log(text='main-> ' + 'Asset type: ' + eachAsset['objectType'] + ', Asset path: ' + eachAsset['path'])
                
                if assetPath.find('explore/') != -1 and eachAsset['path'].lower().find(projectName.lower() + '/') != -1:
                    objectCount +=1
                    directoryList.append(assetPath.replace('/explore/', '').split('/')[0])
                    directoryList.append(fileNameDirectory)
                    directoryList.append(directoryList[0])
                    directoryList.append(eachAsset['objectType'].lower())
                    
                    exportPackageDirectoryPath = checkAndCreateDirectory(I, exportPackagePath, directoryList)
                    
                    eachThread = threading.Thread(target=exportPackageJob, args=(I, eachAsset["objectGuid"], eachAsset['objectName'], 
                            exportPackageDirectoryPath, str(objectCount), package_waiting_seconds, exportPackageRetry))

                    eachThread.start()
                    threads.append(eachThread)

                    if threadCount >= maxThreadRun:
                        for eachThread in threads:
                            eachThread.join()

                        threads = []
                        threadCount = 1
                        I.logout()
                    else:
                        threadCount +=1

                else:
                    I.log(text='main-> ' + 'Asset has been ignored for processing due to the type of this asset or may not be belonging to IICS project name: "' + projectName + '"')

            if threadCount != 1:
                for eachThread in threads:
                    eachThread.join()
                I.logout()

            if featureDirectoryPath is not None:
                with open(os.path.join(featureDirectoryPath, 'requestfiledetails.txt'), 'w') as prhandle:
                    prhandle.write('EMAIL:' + emailAddress + '\n')
                    if isPullRequestRequired:
                        prhandle.write('PULLREQUEST:1')
                    else:
                        prhandle.write('PULLREQUEST:0')

                    prhandle.close()

            shutil.rmtree(path=os.path.join(projectMetadataFilePath), ignore_errors=True)
            I.log('main-> ' + 'Deleted files from system temp folder')
        except Exception as ex:
            I.log(text=str(ex))
            I.logout()
            I.error(ex)
                
# main thread
if __name__ == "__main__":
    print('Running...')
    env = sys.argv[0]
    emailAddress = sys.argv[1]
    isPullRequestRequired = sys.argv[2]
    iicsProjectId = sys.argv[3]
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(baseName=os.path.basename(__file__)[:-3], taskName=env)
    
    try:        
        exportIICSProjectToNetworkDrive(sessionContainer['iics'], env, emailAddress, isPullRequestRequired, iicsProjectId)

        print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e, email=False) # email is already handled by Azure DevOps pipeline