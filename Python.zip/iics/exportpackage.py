####################################################################################################
# Name:                 exportpackage.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/exportpackage.vsdx
# Command line usage:   python start.py exportpackage <DEV>
# Purpose:              Exports IICS assets from IICS DEV to DFS(network drive) path
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-12-11 Sanju Joseph (sanj827@kellyservices.com)      Original Author
# 2022-11-15 Hanuman Dasari (hand557@kellyservices.com)    Added process and processobject for AppIntegration
####################################################################################################

# library imports
import json
import threading
import time
import os
import sys
from pathlib import Path
import datetime
import zipfile
import re
import shutil
import subprocess
import tempfile

# local module imports
from iics.iicssession import iicsSession

# create directory if directory doesn't exist and returns directory path 
def checkAndCreateDirectory(iics, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                iics.log(text="created new directory name: " + eachDirectory)
            except OSError:
                iics.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath.lower()

def getFileAuthor(filePath, fileName, fileAuthorNameIndexPosition):
    authorName = ''
    response = subprocess.Popen(['dir', filePath, '/q'], stdout=subprocess.PIPE, shell=True)
    for line in str(response.communicate()[0]).split('\\r\\n'):
        if line.lower().find(fileName.lower()) != -1:
            authorName = line[fileAuthorNameIndexPosition:].split(' ')[0].replace('\\\\','\\')
            break

    return authorName

def createObjectInfoFile(devFilePath, exportFilePath, emailNotificationLabel, emailAddress, fileAuthorNameIndexPosition):
    fileName = os.path.basename(devFilePath)
    with open(exportFilePath.replace(os.path.splitext(exportFilePath)[1], '.txt'), 'w') as filehandle:  
        filehandle.write('Name: ' + fileName + '\n')
        filehandle.write('Author: ' + getFileAuthor(devFilePath, fileName, fileAuthorNameIndexPosition) + '\n')
        filehandle.write('Created on: ' + datetime.datetime.fromtimestamp(os.path.getctime(devFilePath)).isoformat() + '\n')
        filehandle.write('Last updated on: ' + datetime.datetime.fromtimestamp(os.path.getmtime(devFilePath)).isoformat() + '\n')
        filehandle.write(emailNotificationLabel + ': ' + emailAddress + '\n')
        filehandle.write('File size: ' + str(os.stat(devFilePath).st_size/1024.0) + ' KB')
        filehandle.close()

def createAssetInfoFile(iics, zipFilePath, assetId, assetType, assetName, emailNotificationLabel, emailAddress):
    exportZipFile = zipfile.ZipFile(zipFilePath)
                    
    assetDetails = getAssetDetails(iics, assetId, assetType, assetName)
    with open(zipFilePath.replace('.zip', '.txt'), 'w') as filehandle:  
        for eachDetail in assetDetails:
            filehandle.write(eachDetail + '\n')
        
        filehandle.write(emailNotificationLabel + ': ' + emailAddress + '\n')
        filehandle.write('Zip file contents:' + '\n')

        for eachFileName in exportZipFile.namelist():
            filehandle.write('\t%s\n' % eachFileName)
    
        filehandle.write('Zip file size: ' + str(os.stat(zipFilePath).st_size/1024.0) + ' KB')
        filehandle.close()
    
    iics.log(text="'" + assetName + ".txt' has been created successfully")

def getIICSAgentPath(config, projectName):
    return config['dev']['dsfserverpath']+'\\'+config['dev']['dfsinfadev']+'\\'+config['iicsagents'][projectName]
        
def getUserParameterFilePath(config, projectName, fileName):
    return getIICSAgentPath(config, projectName)+'\\'+config['dev']['userparameter']+'\\'+fileName

def getScriptsCustomFilePath(config, projectName, fileName):
    return getIICSAgentPath(config, projectName)+'\\'+config['iicsscriptscustom'][projectName]+'\\'+fileName

# getting IICS asset ids and copy external objects to network drive
def getAssetIdAndDownloadExternalObjects(iics, assetList, config, exportPackagePath, fileNameDirectory, emailAddress):
    inputArr = []
    featureDirectoryPath = None
    userParameterType = 'userparameter'
    scripts_customType = 'scripts_custom'
    emailNotificationLabel = config['package']['emailnotificationlabel']
    fileAuthorNameIndexPosition = config['package']['fileauthornameindexposition']

    for asset in assetList:
        objectType, objectPath = asset.split(',')
        if objectType is not None:
            objectType = objectType.lower()
            if config['package']['allowassettypetoexport'].find(objectType) != -1:
                inputArr.append(asset)
            elif objectType == userParameterType or objectType == scripts_customType:
                filePathArr = objectPath.lower().split('/')
                projectName = filePathArr[0]
                fileName = filePathArr[-1]
                featureDirectoryList = []
                featureDirectoryList.append(projectName)
                featureDirectoryList.append(fileNameDirectory)
                featureDirectoryPath = checkAndCreateDirectory(iics, exportPackagePath, featureDirectoryList)

                exportDirectoryList = []
                exportDirectoryList.append(projectName)
                exportDirectoryList.append(objectType.lower())
                exportPackageDirectoryPath = checkAndCreateDirectory(iics, featureDirectoryPath, exportDirectoryList)
                
                exportFilePath = os.path.join(exportPackageDirectoryPath, fileName)
                if objectType == userParameterType:
                    devFilePath = getUserParameterFilePath(config, projectName, fileName)
                elif objectType == scripts_customType:
                    devFilePath = getScriptsCustomFilePath(config, projectName, fileName)
                shutil.copyfile(devFilePath, exportFilePath)
                iics.log(text="File has been copied from '"+devFilePath+"' to dfs path")
                createObjectInfoFile(devFilePath, exportFilePath, emailNotificationLabel, emailAddress, fileAuthorNameIndexPosition)
        
    return inputArr, featureDirectoryPath

def extractAssetInfoFromZipFile(iics, asset_arr, package_path, folder_path, metadata_file_name, allowIICSAssetTypes):
    asset_list=[]
    zip = zipfile.ZipFile(package_path)
    iics.log(text='extracting '+ metadata_file_name + ' file from zip file')
    metadata_Json_object = {}
    for name in zip.namelist():
        if name == metadata_file_name:
            metadata_Json_object = json.loads(zip.read(name))
            zip.close()
            break
    
    iics.log(text='asset file has been downloaded to path '+str(zip.filename))
    for each_asset in metadata_Json_object['exportedObjects']:
        asset_folder_path = str(each_asset['path']).lower().replace('/explore/', '')
        if allowIICSAssetTypes.find(str(each_asset['objectType']).lower()) == -1:
            iics.log(text= "'"+str(each_asset['objectType'])+"' is not allowed to export")
        elif asset_folder_path.lower() == folder_path.lower():
            asset_path = asset_folder_path+'/'+str(each_asset['objectName'])
            asset_info = str(each_asset['objectType'])+','+asset_path
            iics.log(text=asset_info+' \n')
            is_asset_not_in_list = True
            for prev_asset in asset_arr:
                if prev_asset.lower().endswith(asset_path.lower()):
                    is_asset_not_in_list=False
                    iics.log(text="'"+asset_path + "' is already exists in requested asset list, hence ignoring it")
                    break

            if is_asset_not_in_list:
                asset_list.append(asset_info)
                iics.log(text= "'"+str(each_asset['objectName'])+"' has been added to request asset list")

        else:
            iics.log(text= "'"+str(each_asset['objectName'])+"' path is not matching with current folder, hence ignoring this asset")

    return asset_list

def getAssetsFromFolder(iics, inputArr, metadata_file_name, waiting_seconds, retry, emailNotificationLabel, emailAddress, allowIICSAssetTypes):
    assetArr=[]
    folderAssets=[]
    for everyAsset in inputArr:
            assetType = everyAsset.split(',')[0]
            if isAssetTypeFolder(assetType):
                folderAssets.append(everyAsset)
            else:
                assetArr.append(everyAsset.lower())

    if (len(folderAssets) != 0):
        newDirectoryList=[]
        newDirectoryList.append('iics')
        tempDirectoryPath = checkAndCreateDirectory(iics, tempfile.gettempdir(), newDirectoryList)
        lookup_response_json = callLookup(iics, emailAddress, folderAssets)
        # if lookup_response.status_code != 200:
        #     iics.log(text="failed lookup api call at getAssetsFromFolder() function. Response status code: " + str(lookup_response.status_code))

        # lookup_response_json = lookup_response.json()
        iics.log(text='lookup api called at getAssetsFromFolder() function and json response is: ' + json.dumps(lookup_response_json))
        
        for each_asset in lookup_response_json['objects']:
            assetType = each_asset['type']
            assetName = each_asset['path'].split('/')[-1]
            zip_file_path = exportPackageJob(iics, each_asset['id'], assetType, assetName, tempDirectoryPath, waiting_seconds, retry, emailNotificationLabel, emailAddress)
            folder_path = each_asset['path'].lower().replace('/explore/', '')
            folder_assets = extractAssetInfoFromZipFile(iics, assetArr, zip_file_path, folder_path, metadata_file_name, allowIICSAssetTypes)
            assetArr.extend(folder_assets)
            try:
                os.remove(zip_file_path)
                iics.log(text='temp file '+str(zip_file_path)+' has been removed')
            except Exception as file_delete_exception:
                iics.log(text='exception while deleting file: '+ zip_file_path+'. Exception details: '+str(file_delete_exception))

    return assetArr

def callLookup(iics, emailAddress, inputArr, isLookupById=False, returnResponseObj=False):
    if len(inputArr) != 0:
        max_lookup = 75
        lookup_count = 1
        total_count = 0
        assets=[]
        iics.log(text='total assests for lookup: ' + str(len(inputArr)))
        
        if len(inputArr) <= max_lookup:
            for everyAsset in inputArr:
                if isLookupById:
                    assets.append({"id" : everyAsset})
                else:
                    objectType, objectPath = everyAsset.split(',')
                    assets.append({"path" : objectPath.strip(), "type" : objectType.strip()})

            jsonString = json.dumps({"objects":assets})
            postObject = json.loads(jsonString)
            iics.log(text='lookup request: \n' + jsonString)

            lookup_response =  iics.lookup(postObject)
            lookup_response_json = lookup_response.json()
            lookup_response_json_text = json.dumps(lookup_response_json)
            if lookup_response.status_code != 200:
                iics.log(text='error occurred while calling look api. error details: ' + str(lookup_response_json_text))
                iics.log(text='trying to call lookup api once again')
                lookup_response =  iics.lookup(postObject)
                lookup_response_json = lookup_response.json()
                lookup_response_json_text = json.dumps(lookup_response_json)
                if lookup_response.status_code != 200:
                    iics.log(text='lookup api got failed once again. error details: ' + str(lookup_response_json_text))
                else:
                    iics.log(text='lookup response: '+ lookup_response_json_text)
            else:
                iics.log(text='lookup response: '+ lookup_response_json_text)

            if returnResponseObj:
                return lookup_response
            else:
                return lookup_response_json
        else:
            all_lookup_responses = []
            for everyAsset in inputArr:
                if isLookupById:
                    assets.append({"id" : everyAsset})
                else:
                    objectType, objectPath = everyAsset.split(',')
                    assets.append({"path" : objectPath.strip(), "type" : objectType.strip()})
                total_count = total_count + 1
                if lookup_count == max_lookup or total_count == len(inputArr):
                    jsonString = json.dumps({"objects":assets})
                    postObject = json.loads(jsonString)
                    iics.log(text='lookup request: \n' + jsonString)
                    lookup_response =  iics.lookup(postObject)
                    lookup_response_json = lookup_response.json()
                    lookup_response_json_text = json.dumps(lookup_response_json)
                    if lookup_response.status_code == 200:
                        iics.log(text='lookup response: '+ lookup_response_json_text)
                        all_lookup_responses.extend(lookup_response_json['objects'])
                    elif lookup_response_json_text.lower().find('"V3API_LookupError_011"') != -1 or lookup_response_json_text.lower().find('"CMN_001"') != -1:
                            iics.log(text='error occurred while calling look api. error details: ' + str(lookup_response_json_text))
                            iics.log(text='trying to call lookup api once again')
                            lookup_response =  iics.lookup(postObject)
                            lookup_response_json = lookup_response.json()
                            lookup_response_json_text = json.dumps(lookup_response_json)
                            if lookup_response.status_code == 200:
                                iics.log(text='lookup response: '+ lookup_response_json_text)
                                all_lookup_responses.extend(lookup_response_json['objects'])
                            else:
                                iics.log(text='lookup api got failed once again. error details: ' + str(lookup_response_json_text))
                                return lookup_response_json
                    else:
                        return lookup_response_json

                    assets = []
                    lookup_count = 0

                lookup_count = lookup_count + 1
            
            return json.loads(json.dumps({"objects":all_lookup_responses}))

def isAssetTypeFolder(assetType):
    return assetType.lower() == 'folder'

def extractAssetFromObject(iics, assetId):
    lookupResponse = callLookup(iics, '', [assetId], True, True)
    if lookupResponse.status_code == 200:
        lookupResponseJson = lookupResponse.json()
        if 'objects' in lookupResponseJson:
            lookupResponseJson = lookupResponseJson['objects'][0]
            lookupResponseJson['name'] = lookupResponseJson['path'].split('/')[-1]
    return lookupResponse.status_code, lookupResponseJson

def getStatusCodeAndResponseJson(responseObj):
    return responseObj.status_code==200, responseObj.json()

def getAssetResponse(iics, assetId, assetName, assetType):
    assetType = assetType.lower()

    if assetType == 'fwconfig':
        return getStatusCodeAndResponseJson(iics.fwConfigGet(assetName))
    elif assetType == 'bservice':
        return extractAssetFromObject(iics, assetId)
    elif assetType == 'dtemplate':
        return getStatusCodeAndResponseJson(iics.mappingGet(assetName))
    elif assetType == 'mtt':
        return getStatusCodeAndResponseJson(iics.mappingTaskGet(assetName))
    elif assetType == 'taskflow':
        return extractAssetFromObject(iics, assetId)
    elif assetType == 'mi_task':
        return getStatusCodeAndResponseJson(iics.massIngestDetailsGet(assetId))
    elif assetType == 'process':
        return extractAssetFromObject(iics, assetId)   
    elif assetType == 'process_object':
        return extractAssetFromObject(iics, assetId)
    else:
        iics.log(text="provided asset name: '" + assetName + "' is not supported due to it's asset type: " + assetType)
        return False, {}

def get_value_or_empty(dict_object, key, alt_key=''):
    value = ''
    if key in dict_object:
        value = str(dict_object[key])
    elif alt_key != '' and alt_key in dict_object:
        value = str(dict_object[alt_key])
    return value

def getAssetDetails(iics, assetId, assetType, assetName):
    assetDetails = []
    isSuccessful, assetResponseJson = getAssetResponse(iics, assetId, assetName, assetType)
    
    if isSuccessful:
        assetDetails.append('Name: ' + get_value_or_empty(assetResponseJson, 'name'))
        assetDetails.append('Description: ' + get_value_or_empty(assetResponseJson, 'description'))
        assetDetails.append('Created by: ' + get_value_or_empty(assetResponseJson, 'createdBy'))
        assetDetails.append('Created on: ' + get_value_or_empty(assetResponseJson, 'createTime', 'createdTime'))
        assetDetails.append('Last updated by: ' + get_value_or_empty(assetResponseJson, 'updatedBy'))
        assetDetails.append('Last updated on: ' + get_value_or_empty(assetResponseJson, 'updateTime', 'updatedTime'))
    else:
        iics.log(text="could not able to retrieving asset details for asset name: " + assetName)

    return assetDetails

# export IICS asset
def exportPackageJob(iics, assetId, assetType, assetName, exportPackagePath, waiting_seconds, retry, emailNotificationLabel, emailAddress):
    jsonString = '{"objects":[{"id": "' + assetId
    if isAssetTypeFolder(assetType):
        jsonString = jsonString + '", "includeDependencies" : true}]}'
    else:
        jsonString = jsonString + '", "includeDependencies" : false}]}'

    iics.log(text='\nRequest: ' + jsonString)
    postObject = json.loads(jsonString)
    exportJobResponse = iics.exportJobStart(postObject)
    exportJobResponseJson = exportJobResponse.json()
    if exportJobResponse.status_code != 200:
        iics.log(text="Error: failed exportJob api for asset Name:" + assetName)
        iics.log(text=json.dumps(exportJobResponseJson))
        failureMessage = 'An error occurred while exporting file name: ' + assetName + '. Please check the attached log file.'
        failToExportPackage(iics, emailAddress, failureMessage)
    else:
        iics.log('Response: ' + json.dumps(exportJobResponseJson))
        
        time.sleep(waiting_seconds)
        exportJobObjectId = exportJobResponseJson["id"]
        totalRetry = retry  
        while True:
            if retry > 0:
                retry = retry - 1
                iics.log(text="checking asset objectid status:"+ exportJobObjectId)
                exportJobResponse = iics.exportJobStatusGet(exportJobObjectId)
                if exportJobResponse.status_code != 200:
                    iics.log(text="Error: failed exportJobStatusGet api for asset objectid: " 
                                    + exportJobObjectId)
                    iics.log(text=json.dumps(exportJobResponse.json()))
                    failureMessage = 'An error occurred while exporting file name: ' + assetName + '. Please check the attached log file.'
                    failToExportPackage(iics, emailAddress, failureMessage)
                    break

                exportJobResponseJson = exportJobResponse.json()
                # if export job status is 'in progress' then retry again 
                if exportJobResponseJson["status"]["state"] == "IN_PROGRESS":
                    iics.log(text='Job id: ' + exportJobObjectId +  
                        ' is in "IN_PRORESS" state, hence checking again after ' + 
                        str(waiting_seconds) + ' seconds')
                    time.sleep(waiting_seconds)

                # if export job status is 'successful' then download the asset zip file to network drive
                elif exportJobResponseJson["status"]["state"] == "SUCCESSFUL":
                    iics.log(text='Job id: ' + exportJobObjectId + ' is already in "SUCCESS" state, hence started downloading...')
                    exportPackageResponse = iics.exportPackageGet(exportJobObjectId)
                    
                    if isAssetTypeFolder(assetType):
                        zipFileName = str(assetId)+'.zip'
                    else:
                        zipFileName = assetName+'.zip'
                    iics.log(text='downloading package: ' + zipFileName)

                    zipFilePath = os.path.join(exportPackagePath, zipFileName)
                    with open(zipFilePath, 'wb') as zip:
                        zip.write(exportPackageResponse.content)

                    iics.log(text="downloaded package: " + zipFileName + " successfully")
                    
                    if not isAssetTypeFolder(assetType):
                        createAssetInfoFile(iics, zipFilePath, assetId, assetType, assetName, emailNotificationLabel, emailAddress)

                    return zipFilePath
                # if export job status is 'failed'
                else:
                    iics.log(text=exportJobResponseJson["id"] + 'status is in "FAILED" state')
                    iics.log(text='failed response: ' + exportJobResponseJson)
                    failureMessage = 'IICS job failed while exporting file name: ' + assetName + '. Please checked the attached log file.'
                    failToExportPackage(iics, emailAddress, failureMessage)
                    break
            else:
                iics.log('Tried ' + str(totalRetry) + ' times to export file name :' + assetName + ', but still in IN_PROGRESS state')
                totalTimeConsumed = totalRetry * waiting_seconds
                failureMessage = 'Tried ' + str(totalRetry) + ' times and waited ' + str(totalTimeConsumed) + ' seconds to export this file name: ' + assetName + ' but still in "IN PROGRESS" state. Please check this asset on IICS DEV and try again'
                failToExportPackage(iics, emailAddress, failureMessage)
                break
            
# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def sendEmail(session, emailAddress, subject, body, isSuccess=False, attachment=None):
    recipients = []
    if emailAddress is not None and len(emailAddress.strip()) != 0:
        recipients.append(emailAddress)
        
    emailDefaultRecipients = session.scriptConfig['dev']['emaildefaultrecipients']
    sendEmailToRecipientsOnSuccess = session.scriptConfig['dev']['sendemailtorecipientsonsuccess']

    if (not isSuccess) or (isSuccess and sendEmailToRecipientsOnSuccess):
        for email in emailDefaultRecipients.split(','):
            recipients.append(email.strip())

    try:
        body = convert_plaintext_to_html(body)
        with open(session.configDirectory/'emailTemplates'/'emailbody_iicsexport.html') as template:
            emailbody = template.read().format(body)

        session.email(subject, emailbody, attachment=attachment, recipients=recipients)
    except Exception as emailException:
        session.log(text="error occurred while sending email. Error details: " + str(emailException))

# calls when runtime exception occur
def failToExportPackage(session, emailAddress, failureMessage):
    subject = 'IICS DEV Export | Error'
    sendEmail(session, emailAddress, subject, failureMessage, isSuccess=False, attachment=str(session.logFileName))
    raise Exception(failureMessage, 'exceptionhandled')

# calls when any validation fails
def fail(session, requestFilePath, failDirectoryPath, requestFileName, failureMessage, emailAddress=None):
    timeStamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
    session.log(text=failureMessage)

    failureMessage = 'Invalid request file: ' + requestFileName + ' \r\n ' + failureMessage + '.'
    
    emailSubject = 'IICS DEV Export | Error'

    sendEmail(session, emailAddress, emailSubject, failureMessage, isSuccess=False, attachment=requestFilePath)

    newFailedFileName = requestFileName.replace('.txt', '_' + timeStamp + '.txt')
    newLocation = os.path.join(failDirectoryPath, newFailedFileName)
    os.rename(requestFilePath, newLocation)
    session.log(text="requested file '" + requestFileName + "' content is not valid, hence moved to _failed directory path: " + newLocation)
    
    with open (newLocation.replace('.txt', '_failed_details.txt'), 'w') as failedFileHandler:
        failedFileHandler.write(failureMessage)
        failedFileHandler.close()

    raise Exception(failureMessage, 'exceptionhandled')

#validates pull request format
def checkPullRequestValidation(I, eachLine, pullRequestFormat, filePath, failDirectoryPath, fileName, emailAddress):
    prLineArray = eachLine.split('=')
    if len(eachLine.split('=')) == 2 and prLineArray[0].strip() == pullRequestFormat:
        if prLineArray[1].strip().lower() == 'yes':
            return True
        elif prLineArray[1].strip().lower() == 'no':
            return False
        else:
            failureMessage = pullRequestFormat + ' value must be either YES or NO'
            fail(I, filePath, failDirectoryPath, fileName, failureMessage, emailAddress)
    else:
        fail(I, filePath, failDirectoryPath, fileName, pullRequestFormat + ' value is missing', emailAddress)

# validates email address format
def checkEmailAddressValidation(I, eachLine, emailFormat, filePath, failDirectoryPath, fileName):
    prLineArray = eachLine.replace('\n', '').split('=')
    if len(prLineArray) == 2:
        email = prLineArray[1].strip()
        if prLineArray[0].strip() == emailFormat and len(email) != 0:
            if bool(re.search(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$", email)):
                if email.lower().find('@kellyservices') != -1:
                    return email
                else:
                    failureMessage = "Email validation failed due to an invalid email domain name '" + prLineArray[1] + "'. The email domain name must be '@kellyservices'."
                    fail(I, filePath, failDirectoryPath, fileName, failureMessage, None)
            else:
                failureMessage = "Email validation failed due to an invalid email address '" + prLineArray[1] + "'."
                fail(I, filePath, failDirectoryPath, fileName, failureMessage, None)
        else:
            fail(I, filePath, failDirectoryPath, fileName, emailFormat + ' value is missing', None)
    else:
        fail(I, filePath, failDirectoryPath, fileName, emailFormat + ' value is missing', None)

# validates multiple IICS project entries from request file
def checkMultipleProjectEntries(session, objectList, oType, oPath, content, lineNo, config):
    failureMessage = None
    userParameterType = 'userparameter'
    scripts_customType = 'scripts_custom'
    objectType = oType.strip().lower()
    objectPath = oPath.strip().lower()
    lineNo = str(lineNo)
    filePathArr = objectPath.split('/')

    if objectType.find('/') != -1:
        return 'Invalid object type at line number ' + lineNo
    
    if config['dev']['allowiicsprojects'].find(filePathArr[0]+'/') == -1:
        return "Request file contains an invalid IICS project name or currently project object is not allow to export '" + oPath + "' at line number " + lineNo

    if objectType == userParameterType:
        devFilePath = getUserParameterFilePath(config, filePathArr[0], filePathArr[-1])
        if config['dev']['userparameterfileextensions'].find(os.path.splitext(devFilePath)[1]) == -1:
            return "Request file contains an invalid '"+userParameterType+"' file type '" + oType + "' at line number " + lineNo
        elif not os.path.isfile(devFilePath):
            session.log(text="File path '"+devFilePath+"' doesn't exist for '" +userParameterType+"'")
            return "'"+userParameterType+"' file name '" + filePathArr[-1] + "' doesn't exist in IICS " + session.env.upper() + " secure agent at line number " + lineNo

    elif objectType == scripts_customType:
        devFilePath = getScriptsCustomFilePath(config, filePathArr[0], filePathArr[-1])
        if config['dev']['scriptscustomfileextensions'].find(os.path.splitext(devFilePath)[1]) == -1:
            return "Request file contains an invalid '"+scripts_customType+"' file type '" + oType + "' at line number " + lineNo
        elif not os.path.isfile(devFilePath):
            session.log(text="File path '"+devFilePath+"' doesn't exist for '" +scripts_customType+"'")
            return "'"+scripts_customType+"' file name '" + filePathArr[-1] + "' doesn't exist in IICS " + session.env.upper() + " secure agent at line number " + lineNo

    if objectList[0].lower().find(',' + filePathArr[0] + '/') == -1:
        return "Request file contains multiple IICS project entries '" + content + "' at line number " + lineNo
          
    return failureMessage

# validate request file name
def isValidFileName(name):
    return re.findall('[^A-Za-z0-9_-]', str(os.path.splitext(name)[0]))

# get dfs infa dev path
def getInfaDevPath(config):
    return config['dev']['dsfserverpath']+'\\'+config['dev']['dfsinfadev']

# moving .txt request file to archive directory
def archiveRequestFile(I, archiveDirectoryPath, requestFileDirectory, filePath, fileName):
    fileTimestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')

    newDirInArchiveDirectory = []
    newDirInArchiveDirectory.append(requestFileDirectory)
    getNewArchiveDirectoryPath = checkAndCreateDirectory(I, archiveDirectoryPath, newDirInArchiveDirectory)
    fileExt = str(os.path.splitext(filePath)[1])
    
    os.rename(filePath, os.path.join(getNewArchiveDirectoryPath, fileName.replace(fileExt, '_' + fileTimestamp + fileExt)))
    I.log(text='\nRequest file has been moved to _archive directory')

# reads request file and export IICS assets to dfs path
def exportIICSPackageToNetworkDrive(I):
    env = I.env
    
    infaDevPath = getInfaDevPath(I.scriptConfig)
    exportPackagePath = infaDevPath+'\\'+I.scriptConfig[env]['exportpackagepath']
    directoryPath = exportPackagePath+'\\'+I.scriptConfig[env]['requestfilepath']
    logPath = exportPackagePath+'\\'+I.scriptConfig[env]['logpath']
    archiveDirectoryPath = exportPackagePath+'\\'+I.scriptConfig[env]['archivepath']
    failDirectoryPath = directoryPath+'\\'+I.scriptConfig[env]['faildirectorypath']
    
    package_waiting_seconds = int(I.scriptConfig['package']['waitseconds'])
    exportPackageRetry = int(I.scriptConfig['package']['retrycount'])
    exportPackageFileExtension = I.scriptConfig['package']['fileextension']
    allowIICSAssetTypes = I.scriptConfig['package']['allowassettypetoexport']
    allowAssetAndExternalObjectTypes = allowIICSAssetTypes + ',' + I.scriptConfig['package']['allowexternalobjecttype']
    fileNameMaxChars = int(I.scriptConfig['package']['filenamemaxchars'])
    fileNameStartsWith = I.scriptConfig['package']['filenamestartswith']
    configAssetTypeTranslates = I.scriptConfig['assettypetranslates']
    pullRequestEnabled = I.scriptConfig['package']['pullrequestenabled']
    pullRequestFormat = I.scriptConfig[env]['pullrequestformat']
    emailNotificationEnabled = I.scriptConfig['package']['emailnotificationenabled']
    emailAddressFormat = I.scriptConfig[env]['emailaddressformat']
    emailNotificationLabel = I.scriptConfig['package']['emailnotificationlabel']
    requestFileDirectory = '_request_file'
    metadataFileName = I.scriptConfig['package']['metadatafilename']

    fileList = []
    for (_, _, filenames) in os.walk(directoryPath):
        fileList.extend(filenames)
        break

    # looping every '.txt' file inside '_request_file' folder
    for fileName in fileList:
        isPullRequestRequired = pullRequestEnabled and False
        emailAddress = ''

        filePath = os.path.join(directoryPath, fileName)
        featureDirectoryPath = ''
        fileNameDirectory = fileName.replace(exportPackageFileExtension, '').lower()
        
        fileNameDirectory = fileNameStartsWith + fileNameDirectory

        I.log(taskName=fileNameStartsWith + os.path.splitext(fileName)[0], directory=os.path.join(logPath, requestFileDirectory))
        
        try:
            if str(fileName).endswith(exportPackageFileExtension):
                assetList = []
                isFirstLine = True
                isSecondLine = True
                isInvalidRequestFileContent = False
                
                I.log(text='Started processing request file...')

                # reading '.txt' file
                inputLines = []
                
                with open(filePath, "r") as fileObject:
                    inputLines.extend(fileObject.readlines())
                    fileObject.close()

                # archive requested file
                archiveRequestFile(I, archiveDirectoryPath, requestFileDirectory, filePath, fileName)

                lineNo = 0
                for eachLine in inputLines:
                    lineNo = lineNo + 1
                    if emailNotificationEnabled and isFirstLine:
                        emailAddress = checkEmailAddressValidation(I, eachLine, emailAddressFormat, filePath, failDirectoryPath, fileName)
                        isFirstLine = False
                        
                        failureMessages = []
                        if len(fileNameDirectory) > fileNameMaxChars:
                            failureMessages.append('Request file name must not be more than ' + str(fileNameMaxChars) + ' characters length')

                        if isValidFileName(fileName):
                            failureMessages.append('Request file name must not have any special characters other than underscore (_) and hyphen (-)')
                    
                        if len(failureMessages) != 0:
                            failureMessageStr = ' \r\n '+' \r\n '.join(failureMessages)
                            fail(I, filePath, failDirectoryPath, fileName, failureMessageStr, emailAddress)
                        
                        continue

                    if pullRequestEnabled and isSecondLine:
                        isPullRequestRequired = checkPullRequestValidation(I, eachLine, pullRequestFormat, filePath, failDirectoryPath, fileName, emailAddress)
                        isSecondLine = False
                        continue
                    
                    if eachLine != None:
                        if eachLine.replace('\n','').strip() == '':
                            continue
                        
                        eachLine = eachLine.strip().replace('\\','/')
                        if eachLine.endswith('/'):
                            eachLine = eachLine[:-1]

                        eachLineArray = eachLine.split(',')
                        if len(eachLineArray) == 2:
                            eachLine = eachLine.replace('\n', '')
                            
                            if I.scriptConfig['transalestoassettypes'].get(eachLineArray[0].strip().lower()):
                                eachLineArray[0] = I.scriptConfig['transalestoassettypes'][eachLineArray[0].strip().lower()]
                            
                            if eachLineArray[0].strip() != '':
                                if allowAssetAndExternalObjectTypes.find(eachLineArray[0].strip().lower()) != -1:
                                    if eachLineArray[1].strip() != '':
                                        assetList.append(eachLineArray[0].strip() +','+eachLineArray[1].strip())
                                    else:
                                        fail(I, filePath, failDirectoryPath, fileName, "Asset path is empty at line number " + str(lineNo), emailAddress)
                                else:
                                    fail(I, filePath, failDirectoryPath, fileName, "'" + eachLineArray[0] + "' asset type is incorrect or may not be allowed to export at line number " + str(lineNo), emailAddress)
                            else:
                                fail(I, filePath, failDirectoryPath, fileName, "Asset type is empty at line number " + str(lineNo), emailAddress)

                            failureMessage = checkMultipleProjectEntries(I, assetList, eachLineArray[0], eachLineArray[1], eachLine, lineNo, I.scriptConfig)
                            if failureMessage is not None:
                                fail(I, filePath, failDirectoryPath, fileName, failureMessage, emailAddress)
                        else:
                            isInvalidRequestFileContent = True
                            fail(I, filePath, failDirectoryPath, fileName, "Request file contains an invalid entry '" + eachLine + "' at line number " + str(lineNo), emailAddress)
                            break
                    else:
                        isInvalidRequestFileContent = True
                        fail(I, filePath, failDirectoryPath, fileName, "Request file contains an empty line at line number " + str(lineNo))
                        break

                # if file content is not valid
                if isInvalidRequestFileContent:
                    I.log(text="Error: invalid request file content, hence ignoring request file name: " + fileName)
                # if file content is empty
                elif len(assetList) == 0:
                    failureMessage = 'There is no asset information available'
                    I.log(text=failureMessage + ': ' +  fileName)
                    fail(I, filePath, failDirectoryPath, fileName, failureMessage, emailAddress)
                else:
                    # getting IICS asset id and copy external objects to network drive   
                    getlookupRequestArr, featureDirectoryPath = getAssetIdAndDownloadExternalObjects(I, assetList, I.scriptConfig, exportPackagePath, fileNameDirectory, emailAddress)
                    
                    if not I.login():
                        emailSubject = 'IICS DEV Export | Error'
                        failureMessage = "Could not able to login to IICS DEV."
                        sendEmail(I, emailAddress, emailSubject, failureMessage)
                        raise Exception(failureMessage, 'exceptionhandled')

                    getlookupRequestArr = getAssetsFromFolder(I, getlookupRequestArr, metadataFileName, package_waiting_seconds, exportPackageRetry, emailNotificationLabel, emailAddress, allowIICSAssetTypes)

                    if len(getlookupRequestArr) != 0:
                        lookupResponseJson = callLookup(I, emailAddress, getlookupRequestArr)
                        
                        I.log(text='lookup json: ' + json.dumps(lookupResponseJson))
                        
                        assetNotFound = False
                        for eachAssetPath in getlookupRequestArr:
                            eachAssetPathArray = eachAssetPath.split(',')
                            for eachAsset in lookupResponseJson["objects"]:
                                if eachAssetPathArray[1].lower().find(str(eachAsset["path"].lower())) == -1:
                                    assetNotFound = True
                                else:
                                    assetNotFound = False
                                    break

                            if assetNotFound:
                                failureMessage = 'Asset path is not available on IICS DEV. \r\n Asset Path: ' + eachAssetPathArray[1] + ' \r\n Asset Type: ' + eachAssetPathArray[0]
                                fail(I, filePath, failDirectoryPath, fileName, failureMessage, emailAddress)

                        for eachAsset in lookupResponseJson["objects"]:
                            assetId = eachAsset["id"]
                            assetType = eachAsset["type"]
                            pathArray = eachAsset["path"].split('/')
                            assetName = pathArray[-1]
                            projectName = pathArray[0].lower()
                            featureDirectoryPath = os.path.join(exportPackagePath, projectName, fileNameDirectory)
                            newDirectoryList = []

                            if isAssetTypeFolder(assetType):
                                newDirectoryList.append('iics')
                                exportPackageDirectoryPath = checkAndCreateDirectory(I, tempfile.gettempdir(), newDirectoryList)
                            else:
                                newDirectoryList.append(projectName)
                                newDirectoryList.append(fileNameDirectory)
                                newDirectoryList.append(projectName)
                                newDirectoryList.append(configAssetTypeTranslates[assetType.lower()])   
                                exportPackageDirectoryPath = checkAndCreateDirectory(I, exportPackagePath, newDirectoryList)
                            
                            exportPackageJob(I, assetId, assetType, assetName, exportPackageDirectoryPath, package_waiting_seconds, exportPackageRetry, emailNotificationLabel, emailAddress)
                             
                        I.logout()
            else:
                I.log(text="Invalid file extension. The request file must have '.txt' file extension.")
            
        except Exception as ex:
            argument = None
            I.log(text='exception message: ' + str(ex))
            
            try:
                I.logout()
            except Exception as _:
                I.log(text='Tried to logout from IICS DEV')

            if len(ex.args) == 2:
                exceptionMessage, argument = ex.args
                
            if argument is None or argument != 'exceptionhandled':
                subject = 'IICS DEV Export | Error'
                body = 'An error occurred. Please check the attached log file.'
                sendEmail(I, emailAddress, subject, body, isSuccess=False, attachment=str(I.logFileName))

            continue

        with open(os.path.join(featureDirectoryPath, 'requestfiledetails.txt'), 'w') as prhandle:
            prhandle.write('EMAIL:' + emailAddress + '\n')
            if pullRequestEnabled and isPullRequestRequired:
                prhandle.write('PULLREQUEST:1')
            else:
                prhandle.write('PULLREQUEST:0')

            prhandle.close()

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(baseName=os.path.basename(__file__)[:-3], taskName='')
    extraLogFilePath = str(sessionContainer['iics'].logFileName)
    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as fileRemoveException:
        print("couldn't able to delete extra log file: "+extraLogFilePath)

    try:
        exportIICSPackageToNetworkDrive(sessionContainer['iics'])

        print('Script execution complete')
    except Exception as e:
        if os.path.exists(str(sessionContainer['iics'].logFileName)):
            sessionContainer['iics'].error(e)
        else:
            print('Exception occurred: '+str(e))