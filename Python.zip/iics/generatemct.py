####################################################################################################
# Name:                 generatemct.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/generatemct.vsdx
# Command line usage:   python start.py generatemct <csvFile> <jsonFile> <taskPrefix> <taskDesc>
# Purpose:              Generates IICS mapping tasks based on definition and example
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# local module imports
import csv
import json
import os
import sys
# library imports
from iics.iicssession import iicsSession

# generates MCTs based on parameters provided by the user given a CSV and JSON template
def generateMct(session, csvFile, jsonFile, taskPrefix='tsk_', taskDesc='Python-generated MCT'):
    session.log(text='Generating mapping configuration tasks')
    
    # load CSV file from taskDefinitions (mandate .csv extension)
    if csvFile.split('.')[-1] != 'csv':
            csvFile = csvFile.split('.')[0] + '.csv'
    csvData = csv.reader(open(session.directory/'taskDefinitions'/csvFile))
    session.log(text='Loaded CSV file at '+csvFile)
    # load JSON file from taskTemplates (mandate .json extension)
    if jsonFile.split('.')[-1] != 'json':
            jsonFile = jsonFile.split('.')[0] + '.json'
    taskData = json.load(open(session.directory/'taskTemplates'/jsonFile))
    session.log(text='Loaded JSON file at '+jsonFile)
    
    # populate and post mttask object
    header = next(csvData)
    for row in csvData:
        session.log(text='\nRow '+row[0]+' of CSV file '+csvFile)
        # catch for GenerateIndicator column
        if row[1] == 'N':
            session.log(text=' - Skipping row')
            continue
        # set param flag for manually specified param files if applicable
        paramSpecified = False
        # iterate through columns to match params with object members
        for i in range(len(header)):
            # if param name refers to a table
            if any(x in header[i] for x in ['Tbl', 'tbl', 'table', 'Table']): # NOTE: should be in param name
                # if param is targetUpdateColumns of a table
                if 'targetUpdateColumns' in header[i]: # NOTE: should be param name suffix
                    for p in taskData['parameters']:
                        # if parameter name matches prefix, fill in targrtUpdateColumns
                        if p['name'] == '$'+header[i].split('_')[0]+'$':
                            p['targetUpdateColumns'] = row[i].split(';')
                            row[i] = None
                            break
                # if param is the table itself
                else:
                    # check in standard parameters
                    for p in taskData['parameters']:
                        # if parameter name matches, fill in according to parameter type
                        if p['name'] == '$'+header[i]+'$':
                            if p['type'] == 'EXTENDED_SOURCE':
                                p['extendedObject']['object']['name'] = row[i]
                                p['extendedObject']['object']['label'] = row[i]
                                row[i] = None
                            elif p['type'] == 'SOURCE':
                                p['sourceObject'] = row[i]
                                p['sourceObjectLabel'] = row[i]
                                row[i] = None
                            elif p['type'] == 'TARGET':
                                p['targetObject'] = row[i]
                                p['targetObjectLabel'] = row[i]
                                row[i] = None
                            else:
                                p['text'] = row[i]
                                row[i] = None
                            break
                    # check in IO parameters
                    for io in taskData['inOutParameters']:
                        if io['name'] == header[i]:
                            io['currentValue'] = row[i]
                            io['initialValue'] = row[i]
                            row[i] = None
                            break
            # if param is a connection
            elif any(x in header[i] for x in ['connection', 'Connection']): # NOTE: should be in param name
                for p in taskData['parameters']:
                    # if logcnx member of uiProperties exists
                    if 'logcnx' in p['uiProperties']:
                        # if parameter name matches, fill in by parameter type
                        if p['uiProperties']['logcnx'] in header[i]:
                            # get connection by name to get ID
                            connData = session.connectionGet('name/'+row[i]).json()
                            if p['type'] in ['EXTENDED_SOURCE', 'SOURCE']:
                                p['sourceConnectionId'] = connData['id']
                                row[i] = None
                            elif p['type'] == 'TARGET':
                                p['targetConnectionId'] = connData['id']
                                row[i] = None
                            break
            # if param is a parameter file
            elif header[i] == 'parameterFileName':
                # if column exists and is not blank, set param file name based on CSV
                if row[i] != '':
                    taskData['parameterFileName'] = row[i]
                # if column exists and is blank, delete parameterFileName from object if it exists
                elif 'parameterFileName' in taskData: 
                    del taskData['parameterFileName']
                # set flag to disable default behavior
                paramSpecified = True
                row[i] = None
            # TODO: Work out how to store/reference session properties (if workable)
            #elif header[i] == 'sessionProperties':
                #taskData['sessionProperties'] = row[i]
            # if param is a string (covers all other observed cases)
            else:
                # check for standard parameters
                for p in taskData['parameters']:
                    # if parameter name matches, fill in text member (default)
                    if p['name'] == '$'+header[i]+'$':
                        p['text'] = row[i]
                        row[i] = None
                        break
                # check for IO parameters
                for io in taskData['inOutParameters']:
                    # if parameter name matches, fill in text member (default)
                    if io['name'] == header[i]:
                        io['currentValue'] = row[i]
                        io['initialValue'] = row[i]
                        row[i] = None
                        break
        # catch CSV-Template matching failure
        if any(row[2:]): # exclude Seq column
            session.log(text='Complete task definition failed on row '+row[0]+': '+str(row[1:]))
            continue
        
        # find target tables for description
        for p in taskData['parameters']:
            if p['type'] == 'TARGET':
                targetTable = p['targetObject']
                break
        # populate task name, description, python commands, and param file if applicable
        taskName = taskPrefix + targetTable # this is convention
        taskData['name'] = taskName
        taskData['description'] = taskDesc
        if 'preProcessingCmd' in taskData:
            taskData['preProcessingCmd'] = ' '.join(taskData['preProcessingCmd'].split(' ')[:-1])+' '+taskName
        if 'postProcessingCmd' in taskData:
            taskData['postProcessingCmd'] = ' '.join(taskData['postProcessingCmd'].split(' ')[:-1])+' '+taskName
        if not paramSpecified:
            taskData['parameterFileName'] = taskName+'.param'
        
        # if there exists a mapping task with that name for informatica to return, post in update mode        
        #taskCheck = session.taskGet('name/'+taskName).json()
        #if taskCheck['@type'] == 'mtTask':
            #session.log(text=taskName+' already exists - updating')
            #session.createJsonFile('taskTemplates/derp.json', taskData) # DEBUG STATEMENT
            #r = session.taskUpdate(taskCheck['id'], taskData)
        #else:
            #session.createJsonFile('taskTemplates/derp.json', taskData) # DEBUG STATEMENT
        r = session.taskCreate(taskData)
        # check response status code
        if r.status_code == 200:
            session.log(text=taskName+'\t: SUCCESS')
        else:
            session.log(text=taskName+'\t: FAILURE')
            session.log(text=r.text)
        #input() # DEBUG STATEMENT

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(os.path.basename(__file__)[:-3], taskName=sys.argv[1]+'_'+sys.argv[2]) # remove ".py" from script name
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            # handle command line args
            if len(sys.argv) >= 5:
                generateMct(sessionContainer['iics'], sys.argv[1], sys.argv[2], taskPrefix=sys.argv[3], taskDesc=sys.argv[4])
            elif len(sys.argv) == 4:
                generateMct(sessionContainer['iics'], sys.argv[1], sys.argv[2], taskPrefix=sys.argv[3])
            else:
                generateMct(sessionContainer['iics'], sys.argv[1], sys.argv[2])
            sessionContainer['iics'].logout()
            print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e)