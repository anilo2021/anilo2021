####################################################################################################
# Name:                 projectbackup.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/projectbackup.vsdx
# Command line usage:   python start.py projectbackup
# Purpose:              Exports daily IICS Projects from IICS DEV, SQA & PRD
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-05-02 Sanju Joseph (sanj827@kellyservices.com)      Original Author
# 2019-12-23 Sanju Joseph (sanj827@kellyservices.com)      throws exception instead of just log error message
####################################################################################################

# library imports
import json
import threading
import time
import os
import sys
from pathlib import Path
import datetime
import tempfile
import zipfile

# local module imports
from iics.iicssession import iicsSession

# create directory if directory doesn't exist and returns directory path
def checkAndCreateDirectory(iics, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                iics.log(text="created new directory name: " + eachDirectory)
            except OSError:
                iics.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath

# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def sendEmail(session, emailAddress, subject, body, attachment=None):
    try:
        body = convert_plaintext_to_html(body)
        with open(session.configDirectory/'emailTemplates'/'emailbody_iicsexport.html') as template:
            emailbody = template.read().format(body)
        
        session.email(subject, emailbody, attachment=attachment, recipients=emailAddress)
    except Exception as emailException:
        session.log(text="error occurred while sending email. Error details: " + str(emailException))

def failToBackupProject(session, emailAddress, failureMessage):
    subject = 'IICS ' + str(session.env).upper() + ' Backup | Error'
    sendEmail(session, emailAddress, subject, failureMessage, attachment=str(session.logFileName))
    raise Exception(failureMessage, 'exceptionhandled')

# download IICS asset
def exportPackageJob(iics, assetId, assetName, exportPackagePath, exportName, waiting_seconds, exportProjectRetry):
    jsonString = '{"objects":[{"id": "' + assetId + '", "includeDependencies" : true}]}'
    iics.log(text=exportName + '-> ' + 'Request: ' + jsonString)
    postObject = json.loads(jsonString)
    exportJobResponse = iics.exportJobStart(postObject)
    exportJobResponseJson = exportJobResponse.json()
    if exportJobResponse.status_code != 200:
            iics.log(text=exportName + '-> ' + 'Error: Project export got failed. Status code: ' + str(exportJobResponse.status_code))
            iics.log(text=exportName + '-> Error response: ' + json.dumps(exportJobResponseJson))
            raise Exception(json.dumps(exportJobResponseJson))
    else:
        iics.log(text=exportName + '-> ' + 'Success Response: ' + json.dumps(exportJobResponseJson))
        retry = exportProjectRetry
        time.sleep(waiting_seconds)
        exportJobObjectId = exportJobResponseJson["id"]

        while True:
            if retry > 0:
                retry = retry - 1
                iics.log(text=exportName + '-> ' + "checking asset objectid status:"+ exportJobObjectId)
                exportJobResponse = iics.exportJobStatusGet(exportJobObjectId)
                if exportJobResponse.status_code != 200:
                    iics.log(text=exportName + '-> ' + "Error: failed exportJobStatusGet api for asset objectid: " 
                                    + exportJobObjectId)
                    exportJobResponseJsonError = exportJobResponse.json()
                    iics.log(text=exportName + '-> ' + json.dumps(exportJobResponseJsonError))

                    if exportJobResponseJsonError['error']['code'] == 'AUTH_01':
                        iics.log(text=exportName + '-> ' + 'Authentication failure, hence trying to re-login to IICS')
                        iics.login()
                        continue
                    else:
                        raise Exception(json.dumps(exportJobResponseJsonError))

                exportJobResponseJson = exportJobResponse.json()

                # if export job status is 'in progress' then retry again
                if exportJobResponseJson["status"]["state"] == "IN_PROGRESS":
                    iics.log(text=exportName + '-> ' + 'Job id: ' + exportJobObjectId +  
                        ' is in "IN_PRORESS" state, hence checking again after ' + 
                        str(waiting_seconds) + ' seconds')
                    time.sleep(waiting_seconds)
                
                # if export job status is 'successful' then download the asset zip file to network drive
                elif exportJobResponseJson["status"]["state"] == "SUCCESSFUL":
                    iics.log(text=exportName + '-> ' + 'Job id: ' + exportJobObjectId + ' is already in "SUCCESS" state, hence started downloading...')
                    exportPackageResponse = iics.exportPackageGet(exportJobObjectId)
                    
                    iics.log(text=exportName + '-> ' + 'downloading file name: "' + assetName +'.zip"')
                    zipFilePath = os.path.join(exportPackagePath, assetName + '.zip')
                    with open(zipFilePath, 'wb') as zip:
                        zip.write(exportPackageResponse.content)

                    iics.log(text=exportName + '-> ' + "downloaded file name: " + assetName + ".zip successfully")
                    
                    break
                # if export job status is 'failed'
                else:
                    iics.log(text=exportName + '-> ' + exportJobResponseJson["id"] + 'status is in "FAILED" state')
                    iics.log(text=exportName + '-> ' + exportJobResponseJson)
                    raise Exception(json.dumps(exportJobResponseJson))
            else:
                iics.log(text=exportName + '-> ' + 'Tried ' + str(exportProjectRetry) + ' times to export job id:' + exportJobObjectId + 
                                ', but still in IN_PROGRESS state')
                break

def call_lookup(session, email_addresses, projectid_array):
    object_array = []
    for each_id in projectid_array:
        object_array.append({'id' : each_id.strip()})
    
    jsonString = json.dumps({"objects": object_array})
    postObject = json.loads(jsonString)
    session.log(text='lookup request: \n' + jsonString)

    lookup_response =  session.lookup(postObject)
    lookup_response_json = lookup_response.json()
    lookup_response_json_text = json.dumps(lookup_response_json)
    
    if lookup_response.status_code != 200:
        session.log(text='Error while calling IICS lookup API. status_code: ' + str(lookup_response.status_code))
        session.log(text='Error response: ' + lookup_response_json_text)
        email_body = 'Error while calling IICS lookup API. Please check the attached log file'
        failToBackupProject(session, email_addresses, email_body)
    else:
        session.log(text='lookup response: ' + lookup_response_json_text)

    return lookup_response_json

def backup_project(project_id, project_name, timestamp, backup_path, project_waiting_seconds, project_retry_seconds, success_project_names, failed_project_names):
    try:
        project_name = str(project_name)
        zip_file_name = project_name + '_' + timestamp
        directory_list = []
        directory_list.append('projects')
        directory_list.append(project_name)
        project_backup_directory_path = checkAndCreateDirectory(sessionContainer['iics'], backup_path, directory_list)
        
        exportPackageJob(sessionContainer['iics'], project_id, zip_file_name, project_backup_directory_path, '[' + project_name + ']', project_waiting_seconds, project_retry_seconds)
        success_project_names.append(project_name)

    except Exception as project_download_exception:
        failed_project_names.append(project_name)
        failure_message = "Runtime error while taking backup of project name: " + project_name + '. \n error details: ' + str(project_download_exception)
        sessionContainer['iics'].log(text=failure_message)

def exportIICSProjectToNetworkDrive(session, log_file_name):
    config = session.scriptConfig
    env = str(session.env)
    email_addresses = []
    backup_path = config['project']['backup']['dsfserverpath'] + config['project']['backup']['env'][env]['backuppath']
    session.logFileName = Path(backup_path)/config['project']['backup']['logpath']/log_file_name
    project_waiting_seconds = int(config['project']['waitseconds'])
    project_retry_seconds = int(config['project']['retrycount'])
    allow_project_ids = config['project']['backup']['env'][env]['projectids']
    email_addresses.append(config['project']['emaildefaultrecipients'])

    try:
        if not session.login():
            fail_message = "Couldn't able to login to IICS " + env.upper()
            session.log(text=fail_message)
            failToBackupProject(session, email_addresses, fail_message)
        
        projectid_array = allow_project_ids.split(',')
        lookup_response_json = call_lookup(session, email_addresses, projectid_array)
        
        success_project_names = []
        failed_project_names = []
        threads=[]
        timestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
        
        for each_project in lookup_response_json["objects"]:
            project_id = str(each_project['id'])
            project_name = str(each_project['path']).lower()
            
            session.log(text='processing for project name: ' + project_name + '\n')

            each_thread = threading.Thread(target=backup_project, args=(project_id, project_name, timestamp, backup_path, project_waiting_seconds, project_retry_seconds, success_project_names, failed_project_names))
            each_thread.start()
            threads.append(each_thread)
        
        for each_thread in threads:
            each_thread.join()

        session.logout()

        email_message = ''

        if len(success_project_names) > 0:
            email_message = "Backup have been taken successfully at " + timestamp.replace('_',' ') + ' for the following projects:\r\n '
            email_message = email_message + ' \r\n '.join(success_project_names)
        
        if len(failed_project_names) > 0:
            if email_message != '':
                email_message = email_message + '\r\n \r\n \r\n '

            email_message = email_message + "Couldn't able to take the backup of the following projects due to a runtime error:\r\n "
            email_message = email_message + ' \r\n '.join(failed_project_names) + ' \r\n Please check the attached log file.'

        email_message = 'IICS ' + env.upper() + ' projects backup status:\r\n \r\n ' + email_message
        email_subject = 'IICS ' + env.upper() + ' Backup | '
        
        if len(failed_project_names) == 0:
            email_subject = email_subject + 'Success'     
        else:
            email_subject = email_subject + 'Error'

        sendEmail(session, email_addresses, email_subject, email_message, attachment=str(session.logFileName))

    except Exception as ex:
        argument = None
        session.log(text='exception message: ' + str(ex))
        
        try:
            session.logout()
        except Exception as _:
            session.log(text='Tried to logout from IICS ' + env.upper())

        if len(ex.args) == 2:
            exceptionMessage, argument = ex.args
            
        if argument is None or argument != 'exceptionhandled':
            subject = 'IICS ' + env.upper() + ' Backup | Error'
            body = 'An error occurred. Please check the attached log file.'
            sendEmail(session, email_addresses, subject, body, attachment=str(session.logFileName))
            
# main thread
if __name__ == "__main__":
    print('Running...')
    
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(baseName=os.path.basename(__file__)[:-3], taskName='')
    extraLogFilePath = str(sessionContainer['iics'].logFileName)
    log_file_name = os.path.basename(extraLogFilePath)

    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as fileRemoveException:
        print("couldn't able to delete extra log file: "+ extraLogFilePath)
    
    try:        
        exportIICSProjectToNetworkDrive(sessionContainer['iics'], log_file_name)
        
        print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e, email=False)