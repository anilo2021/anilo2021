###################################################################################################### 
# Name:                 runtaskflow.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/runtaskflow.vsdx
# Command line usage:   python start.py runtaskflow <projectName> <taskflowPath> <taskflowName> <timeout> <pollInterval>
# Purpose:              Invoke and monitor an IICS taskflow for given time and with polling interval
#######################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-01-14 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
import multiprocessing
from pathlib import Path
import sys
import time
# local module imports
from iics.iicssession import iicsSession

# function to invoke a taskflow
# TODO: add full support for parameters as future state requires
def taskflowInvoke(session, taskflowServiceName, params=None):
    if not params:
        return session.taskflowRun(taskflowServiceName)
    else:
        return session.taskflowRun(taskflowServiceName, params)

# monitors taskflow status until complete, with specified interval, and returns success status
def taskflowMonitorStatus(session, runId, timeoutProcess, period):
    session.log(text='Monitoring job with Run ID '+runId+' and checking every '+str(period/60)+' minutes')
    # loop as long as timeout process has not finished
    noStatusCounter = 0
    errorHappened = False
    success = False # default to failure
    while timeoutProcess.is_alive():
        try:
            session.log(text='Checking taskflow status for job '+runId)
            statusJson = session.taskflowStatusGet(runId).json()
            session.log(text=statusJson['status'])
            # if status is error, record in log and break loop
            if 'error' in statusJson:
                session.log(text=statusJson['error'])
                break
            # handle returned status if finished, otherwise wait before checking again
            else:
                if statusJson['status'] == 'SUCCESS':
                    success = True # indicated success
                    break
                elif statusJson['status'] in ['FAILED', 'SUSPENDED']:
                    break
                else:
                    # handle a lack of status, which cannot be trusted since it can be fine or an error
                    if statusJson['status'] == 'No status available.':
                        # terminate if no status for 2 minutes
                        if noStatusCounter*period >= 120:
                            session.log(text='Job returned no status for 2 minutes - check job in IICS! Terminating script...')
                            break
                        noStatusCounter+=1
                    session.log(text='Job unfinished, waiting '+str(period/60)+' minutes before retrying...')
                    # check timeout process while waiting
                    for _ in range(period):
                        if not timeoutProcess.is_alive():
                            break
                        else:
                            time.sleep(1)
        except Exception as e:
            # fail if it has failed before
            if errorHappened:
                raise e
            # try again if it has not yet failed
            else:
                session.error(e, exit=False)
                session.log('Exception handled. Attempting to resume monitoring...')
    # kill timeout if running and return success indicator
    if timeoutProcess.is_alive():
        timeoutProcess.terminate()
    return success

# test function
def runTaskflow(session, taskflowPath, taskflowServiceName, timeoutProcess, period=60):
    session.log(text='Looking up taskflow '+taskflowPath)
    lookupData = {
        'objects' : [{ 
            "path" : taskflowPath,
            "type" : "TASKFLOW" 
            }]
    }
    resultList = session.lookup(lookupData).json()['objects']
    # if exactly one taskflow of given name in given project, continue with invocation
    if len(resultList) == 1:
        session.log(text='Invoking taskflow "'+taskflowServiceName+'"')
        runId = taskflowInvoke(session, taskflowServiceName, {}).json()['RunId']
        session.log(text='Taskflow invoked.')
        # monitor taskflow status until status returned
        success = taskflowMonitorStatus(session, runId, timeoutProcess, period)
        # handle success or failure
        if success:
            session.log(text='Taskflow completed successfully.')
        else:
            session.log(text='Taskflow failed! See session logs in IICS.')
            sys.exit(1)
    # fail script if there is not exactly one taskflow of given name in project
    else:
        session.log(text='Taskflow not found! Terminating script...')
        sys.exit(1)        
        

# main thread
if __name__ == "__main__":
    print('Running...')
    taskflowPath = sys.argv[2].replace('\\','/')
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(Path(__file__).stem, taskName=taskflowPath.replace('/', '_'))
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            # set timeout as secondary thread using second argument
            timeoutLimit = 300 if int(sys.argv[4]) < 5 else int(sys.argv[4])*60 # at least 5 minutes
            timeoutProcess = multiprocessing.Process(target=sessionContainer['iics'].timer, args=[timeoutLimit])
            timeoutProcess.start()
            # handle command line args
            period = 60 if int(sys.argv[5]) < 1 else int(sys.argv[5])*60 # at least one minute
            # validate project name
            if sys.argv[2].startswith(sys.argv[1]):
                sessionContainer['iics'].log(text='Taskflow running from project '+sys.argv[1])
                runTaskflow(sessionContainer['iics'], taskflowPath, sys.argv[3], timeoutProcess, period)
                sessionContainer['iics'].logout()
                print('Script execution complete')
            else:
                sessionContainer['iics'].logout()
                raise ValueError('Invalid taskflow path - project name does not match "'+sys.argv[1]+'"')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        sessionContainer['iics'].iicsError(e, email=sessionContainer['iics'].scriptConfig['errorNotification'])