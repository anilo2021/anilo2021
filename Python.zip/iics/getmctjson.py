####################################################################################################
# Name:                 getmctjson.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/getmctjson.vsdx
# Command line usage:   python start.py getmctjson <taskName> <fileName>
# Purpose:              GETs and saves JSON file of mttask object from IICS API
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
import os
import sys
# local module imports
from iics.iicssession import iicsSession

# updates/creates mapping task examples
def getMctJson(session, taskName, fileName):
    session.log(text='Getting mapping configuration task example '+taskName+' from IICS')
    # get and format desired Mapping Task example from IICS
    taskJson = session.taskGet('name/'+taskName).json()
    # if no mapping task returned, end function
    if taskJson['@type'] != 'mtTask':
        session.log(text='Invalid mapping task name')
    else:
        # remove extraneous items from task object
        items = ('agentId', 'createdBy', 'createTime', 'id', 'lastRunTime', 'updateTime', 'updatedBy')
        for item in items:
            if item in taskJson:
                del taskJson[item]
        # save new JSON example based on task
        session.log(text='Creating new example mapping task '+fileName)
        session.createJsonFile('taskTemplates/'+fileName, taskJson)
        
# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(os.path.basename(__file__)[:-3], taskName=sys.argv[2]) # remove ".py" from script name
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            # handle command line args
            getMctJson(sessionContainer['iics'], sys.argv[1], sys.argv[2])
            sessionContainer['iics'].logout()
            print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e)