####################################################################################################
# Name:                 iicsfolderbackup.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/iicsfolderbackup.vsdx
# Command line usage:   python start.py iicsfolderbackup
# Purpose:              Backup IICS Project folders from IICS DEV, SQA & PRD
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2022-02-23 Sanju Joseph (sanj827@kellyservices.com)      Original Author
####################################################################################################

# library imports
import json
import threading
import time
import sys
from pathlib import Path
import datetime
import pandas as pd
import numpy as np

# local module imports
from iics.iicssession import iicsSession

# converts plain text to html format
def convertPlainTextToHtml(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def sendEmail(session, emailAddress, subject, body, attachment=None):
    try:
        body = convertPlainTextToHtml(body)
        with open(session.configDirectory/'emailTemplates'/'emailbody_iicsexport.html') as template:
            emailbody = template.read().format(body)
        
        session.email(subject, emailbody, attachment=attachment, recipients=emailAddress)
    except Exception as emailException:
        session.log(text="error occurred while sending email. Error details: " + str(emailException))

def failToBackupFolder(session, emailAddresses):
    emailBody = 'Error while calling IICS lookup API. Please check the attached log file'
    subject = 'IICS ' + str(session.env).upper() + ' Backup | Error'
    sendEmail(session, emailAddresses, subject, emailBody, attachment=str(session.logFileName))
    raise Exception(emailAddresses, 'exceptionhandled')

def getFolderDataFrame(session, projectNameList, emailAddresses):
    skip=0
    totalFoldersReceived = 0
    maxRecordLimit = session.scriptConfig['backup']['maxRecordLimit']
    assetType = session.scriptConfig['backup']['assetType']
    mainFolderListDataFrame = {}
    session.log(text='request project names are: [{}]'.format(','.join(projectNameList)))
    
    while True:
        totalFolders = 0
        queryString = 'type==\'{}\'&skip={}'.format(assetType, skip)
        objectDetailsResponse = session.getObjectDetails(queryString)
        objectDetailsResponseJson = objectDetailsResponse.json()
        folderReceivedCount = 0
        if objectDetailsResponse.status_code != 200:
            objectDetailsResponseJsonText = json.dumps(objectDetailsResponseJson)
            session.log(text='received error response while calling getObjectDetails() API. status_code: {}'.format(queryString, str(objectDetailsResponse.status_code)))
            session.log(text='error response details: ' + objectDetailsResponseJsonText)
            
            failToBackupFolder(session, emailAddresses)
        else:
            session.log(text='received getObjectDetails() API response successfully: '.format(queryString))
            totalFolders = objectDetailsResponseJson['count']
            
            folderObjectsDataFrame = pd.DataFrame().from_dict(objectDetailsResponseJson['objects'])
            folderReceivedCount = folderObjectsDataFrame.shape[0]
            totalFoldersReceived += folderReceivedCount
            session.log(text='received {} records'.format(folderReceivedCount))
            if folderReceivedCount > 0:
                folderObjectsDataFrame['type'] = folderObjectsDataFrame['type'].str.upper()
                newDfs = folderObjectsDataFrame['path'].str.split('/', 1, expand=True)
                folderObjectsDataFrame['project'] = newDfs[0]
                folderObjectsDataFrame['folder'] = newDfs[1]
                
                if isinstance(mainFolderListDataFrame, pd.DataFrame):
                    mainFolderListDataFrame = pd.concat([mainFolderListDataFrame,folderObjectsDataFrame], ignore_index=True)
                else:
                    mainFolderListDataFrame = folderObjectsDataFrame.copy()
                
                session.log(text='received {} records out of {}'.format((folderObjectsDataFrame.shape[0]+skip), totalFolders))

        if totalFolders <= totalFoldersReceived:
            mainFolderListDataFrame = mainFolderListDataFrame[(mainFolderListDataFrame['type']==assetType) & (mainFolderListDataFrame['project'].isin(projectNameList))][['id','path','project','folder']]
            session.log(text='total no. of folders to export based on given projects: {}'.format(mainFolderListDataFrame.shape[0]))
            return mainFolderListDataFrame
        else:
            skip += maxRecordLimit

# create directory if directory doesn't exist and returns directory path
def checkAndCreateDirectory(session, projectName, backupPath, directoryList):
    for eachDirectory in directoryList:
        backupPath = Path(backupPath)
        backupPath = backupPath/eachDirectory
        if not backupPath.is_dir():
            try:
                backupPath.mkdir(parents=True, exist_ok=True)
                session.log(text="created new directory name '{}' for project '{}'.".format(eachDirectory, projectName))
            except OSError as osError:
                session.log(text="An error occurred while creating '{}' directory. Error details: {}".format(eachDirectory, osError))
    return backupPath

def triggerExportFolders(iics, projectName, assetId, exportName):
    exportName = '[{}/{}]'.format(projectName, exportName)
    jsonString = '{"objects":[{"id": "' + assetId + '", "includeDependencies" : false}]}'
    postObject = json.loads(jsonString)
    iics.log(text=exportName + '-> ' + 'sending export request...')
    exportJobResponse = iics.exportJobStart(postObject)
    exportJobResponseJson = exportJobResponse.json()
    if exportJobResponse.status_code != 200:
            iics.log(text=exportName + '-> ' + 'Error: folder export got failed. Status code: ' + str(exportJobResponse.status_code))
            iics.log(text=exportName + '-> Error response: ' + json.dumps(exportJobResponseJson))
            raise Exception(json.dumps(exportJobResponseJson))
    else:
        iics.log(text=exportName + '-> ' + 'received success response.')
        return exportJobResponseJson["id"]

def checkExportFoldersStatus(iics, projectName, exportJobObjectId, assetName, exportPackagePath, waitingSeconds, retry):
    exportName = '[{}/{}]'.format(projectName, assetName)
    zipFileName = assetName + '.zip'
    while True:
        if retry > 0:
            retry = retry - 1
            iics.log(text=exportName + '-> ' + "checking asset objectid status:"+ exportJobObjectId)
            exportJobResponse = iics.exportJobStatusGet(exportJobObjectId)
            if exportJobResponse.status_code != 200:
                iics.log(text=exportName + '-> ' + "Error: failed exportJobStatusGet api for asset objectid: " 
                                + exportJobObjectId)
                exportJobResponseJsonError = exportJobResponse.json()
                iics.log(text=exportName + '-> ' + json.dumps(exportJobResponseJsonError))

                if exportJobResponseJsonError['error']['code'] == 'AUTH_01':
                    iics.log(text=exportName + '-> ' + 'Authentication failure, hence trying to re-login to IICS')
                    iics.login()
                    continue
                else:
                    raise Exception(json.dumps(exportJobResponseJsonError))

            exportJobResponseJson = exportJobResponse.json()

            # if export job status is 'in progress' then retry again
            if exportJobResponseJson["status"]["state"] == "IN_PROGRESS":
                iics.log(text=exportName + '-> ' + ' export status is in "IN_PRORESS" state, will check again after ' + str(waitingSeconds) + ' seconds')
                time.sleep(waitingSeconds)
            
            # if export job status is 'successful' then download the asset zip file to DFS drive
            elif exportJobResponseJson["status"]["state"] == "SUCCESSFUL":
                iics.log(text=exportName + '-> ' + 'export status is in "SUCCESS" state.')
                exportPackageResponse = iics.exportPackageGet(exportJobObjectId)
                
                iics.log(text=exportName + '-> ' + 'downloading file name: "' + zipFileName+'.')
                zipFilePath = exportPackagePath/zipFileName
                with open(zipFilePath, 'wb') as zip:
                    zip.write(exportPackageResponse.content)

                iics.log(text=exportName + '-> ' + "downloaded file name: " + zipFileName + " successfully.")
                
                break
            # if export job status is 'failed'
            else:
                iics.log(text=exportName + '-> ' + exportJobResponseJson["id"] + 'status is in "FAILED" state.')
                iics.log(text=exportName + '-> ' + exportJobResponseJson)
                raise Exception(json.dumps(exportJobResponseJson))
        else:
            iics.log(text=exportName + '-> ' + 'Tried ' + str(retry) + ' times to export job id:' + exportJobObjectId + 
                            ', but still in IN_PROGRESS state')
            break

def exportFolders(session, projectName, projectWiseFolderDataFrame, exportFolderPath, waitingSeconds, exportAssetRetry):
    folderIds = projectWiseFolderDataFrame['id'].tolist()
    folderNames = projectWiseFolderDataFrame['folder'].tolist()
    projectWiseFolderDataFrame['jobId'] = np.nan
    projectWiseFolderDataFrame['exportTriggered'] = False
    projectWiseFolderDataFrame['downloaded'] = False
    projectWiseFolderDataFrame['errorCode'] = np.nan
    projectWiseFolderDataFrame['errorMessage'] = np.nan

    totalFolderCount = len(folderIds)
    for folderIndex in range(0, totalFolderCount):
        iicsFolderId = folderIds[folderIndex]
        iicsFolderName = folderNames[folderIndex]
        try:
            jobId = triggerExportFolders(session, projectName, iicsFolderId, iicsFolderName)
            projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['id']==iicsFolderId,'jobId'] = jobId
            projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['id']==iicsFolderId,'exportTriggered'] = True
            session.log(text='[{}/{}] folder backup triggered and received job-id:{}'.format(projectName, iicsFolderName, jobId))
        except Exception as folderExportTriggerException:
            exportJobResponseErorJson = json.loads(folderExportTriggerException.args[0])
            if 'error' in exportJobResponseErorJson:
                if 'code' in exportJobResponseErorJson['error']:
                    projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['id']==iicsFolderId,'errorCode'] = exportJobResponseErorJson['error']['code']
                if 'message' in exportJobResponseErorJson['error']:
                    projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['id']==iicsFolderId,'errorMessage'] = exportJobResponseErorJson['error']['message']
            
    jobIdDataFrame = projectWiseFolderDataFrame[~projectWiseFolderDataFrame['jobId'].isnull()]
    jobIds = jobIdDataFrame['jobId'].tolist()
    folderNames = jobIdDataFrame['folder'].tolist()

    for jobIdIndex in range(0, len(jobIds)):
        jobId = jobIds[jobIdIndex]
        folderName = folderNames[jobIdIndex]
        iicsFolderName = projectWiseFolderDataFrame[projectWiseFolderDataFrame['jobId']==jobId]
        try:
            checkExportFoldersStatus(session, projectName, jobId, folderName, exportFolderPath, waitingSeconds, exportAssetRetry)
            projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['jobId']==jobId,'downloaded'] = True
        except Exception as folderExportException:
            exportJobResponseErorJson = json.loads(folderExportException.args[0])
            if 'error' in exportJobResponseErorJson:
                if 'code' in exportJobResponseErorJson['error']:
                    projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['jobId']==jobId,'errorCode'] = exportJobResponseErorJson['error']['code']
                if 'message' in exportJobResponseErorJson['error']:
                    projectWiseFolderDataFrame.loc[projectWiseFolderDataFrame['jobId']==jobId,'errorMessage'] = exportJobResponseErorJson['error']['message']
        
def createSummaryLog(session, projectName, folderBackupDirectoryPath, projectWiseFolderDataFrame):
    folderBackupProjectwisePath = None
    try:
        backupStatusFileNameFormat = session.scriptConfig['backup']['backupStatusFileNameFormat']
        projectFileName = backupStatusFileNameFormat.format(projectName)
        session.log(text='creating {} file.'.format(projectFileName))
        folderBackupProjectwisePath = folderBackupDirectoryPath/projectFileName
        projectwiseFolderInCSVFormat = projectWiseFolderDataFrame.to_csv(path_or_buf=None, index=False, line_terminator='\n')
        with open(folderBackupProjectwisePath, 'w') as fileHandler:
            fileHandler.write(projectwiseFolderInCSVFormat)
        session.log(text='created {} file.'.format(projectFileName))
    except Exception:
        folderBackupProjectwisePath = None
    return folderBackupProjectwisePath

def backupFolder(projectName, projectWiseFolderDataFrame, timestamp, backupPath, folderBackupWaitingSeconds, folderBackupRetrySeconds, succeedFolderBackupNames, failedFolderBackupNames, csvFileList):
    session = sessionContainer['iics']
    session.log(text='processing for project name: ' + projectName)
    
    directoryList = []
    directoryList.append('projects')
    directoryList.append(projectName)
    directoryList.append(timestamp)
    folderBackupDirectoryPath = checkAndCreateDirectory(session, projectName, backupPath, directoryList)
    
    exportFolders(session, projectName, projectWiseFolderDataFrame, folderBackupDirectoryPath, folderBackupWaitingSeconds, folderBackupRetrySeconds)
    succeedFolderNames = projectWiseFolderDataFrame[projectWiseFolderDataFrame['downloaded']==True]['path'].tolist()
    failedFolderNames = projectWiseFolderDataFrame[projectWiseFolderDataFrame['downloaded']==False]['path'].tolist()
    succeedFolderBackupNames.extend(succeedFolderNames)
    failedFolderBackupNames.extend(failedFolderNames)
    session.log(text='project [{}] -> {} folders exported successfully.'.format(projectName, len(succeedFolderBackupNames)))
    session.log(text='project [{}] -> {} folders failed to export.'.format(projectName, len(failedFolderBackupNames)))
    csvfilePath = createSummaryLog(session, projectName, folderBackupDirectoryPath, projectWiseFolderDataFrame)
    if csvfilePath:
        csvFileList.append(str(csvfilePath))

def saveFolderBackupToDFS(session, logFileName):
    env = str(session.env)
    emailAddresses = session.scriptConfig['backup']['emaildefaultrecipients']
    folderWaitingSeconds = session.scriptConfig['backup']['waitseconds']
    folderRetrySeconds = session.scriptConfig['backup']['retrycount']
    projectNameList = session.scriptConfig['backup']['env'][env]['projectNames']
    backupDirPath = session.scriptConfig['backup']['env'][env]['backupPath']
    logDirName = session.scriptConfig['backup']['env'][env]['logpath']
    session.logFileName = Path(backupDirPath)/logDirName/logFileName

    try:
        if not session.login():
            failMessage = "Couldn't able to login to IICS " + env.upper()
            session.log(text=failMessage)
            failToBackupFolder(session, emailAddresses, failMessage)
    
        folderDataFrame = getFolderDataFrame(session, projectNameList, emailAddresses)
        
        succeedFolderBackupNames = []
        failedFolderBackupNames = []
        csvFileList = []
        threads=[]
        timestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
        projectNames = folderDataFrame['project'].unique()
        for eachProject in projectNames:
            projectWiseFolderDataFrame = folderDataFrame[folderDataFrame['project']==eachProject][['id', 'path', 'folder']]
            projectName = str(eachProject).lower()
            if projectWiseFolderDataFrame.shape[0] > 0:
                each_thread = threading.Thread(target=backupFolder, args=(projectName, projectWiseFolderDataFrame, timestamp, backupDirPath, folderWaitingSeconds, folderRetrySeconds, succeedFolderBackupNames, failedFolderBackupNames, csvFileList))
                each_thread.start()
                threads.append(each_thread)
            else:
                session.log(text='No folder found for project:{}, hence ignoring to take the backup of this project.'.format(eachProject))
        
        for each_thread in threads:
            each_thread.join()

        session.logout()
        
        email_message = ''
        datetimeList = timestamp.split('_')
        email_message = 'Project backup triggered at {} {} EST. Following are the backup summary:\r\n'.format(datetimeList[0], datetimeList[1].replace('-',':'))
        email_message = email_message + '\t<table border=1><tr><th>Project Name</th><th>Succeed Folders</th><th>Failed Folders</th></tr>'
        projectNames.sort()
        for eachProject in projectNames:
            succeedFolderCount = len([fld for fld in succeedFolderBackupNames if fld.startswith('{}/'.format(eachProject))])
            failedFolderCount = len([fld for fld in failedFolderBackupNames if fld.startswith('{}/'.format(eachProject))])
            email_message = email_message + '<tr>'
            email_message = email_message + '<th>{}</th>'.format(eachProject)
            email_message = email_message + '<th>{}</th>'.format(succeedFolderCount)
            email_message = email_message + '<th>{}</th>'.format(failedFolderCount)
            email_message = email_message + '</tr>'
        email_message = email_message + '</table>'
       
        email_message = 'IICS ' + env.upper() + ' projects backup status:\r\n \r\n ' + email_message
        email_subject = 'IICS ' + env.upper() + ' Backup | '
        
        session.log(text='adding file attachment(s) to email.')
        emailAttachments = str(session.logFileName)
        if len(csvFileList) > 0:
            session.log(text='csv file path details:')
            emailAttachments = csvFileList
            session.log(text='\r\n\t'.join(emailAttachments))
    
        if len(failedFolderBackupNames) == 0:
            email_subject = email_subject + 'Success'     
        else:
            email_subject = email_subject + 'Error'

        sendEmail(session, emailAddresses, email_subject, email_message, attachment=emailAttachments)

    except Exception as ex:
        argument = None
        session.log(text='exception occurred. Exception details: ' + str(ex))
        
        try:
            session.logout()
        except Exception as _:
            session.log(text='Tried to logout from IICS ' + env.upper())

        if len(ex.args) == 2:
            exceptionMessage, argument = ex.args
            
        if argument is None or argument != 'exceptionhandled':
            subject = 'IICS ' + env.upper() + ' Backup | Error'
            body = 'An error occurred. Please check the attached log file.'
            sendEmail(session, emailAddresses, subject, body, attachment=str(session.logFileName))

# main thread
if __name__ == "__main__":
    print('Running...')
    
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(baseName=Path(__file__).stem, taskName='')
    extraLogFilePath = Path(sessionContainer['iics'].logFileName)
    logFileName = extraLogFilePath.name

    try:
        if extraLogFilePath.is_file():
            extraLogFilePath.unlink()
    except Exception as fileRemoveException:
        print("couldn't able to delete this extra log file: "+ str(extraLogFilePath))
    
    try:        
        saveFolderBackupToDFS(sessionContainer['iics'], logFileName)
        
        print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e, email=False)