####################################################################################################
# Name:                 runmassingest.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/runmassingest.vsdx
# Command line usage:   python start.py runmassingest <taskPath> <timeout> <pollInterval>
# Purpose:              Invoke and monitor an IICS mass ingest task for given time and with polling 
#                       interval
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-10-28 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import json
import multiprocessing
from pathlib import Path
import sys
import time
# local module imports
from iics.iicssession import iicsSession

# monitors taskflow status until complete, with specified interval, and returns success status
def massIngestMonitorStatus(session, runId, timeoutProcess, period):
    session.log(text='Monitoring job with Run ID '+str(runId)+' and checking every '+str(period/60)+' minutes')
    # loop as long as timeout process has not finished
    success = False # default to failure
    while timeoutProcess.is_alive():
        session.log(text='Checking mass ingest status for job '+str(runId))
        statusJson = session.massIngestStatusGet(runId).json()
        session.log(text=statusJson['jobStatus'])
        # if status is error, record in log and break loop
        if 'error' in statusJson:
            session.log(text=statusJson['error'])
            break
        # handle returned status if finished, otherwise wait before checking again
        else:
            if statusJson['jobStatus'] == 'SUCCESS':
                success = True # indicated success
                break
            elif statusJson['jobStatus'] in ['FAILED', 'SUSPENDED']:
                break
            else:
                session.log(text='Job unfinished, waiting '+str(period/60)+' minutes before retrying...')
                # check timeout process while waiting
                for _ in range(period):
                    if not timeoutProcess.is_alive():
                        break
                    else:
                        time.sleep(1)
    # kill timeout if running and return success indicator
    if timeoutProcess.is_alive():
        timeoutProcess.terminate()
    return success

# test function
def runMassIngest(session, taskPath, timeoutProcess, period=60):
    session.log(text='Looking up mass ingest task '+taskPath)
    lookupData = {
        'objects' : [{ 
            'path' : taskPath,
            'type': 'MI_TASK'
            }]
    }
    resultList = session.lookup(lookupData).json()['objects']
    # if exactly one taskflow of given name in given project, continue with invocation
    if len(resultList) == 1:
        jobData = {
            'taskId' : resultList[0]['id']
        }
        session.log(text='Invoking mass ingest task with ID: '+resultList[0]['id'])
        runResponse = session.massIngestRun(jobData)
        runId = runResponse.json()['runId']
        session.log(text='Mass ingest invoked.')
        # monitor taskflow status until status returned
        success = massIngestMonitorStatus(session, runId, timeoutProcess, period)
        # handle success or failure
        if success:
            session.log(text='Mass ingest completed successfully.')
        else:
            session.log(text='Mass ingest failed! See session logs in IICS.')
            sys.exit(1)
    # fail script if there is not exactly one task of given name in project
    else:
        session.log(text='Mass ingest task not found! Terminating script...')
        sys.exit(1)       
        

# main thread
if __name__ == "__main__":
    print('Running...')
    taskPath = sys.argv[2].replace('\\','/')
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(Path(__file__).stem, taskName=taskPath.replace('/', '_'))
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            # set timeout as secondary thread using second argument
            timeoutLimit = 300 if int(sys.argv[3]) < 5 else int(sys.argv[3])*60 # at least 5 minutes
            timeoutProcess = multiprocessing.Process(target=sessionContainer['iics'].timer, args=[timeoutLimit])
            timeoutProcess.start()
            # handle command line args
            period = 60 if int(sys.argv[4]) < 1 else int(sys.argv[4])*60 # at least one minute
            # validate project name
            if taskPath.startswith(sys.argv[1]):
                sessionContainer['iics'].log(text='Mass ingest running from project '+sys.argv[1])
                runMassIngest(sessionContainer['iics'], taskPath, timeoutProcess, period)
                sessionContainer['iics'].logout()
                print('Script execution complete')
            else:
                sessionContainer['iics'].logout()
                raise ValueError('Invalid taskflow path - project name does not match "'+sys.argv[1]+'"')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        sessionContainer['iics'].iicsError(e)