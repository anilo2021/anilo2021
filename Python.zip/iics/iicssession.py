####################################################################################################
# Name:                 iicssession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/7/iicssession
# Command line usage:   N/A
# Purpose:              Class contains methods for IICS API automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)      Original Author
####################################################################################################
# iicswrapper.py
# Original Author: Jesse Rominske (jesr114@kellyservices.com)
# Python version 3.6.4
# Command Line Usage: python iicswrapper.py
# Function:
#   - "Grunt work" for IICS API automation
#   - Class that contains session methods for interfacing with
#     IICS API in an easier and more readable way - a basic
#     Python framework for the IICS API
# Revision History:
#   - 1.0 - 2018/08/16 by Jesse Rominske (jesr114@kellyservices.com)

# library imports
import requests
import json
import os
import sys
# local module imports
from common.session import session

# session subclass with methods relevant to IICS Automation
class iicsSession(session):
    # overloaded setup method
    def _setup(self):
        self.directory = self.repoDirectory/'iics'
        # load stored credentials from JSON file
        self.iicsCreds = json.load(open(self.secureDirectory/(self.env+'_iicscreds.json')))
        self.iicsConfig = json.load(open(self.configDirectory/(self.env+'_iicsconfig.json')))
        # session variables for IICS API interface
        self.serverUrl = self.iicsConfig['serverUrl'][self.env] # API url for IICS org
        self.loginUrl = self.iicsConfig['loginUrl'][self.env] # login url for IICS org
        self.basehdrs = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        self.req = requests.Session()
    
    # logs user in and adds an authenticated session id to header              
    def login(self):
        self.log(text='Logging into IICS as '+self.iicsCreds['iicsuser'])
        loginData = {'username': self.iicsCreds['iicsuser'],
                     'password': self.iicsCreds['iicspassword']}
        self.hdrs = self.basehdrs.copy()
        response = self.req.post(self.loginUrl+'/login', headers=self.hdrs, json=loginData)
        if response.status_code == 200: 
            self.log(text='Login Success')
            self.hdrs['IDS-SESSION-ID'] = response.json()['userInfo']['sessionId']
            self.hdrs['icSessionId'] = response.json()['userInfo']['sessionId']
            self.hdrs['INFA-SESSION-ID'] = response.json()['userInfo']['sessionId']
            return True
        else:
            self.log(text='Login Failed')
            self.log(text=response.text)
            return False
    
    # logs user out to end session (best practice)
    def logout(self): 
        logoutData = {'username': self.iicsCreds['iicsuser'],
                      'password': self.iicsCreds['iicspassword']}
        response = self.req.post(self.loginUrl+'/logout', headers=self.hdrs, json=logoutData)
        if response.status_code == 200: 
            self.log(text='\nSession ended')
        else:
            self.error(response.text)

    # method for sending emails specific to IICS
    def iicsEmail(self, subject, body, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.repoDirectory/'common'/'emailTemplates'/'emailbody_secureagent.html') as template:
            self.email(subject=subject,
                       body=template.read().format(body), # replace "{}" in template file with values
                       attachment=attachment, recipients=recipients) # call basic email function

    # method for send error report email for IICS
    def iicsError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.iicsEmail('Notification from AIM IICS Automation System',
                        'An error occurred with code: '+str(errorCode)+'<br>Please check the logs.')
        sys.exit(errorCode)

    # generic API Resource method (private)
    def _doAPI(self, reqType, uri, postObject=None, fullUpdate=True, data=None):
        # validate session ID
        self.log(text='Validating session...')
        validatedToken = {'@type': 'validatedToken',
                          'userName': self.iicsCreds['iicsuser'],
                          'icToken': self.hdrs['icSessionId']}
        icToken = self.req.post(self.serverUrl+'/saas/api/v2/user/validSessionId', headers=self.hdrs, json=validatedToken).json()
        if not icToken['isValidToken']:
            # login again to refresh session ID if necessary
            self.log(text='Session expired! Refeshing session...')
            self.login()
            self.log(text='Session refreshed')
        else:
            self.log(text='Session validated')
        # prepare to access API resource
        url = self.serverUrl+uri
        self.log(text='Accessing API resource at '+url)
        # switch method use based on request type
        # simply get if method is GET
        if reqType == 'GET':
            return self.req.get(url, headers=self.hdrs)
        # just do normal request call on POST
        if reqType == 'POST':
            if data is None:
                return self.req.post(url, headers=self.hdrs, json=postObject)
            else:
                # upload file via post
                fileUploadHeaders = {}
                fileUploadHeaders['INFA-SESSION-ID'] = self.hdrs['INFA-SESSION-ID']
                fileUploadHeaders['Content-Type'] = 'multipart/form-data; boundary=------------------------acebdf13572468'
                return self.req.post(url, headers=fileUploadHeaders, data=data)
        # extra logic for handling headers for UPDATE modes
        elif reqType == 'UPDATE':
            # copy normal header and add update mode flag
            updateHeaders = self.hdrs
            updateHeaders['Update-Mode'] = 'FULL' if fullUpdate else 'PARTIAL'
            # call API resource
            return self.req.post(url, headers=updateHeaders, json=postObject)
        # simply delete if method is DELETE
        elif reqType == 'DELETE':
            return self.req.delete(url, headers=self.hdrs)
    
    # API V1 methods
    # method to start a mass ingestion task
    def massIngestRun(self, postObject):
        return self._doAPI('POST', '/mftsaas/api/v1/job', postObject)
    # method to check status of a mass ingestion job
    def massIngestStatusGet(self, runId):
        return self._doAPI('GET', '/mftsaas/api/v1/job/'+str(runId)+'/status')
    # method to get the details of mass ingestion task
    def massIngestDetailsGet(self, taskId):
        return self._doAPI('GET', '/mftsaas/api/v1/mitasks/'+str(taskId))

    # API V2 methods
    # method to get details of agent. pass blank objid to get all agents
    def agentDetailsGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/agent/details/'+objectId)
    # method to get details of a connection. pass blank objid to get all connections
    def connectionGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/connection/'+objectId)
    # method to test a connection.
    def connectionTest(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/connection/test/'+objectId)
    # method to update connections
    def connectionUpdate(self, objectId, postObject, fullUpdate=True):
        return self._doAPI('UPDATE', '/saas/api/v2/connection/', postObject, fullUpdate)
    # method to start an IICS job given object with id/name, type, and callbackURL
    def jobStart(self, postObject):
        return self._doAPI('POST', '/saas/api/v2/job/', postObject)
    # method to stop an IICS job given object with id/name and type
    def jobStop(self, postObject):
        return self._doAPI('POST', '/saas/api/v2/job/stop/', postObject)
    # method to get a mapping 
    def mappingGet(self, objectName):   
        return self._doAPI('GET', '/saas/api/v2/mapping/name/'+ objectName)
    # method to get a mappingtask
    def mappingTaskGet(self, objectName):   
        return self._doAPI('GET', '/saas/api/v2/mttask/name/'+ objectName)
    # method to get details of org
    def orgGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/org/'+objectId)
    # method to get details of runtime environment. pass blank objid to get all agents
    def runtimeEnvironmentGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/runtimeEnvironment/'+objectId)
    # method to get schedules
    def scheduleGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/schedule/'+objectId)
    # method to create task. have to pass a valid json template
    def taskCreate(self, postObject):
        return self._doAPI('POST', '/saas/api/v2/mttask/', postObject)
    # method to delete task by ID
    def taskDelete(self, objectId):
        return self._doAPI('DELETE', '/saas/api/v2/mttask/'+objectId)
    # method to run a taskflow asynchronously
    def taskflowRun(self, objectId, postObject=None):
        return self._doAPI('POST', '/active-bpel/rt/'+objectId, postObject)
    # method to get status of asynchronous taskflow
    def taskflowStatusGet(self, objectId, postObject=None):
        return self._doAPI('GET', '/active-bpel/services/tf/status/'+objectId)
    # method to get details of a task. pass blank objectid to get a paginated list of all tasks.    
    def taskGet(self, objectId=''):   
        return self._doAPI('GET', '/saas/api/v2/mttask/'+objectId)
    # method to update task (defaults to full mode). have to pass a valid json template
    def taskUpdate(self, objectId, postObject, fullUpdate=True):
        return self._doAPI('UPDATE', '/saas/api/v2/mttask/', postObject, fullUpdate)
    # method to get a workflow
    def workflowGet(self, objectId=''):
        return self._doAPI('GET', '/saas/api/v2/workflow/'+objectId)
    # method to get a fwconfig
    def fwConfigGet(self, objectName=''):
        return self._doAPI('GET', '/saas/api/v2/fwConfig/name/'+objectName.replace(' ', '%20'))

    # API V3 methods
    # method to start job to export asset based on given object ids
    def exportJobStart(self, postObject):
        return self._doAPI('POST', '/saas/public/core/v3/export', postObject)
    # method to get the export job status based on given export job id 
    def exportJobStatusGet(self, objectId):
        return self._doAPI('GET', '/saas/public/core/v3/export/' + objectId)
    # method to export package by given export job id
    def exportPackageGet(self, objectId):
        return self._doAPI('GET', '/saas/public/core/v3/export/' + objectId + '/package')
    # method to get object ids based on provided path and type of assets
    def lookup(self, postObject):
        return self._doAPI('POST', '/saas/public/core/v3/lookup', postObject)
    # method to export package by given export job id
    def uploadImportPackage(self, data):
        return self._doAPI('POST', '/saas/public/core/v3/import/package', postObject={}, data=data)
    # method to start an import job
    def startImportPackageJob(self, jobId, postObject):
        return self._doAPI('POST', '/saas/public/core/v3/import/' + jobId, postObject)
    # method to check status of an import job
    def getImportPackageJobStatus(self, jobId):
        return self._doAPI('GET', '/saas/public/core/v3/import/' + jobId + '?expand=objects')
    # method to get any asset details based on given queryString
    def getObjectDetails(self, queryString):
        return self._doAPI('GET', '/saas/public/core/v3/objects?q='+queryString)
        
# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    try:
        I = iicsSession(os.path.basename(__file__)[:-3], 'test') # remove ".py" from script name
        if not I.login():
            print('Login error - aborted')
        else:
            I.log(text=I.agentDetailsGet().text)
            I.logout()
            print('Script execution complete')
    except Exception as e:
        I.iicsError(e)