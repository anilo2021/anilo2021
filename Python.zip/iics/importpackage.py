####################################################################################################
# Name:                 importpackage.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/importpackage.vsdx
# Command line usage:   python start.py importpackage <azure_devops_commit_id>
# Purpose:              Imports IICS assets from DFS(network drive) path to IICS SQA & PRD
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-12-21 Sanju Joseph (sanj827@kellyservices.com)      Original Author
# 2022-11-15 Hanuman Dasari (hand557@kellyservices.com)    Added process and processobject for AppIntegration
# 2022-11-15 Hanuman Dasari (hand557@kellyservices.com)    Fixed the import package retry logic issue
####################################################################################################

import json
import time
import os
import sys
from pathlib import Path
import datetime
import tempfile
import zipfile
import shutil
from requests_toolbelt import MultipartEncoder

# local module imports
from iics.iicssession import iicsSession

# returns a list directory names which are not starts with underscore (_)
def getDirectoryNames(path):
    for _, dirnames, _ in os.walk(path):
        return [name for name in dirnames if not name.startswith('_')]

# returns a list of file names
def getFileNames(path):
    for _, _, filenames in os.walk(path):
        return filenames

# create directory if directory doesn't exist and returns directory path
def checkAndCreateDirectory(iics, directoryPath, directoryList):
    for eachDirectory in directoryList:
        directoryPath = os.path.join(directoryPath, eachDirectory)
        if not os.path.isdir(directoryPath):
            try:
                os.makedirs(directoryPath)
                iics.log(text="created new directory name: " + eachDirectory)
            except OSError:
                iics.log(text="'" + eachDirectory + "' directory exists")
    
    return directoryPath

def getAssetTypeDirectories(path, directorySortOrder):
    directoryList = []
    for directory in directorySortOrder.split(','):
        for assetDirectory in getDirectoryNames(path):
            if directory.lower() == assetDirectory.lower():
                directoryList.append(directory)

    return directoryList

def removeEmptySubDirectoryies(session, path):
    for subDirectory in getDirectoryNames(path):
        try:
            subDirectoryPath = os.path.join(path, subDirectory)
            os.rmdir(subDirectoryPath)
            session.log(text='Removed empty directory: ' + subDirectoryPath)
        except OSError as osError:
            session.log(text='Error occurred while removing empty directory: ' + subDirectoryPath + '. OSError details: ' + str(osError))

def getIICSAgentPath(config, env, projectName):
    return config[env]['dsfserverpath']+'\\'+config[env]['dfsinfa']+'\\'+config['iicsagents'][projectName]

def getUserParameterFilePath(config, env, projectName, fileName):
    return getIICSAgentPath(config, env, projectName)+'\\'+config[env.lower()]['userparameter']+'\\'+fileName

def getScriptsCustomFilePath(config, env, projectName, fileName):
    return getIICSAgentPath(config, env, projectName)+'\\'+config['iicsscriptscustom'][projectName]+'\\'+fileName

def getEmailAddress(session, filePath, emailNotificationLabel):
    emailAddress = None
    filehandler = open(filePath, 'r')
    fileContents = filehandler.readlines()
    filehandler.close()

    for content in fileContents:
        if content.find(emailNotificationLabel) != -1:
            emailAddress = content.split(':')[1].strip()
            break

    return emailAddress

# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def sendEmail(session, recipients, subject, body, isSuccess=False, attachment=None):
    emailDefaultRecipients = session.scriptConfig['emaildefaultrecipients']
    sendEmailToRecipientsOnSuccess = session.scriptConfig['sendemailtorecipientsonsuccess']

    if (not isSuccess) or (isSuccess and sendEmailToRecipientsOnSuccess):
        for email in emailDefaultRecipients.split(','):
            recipients.append(email.strip())

    try:
        body = convert_plaintext_to_html(body)
        with open(session.configDirectory/'emailTemplates'/'emailbody_iicsexport.html') as template:
            emailbody = template.read().format(body)

        session.email(subject, emailbody, attachment=attachment, recipients=recipients)
    except Exception as emailException:
        session.log(text="error occurred while sending email. Error details: " + str(emailException))
    
def fail(session, failureMessage):
    raise Exception(failureMessage, 'exceptionhandled')

def failWhenExceptionOccur(I, emailAddresses):
    env = str(I.env).upper()
    subject = 'IICS ' + env + ' Deployment | Error'
    body = 'An error occurred while deploying to IICS ' + env + '. Please check the attached log file.'
    sendEmail(I, emailAddresses, subject, body, isSuccess=False, attachment=str(I.logFileName))
    
def startImportPackageJob(fileCount, iics, jobId, postObject, fileTimestamp, archiveDirectoryPath, zipFilePath, wait_in_seconds, retry):
    iics.log(text='\nstarted importing package for job id: '+ jobId)
    iics.log(text=fileCount + ':: request: ' + postObject)

    importJobResponse = iics.startImportPackageJob(jobId, json.loads(postObject))
    
    if importJobResponse.status_code == 200:
        importJobResponseJson = importJobResponse.json()
        iics.log(text=fileCount + ':: response: ' + json.dumps(importJobResponseJson))
        
        if importJobResponseJson['status']['state'] == 'IN_PROGRESS':
            time.sleep(wait_in_seconds)
            
            while True and (retry > 0):
                importJobResponse = iics.getImportPackageJobStatus(jobId)
                if importJobResponse.status_code == 200:
                    importJobResponseJson = importJobResponse.json()
                    if importJobResponseJson['status']['state'] == 'IN_PROGRESS':
                        iics.log(text=fileCount + ':: still in "IN PROGRESS", hence re-trying after ' + str(wait_in_seconds) + 'seconds')
                        retry = retry - 1
                        time.sleep(wait_in_seconds)
                        continue
                    elif importJobResponseJson['status']['state'] == 'SUCCESSFUL':
                        iics.log(text=fileCount + ' imported successfully. :: response: ' + json.dumps(importJobResponseJson))
                        break
                    else:
                        iics.log(text=fileCount + 'error occurred :: response: ' + json.dumps(importJobResponseJson))
                        fail(iics, 'An error occurred while importing IICS package')
                else:
                    iics.log(text=fileCount + ':: error code: ' + str(importJobResponse.status_code) + '. error details: ' + importJobResponse.text)
                    fail(iics, 'An error occurred while importing IICS package')
                    break
            if (retry == 0) and (importJobResponseJson['status']['state'] == 'IN_PROGRESS'):
                retryFailMsg = 'exceeded import IICS object retry attempts and this object is still in "in-progress" state'
                iics.log(text=fileCount + ':: error code:  ' + retryFailMsg)
                fail(iics, retryFailMsg)    
        else:
            iics.log(text=fileCount + ':: response: ' + json.dumps(importJobResponseJson))
    else:
        iics.log(text=fileCount + ':: error code: ' + str(importJobResponse.status_code) + '. error details: ' + importJobResponse.text)
        fail(iics, 'An error occurred while importing IICS package')
        
    archiveFile(iics, zipFilePath, archiveDirectoryPath, fileTimestamp)
    
def archiveFile(iics, filePath, archiveDirectoryPath, fileTimestamp):
    filePathList = filePath.split('\\')[-4:]
    filePathList[1] = filePathList[1] + '_' + fileTimestamp
    directoryPath = checkAndCreateDirectory(iics, archiveDirectoryPath, filePathList[0:3])
    newArchiveFilePath = os.path.join(directoryPath, filePathList[-1])
    os.rename(filePath, newArchiveFilePath)
    iics.log(text='File has been moved to archive directory path: ' + newArchiveFilePath)

def importPackageToIICS(I, commitid):
    env = I.env
    metadataFileName = 'exportMetadata.v2.json'
    requestFormat = '{ "importSpecification" : { "defaultConflictResolution" : "REUSE", "includeObjects" : [{1}], "objectSpecification" : [{ "sourceObjectId" : {0}, "conflictResolution" : "OVERWRITE" }] }}'
    userParameterType = 'userparameter'
    scripts_customType = 'scripts_custom'

    print('commit id: ' + commitid)

    dfsInfaPath = I.scriptConfig[env]['dsfserverpath']+'\\'+I.scriptConfig[env]['dfsinfa']
    importPackagePath = dfsInfaPath+'\\'+I.scriptConfig[env]['importpackagepath']
    logPath = importPackagePath+'\\'+I.scriptConfig[env]['logpath']
    archiveDirectoryPath = importPackagePath+'\\'+I.scriptConfig[env]['archivepath']

    fileTimestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
    wait_in_seconds = int(I.scriptConfig['waitseconds'])
    retry = int(I.scriptConfig['retrycount'])
    directorySortOrder = I.scriptConfig['directorysortorder']
    emailNotificationLabel = I.scriptConfig['emailnotificationlabel']
    scriptscustomfileextensions = I.scriptConfig['scriptscustomfileextensions']

    try:
        for directoryName in getDirectoryNames(importPackagePath):
            emailAddresses = []
            for commitDirectory in getDirectoryNames(os.path.join(importPackagePath, directoryName)):
                if commitDirectory.lower() == commitid.lower():
                    commitDirectoryPath = os.path.join(importPackagePath, directoryName, commitDirectory)
                    
                    I.log(taskName=commitDirectory, directory=os.path.join(logPath, directoryName))
                    fileCount = 0
                    deployedFileNames = []
                    secureAgentFiles = []
                    unknownFileTypes=[]
                    for assetTypeDirectory in getAssetTypeDirectories(commitDirectoryPath, directorySortOrder):
                        fileNameList = getFileNames(os.path.join(commitDirectoryPath, assetTypeDirectory))
                        
                        if len(fileNameList) == 0:
                            I.log(text="Commit id '" + commitDirectory + "' has no file to import")
                            continue

                        # read email address of requested person 
                        if len(emailAddresses) == 0:
                            for fileName in fileNameList:
                                if fileName.endswith('.txt'):
                                    textfilepath = os.path.join(commitDirectoryPath, assetTypeDirectory, fileName)
                                    emailAddress = getEmailAddress(I, textfilepath, emailNotificationLabel)
                                    if emailAddress is not None:
                                        emailAddresses.append(emailAddress)
                                        I.log(text='Send email notification to: '+emailAddress)
                                        break
    
                        if assetTypeDirectory != userParameterType and assetTypeDirectory != scripts_customType:
                            for fileName in fileNameList:
                                filePath = os.path.join(commitDirectoryPath, assetTypeDirectory, fileName)
                                if fileName.endswith('.zip'):
                                    I.log(text='\nFile Name: ' + fileName)
                                    
                                    fileCount = fileCount + 1
                                    with open(filePath, 'rb') as fileObject:
                                        files = {'package': (fileName, fileObject)}
                                        data = MultipartEncoder(files, boundary='------------------------acebdf13572468')
                                        I.log(text=str(fileCount) + ':: started uploading package:')
                                        uploadPackageResponse = I.uploadImportPackage(data)
                                    
                                    if uploadPackageResponse.status_code == 200:
                                        jobId = uploadPackageResponse.json()['jobId']
                                        
                                        I.log(text=str(fileCount) + ':: package uploaded successfully with Job Id: ' + jobId)

                                        importZipFile = zipfile.ZipFile(filePath)
                                        metadataJsonObject = {}
                                        for name in importZipFile.namelist():
                                            if name == metadataFileName:
                                                metadataJsonObject = json.loads(importZipFile.read(name))
                                                importZipFile.close()
                                                break

                                        assetName = ""
                                        projectName = ""
                                        for eachAsset in metadataJsonObject['exportedObjects']:
                                            
                                            if len(assetName) == 0 and eachAsset['objectName'] == fileName[:-4]:
                                                # get the current asset name
                                                assetName = '"' + eachAsset['objectGuid'] +  '"'
                                                # get the project name
                                                projectName = str(eachAsset['path']).lower().replace('/explore/', '').split('/')[0]
                                            
                                        dependentObjectIds = ""
                                        for eachAsset in metadataJsonObject['exportedObjects']:
                                            # get all dependent asset object ids
                                            if str(eachAsset['path']).lower().find('/' + projectName.lower()) != -1:
                                                if len(dependentObjectIds) > 0:
                                                    dependentObjectIds = dependentObjectIds + ','

                                                dependentObjectIds = dependentObjectIds + '"' + eachAsset['objectGuid'] + '"'
                                            else:
                                                I.log(text='This dependent object must not be imported. current project name: ' + projectName + '. Dependent asset name: ' + eachAsset['objectName'] + '. asset type: ' + eachAsset['objectType'] + '. asset path: ' + eachAsset['path'])

                                        postObject = requestFormat.replace('{0}', assetName).replace('{1}', dependentObjectIds).replace('{2}', projectName)
                                        
                                        startImportPackageJob(str(fileCount), I, jobId, postObject, fileTimestamp, archiveDirectoryPath, filePath, wait_in_seconds, retry)
                                        deployedFileNames.append(directoryName + '/' + assetTypeDirectory + '/' + fileName)
                                    else:
                                        I.log(text=str(fileCount) + ':: error while uploading package, response: ' + json.dumps(uploadPackageResponse.text))
                                        failWhenExceptionOccur(I, emailAddresses)
                                else:
                                    try:
                                        os.remove(filePath)
                                    except Exception as fileRemoveException:
                                        I.log(text=str(fileCount) + ':: an exception occured while removing .txt file. Exception details: ' + str(fileRemoveException))

                        elif assetTypeDirectory == userParameterType:
                            for paramFileName in fileNameList:
                                filePath = os.path.join(commitDirectoryPath, assetTypeDirectory, paramFileName)
                                if paramFileName.lower().endswith('.param'):
                                    destinationIICSAgentPath = getUserParameterFilePath(I.scriptConfig, env, directoryName.lower(), paramFileName)
                                    deployFileToSecureAgentAndArchive(I, filePath, destinationIICSAgentPath, archiveDirectoryPath, paramFileName, fileTimestamp)
                                    secureAgentFiles.append(paramFileName)
                                elif paramFileName.lower().endswith('.txt'):
                                    removeTxtFile(I, filePath)
                                else:
                                    I.log(text="File '" +paramFileName+ "' type is not supported inside '"+userParameterType+"' directory, hence ignoring it.")
                                    unknownFileTypes.append(paramFileName)

                        elif assetTypeDirectory == scripts_customType:
                            for customFileName in fileNameList:
                                filePath = os.path.join(commitDirectoryPath, assetTypeDirectory, customFileName)
                                if customFileName.lower().split('.')[-1] in scriptscustomfileextensions:
                                    destinationIICSAgentPath = getScriptsCustomFilePath(I.scriptConfig, env, directoryName.lower(), customFileName)
                                    deployFileToSecureAgentAndArchive(I, filePath, destinationIICSAgentPath, archiveDirectoryPath, customFileName, fileTimestamp)
                                    secureAgentFiles.append(customFileName)
                                elif customFileName.lower().endswith('.txt'):
                                    removeTxtFile(I, filePath)
                                else:
                                    I.log(text="File '" +customFileName+ "' type is not supported inside '"+scripts_customType+"' directory, hence ignoring it.")
                                    unknownFileTypes.append(customFileName)
                        else:
                            for unknownTypeFileName in fileNameList:
                                unknownFileTypes.append(unknownTypeFileName)

                    # send success email notification
                    if len(emailAddresses) != 0:
                        subject = 'IICS ' + env.upper() + ' Deployment | Success'
                        body = ''
                        if len(deployedFileNames) > 0:
                            body = 'Requested packages have been deployed successfully to IICS ' + env.upper() + '. \r\n ' + 'Following are the deployed file(s): ' + ' \r\n\t ' + ' \r\n\t '.join(deployedFileNames)
                        
                        if len(secureAgentFiles) > 0:
                            body = body + ' \r\n \r\n' + 'Requested custom scripts/user parameters have been deployed to IICS ' + env.upper() + ' Secure Agent. \r\n Following are the deployed custom scritps/user parameters: \r\n\t' + ' \r\n\t'.join(secureAgentFiles)

                        if len(unknownFileTypes) > 0:
                            body = body + ' \r\n \r\n' + 'Following are the ignored files: \r\n\t' + ' \r\n\t'.join(unknownFileTypes)

                        if len(body) == 0:
                            body = 'There are no IICS assets or custom scripts/user parameters files changes to deploy.'

                        sendEmail(I, emailAddresses, subject, body, isSuccess=True)
                        
                    removeEmptySubDirectoryies(I, commitDirectoryPath)
                    removeEmptySubDirectoryies(I, os.path.join(importPackagePath, directoryName))
                    break
    except Exception as runtimeEx:
        I.log(text='Exception occured: ' + str(runtimeEx))
        failWhenExceptionOccur(I, emailAddresses)
        raise Exception(runtimeEx)

def removeTxtFile(I, filePath):
    try:
        os.remove(filePath)
    except Exception as fileRemoveException:
        I.log(text="An exception occured while removing .txt file path '"+str(filePath)+"'. Exception details: " + str(fileRemoveException))
    

def deployFileToSecureAgentAndArchive(I, filePath, destinationIICSAgentPath, archiveDirectoryPath, fileName, fileTimestamp):
    I.log(text='started processing file: ' + fileName)
    shutil.copyfile(filePath, destinationIICSAgentPath)
    I.log(text='File has been deployed to IICS secure agent path: ' + str(destinationIICSAgentPath))
    archiveFile(I, filePath, archiveDirectoryPath, fileTimestamp)
    I.log(text="File '" + fileName + "' has been archived")

# main thread
if __name__ == "__main__":
    print('Running...')
    
    commitid = sys.argv[1]
    
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(baseName=os.path.basename(__file__)[:-3], taskName='')
    extraLogFilePath = str(sessionContainer['iics'].logFileName)

    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as fileRemoveException:
        print("couldn't able to delete extra log file: "+extraLogFilePath)

    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:    
            importPackageToIICS(sessionContainer['iics'], commitid)
            print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e, email=False) # email is already handled by Azure DevOps pipeline

