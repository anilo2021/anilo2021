####################################################################################################
# Name:                 automct.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/iics/automct.vsdx
# Command line usage:   python start.py filecopy <headerFile>
# Purpose:              High-level module for IICS Automation Python script
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2018-08-16 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
import csv
import os
import sys
# local module imports
from iics.iicssession import iicsSession
from iics.getmctjson import getMctJson
from iics.generatemct import generateMct

# function to generate mapping tasks based on CSV definition and JSON example
def autoMct(session, headerFile):
    # load specified CSV from headerFiles (mandate .csv extension)
    session.log(text='Opening '+headerFile)
    headers = csv.reader(open(session.directory/'headerFiles'/headerFile))
    _ = next(headers) # discard column names
    # for each header, download fresh JSON template and match with CSV definition
    for row in headers:
        session.log(text='\nRow '+row[0]+' of header file '+headerFile)
        # download JSON template
        getMctJson(session, taskName=row[1], fileName=row[2])
        # generate MCTs based on CSV definitions and JSON templates
        generateMct(session, 
            csvFile=row[3],
            jsonFile=row[2],
            taskPrefix=row[4],
            taskDesc=row[5])

# main thread
if __name__ == "__main__":
    print('Running...')
    # deal with existence of ".csv" in header file argument
    if sys.argv[1].split('.')[-1] != 'csv':
        taskName=sys.argv[1]
        headerFile = sys.argv[1].split('.')[0]+'.csv'
    else:
        taskName=headerFile[:-4]
    sessionContainer = {}
    sessionContainer['iics'] = iicsSession(os.path.basename(__file__)[:-3], taskName=headerFile) # remove ".py" from script name
    try:
        if not sessionContainer['iics'].login():
            print('Login error - aborted')
        else:
            # handle command line arg
            autoMct(sessionContainer['iics'], headerFile)
            sessionContainer['iics'].logout()
            print('Script execution complete')
    except Exception as e:
        sessionContainer['iics'].iicsError(e)