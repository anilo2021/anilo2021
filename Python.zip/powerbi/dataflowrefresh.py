####################################################################################################
# Name:                 dataflowrefresh.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/powerbi/dataflowrefresh.vsdx
# Command line usage:   python start.py dataflowrefresh <groupName> <dataflowName> <timeout> <period> <recipients>
# Purpose:              Refreshes a Power BI dataflow within a given group (workspace), checking status
#                       until a timeout, using a given period as a polling interval
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2020-10-05 Sanju Joseph (sanj827@kellyservices.com)       Original Author
# 2021-08-04 H. Maddipati (harm344@kellyservices.com)       Feature- Auto refresh dataflow upon failure based on config
####################################################################################################

# library imports
import datetime
from dateutil.tz import tzlocal
import json
import multiprocessing
from pathlib import Path
import sys
import time

# local imports
from powerbi.powerbisession import powerBiSession

# function to check transaction start time against provided time
def isOldTransaction(session, monitorStartTime, transaction, resumed): 
    transactionStartTime = datetime.datetime.strptime(transaction['id'].split('.')[0], '%Y-%m-%dT%H:%M:%S').replace(tzinfo=datetime.timezone.utc)
    session.log(text='Checking if old transaction:\n\tProvided start time is...    '+str(monitorStartTime)+'\n\tTransaction start time is... '+str(transactionStartTime))
    return True if (not resumed) and transactionStartTime < monitorStartTime else False

# monitors taskflow status until complete, with specified interval, and returns success status
def refreshMonitorStatus(session, groupId, dataflowId, startTime, timeoutProcess, period, resumed=False):
    session.log(text='Monitoring refresh and checking every '+str(period/60)+' minutes')
    # loop as long as timeout process has not finished
    success = False # default to failure
    transactionMissingCounter = 0
    errorCounter = 0
    transactionId = None
    while timeoutProcess.is_alive():
        try:
            # if no transaction ID yet, wait until it is retrieved, then record it and monitor the refresh
            if transactionId is None:
                session.log(text='Checking dataflow transaction list for a new transaction...')
                # get list of transactions associated with provided dataflow
                transactionResponseJson = session.dataflowTransactionsGroupGet(groupId, dataflowId) # separate variable for error catching
                transationList = transactionResponseJson['value']
                session.createJsonFile('json/'+session.logFileName.stem+'_TransactionList.json', transationList)
                transaction = transationList[0]
                # grab the refresh from the history response
                # NOTE: try-except block for capturing bad API response
                try:
                    if len(transationList) == 0 or isOldTransaction(session, startTime, transaction, resumed):
                        # if not in transaction history immediately, give a bit to show up because Microsoft
                        if transactionMissingCounter < session.scriptConfig['missingCounterLimit']:
                            transactionMissingCounter += 1
                            session.log('Script-initiated transaction not found - waiting for service to catch up...')
                            session.timer(period)
                        else:
                            raise ValueError('Script-initiated transaction not found! Terminating script...')
                    else:
                       transactionId = transaction['id']
                # if the API response is bad in the expected way, note this and fail script
                except ValueError as e:
                    if str(e).startswith(session.scriptConfig['timeDataExceptionPrefix']):
                        session.log(text='Transaction ID error from API detected - capturing to JSON file...')
                        session.createJsonFile('json/'+session.logFileName.stem+'_timeDataError_errorCounter_'+str(errorCounter)+'.json', transactionResponseJson)
                    raise e
            # once transaction ID has been found, monitor refresh
            else:
                # handle returned status if finished, otherwise wait before checking again
                session.log(text='Checking refresh status for request '+str(transactionId))
                # Get details of the current refresh
                transDetailResponse = session.dataflowTransactionsDetailGroupGet(groupId, transaction['id']) 
                session.createJsonFile('json/'+session.logFileName.stem+'TransactionDetails.json', transDetailResponse)
                # Check if transactions details are returned
                if 'state' not in transDetailResponse:
                    session.log(text='Request unfinished: Wait for transaction details to be returned. Retrying in '+str(period/60)+' minute(s)')
                    session.timer(period)
                else:
                    session.log(text='Transaction Status: '+transDetailResponse['state'])
                    # Check refresh status
                    if transDetailResponse['state'] == 'success':
                        success = True # indicated success
                        break
                    elif transDetailResponse['state'] == 'failure':
                        # extract and report error details
                        failedReasonJson = transDetailResponse['exceptionData']
                        progressFailedMessage = transDetailResponse['progressInformation'][0]['progressDetail']['nodes'][0]['exceptionData']['message']
                        if not resumed:
                            session.log(text='Dataflow failed due to error details: \n'+progressFailedMessage+'\n Exception: '+json.dumps(failedReasonJson)+'\nTerminating script...')
                        else:
                            session.log(text='Resumed dataflow failed due to error details: \n'+progressFailedMessage+'\n Exception: '+json.dumps(failedReasonJson)+'\nTerminating script...')
                        break
                    else:
                        session.log(text='Request unfinished, waiting '+str(period/60)+' minutes before retrying...')
                        session.timer(period)
        # handle general exceptions with redundancy   
        except Exception as e:
            # handle if error limit not yet reached
            if errorCounter < session.scriptConfig['errorCounterLimit']:
                errorCounter += 1
                session.error(e, exit=False)
                session.log('Exception handled. Attempting to resume monitoring in '+str(period/60)+' minute(s)..')
                session.timer(period) 
            # fail if limit exceeded
            else:
                raise e
    return success

# function to handle case where dataflow refresh is already in progress
def refreshRequestCheck(session, groupId, dataflowId, timeoutProcess, period):
    # get list of transactions associated with provided dataflow
    transactions = session.dataflowTransactionsGroupGet(groupId, dataflowId)['value']
    # check if refresh of this dataflow is already in progress
    refreshesInProgress = [t for t in transactions if t['status'] == 'InProgress' and 'refreshType' in t]
    if len(refreshesInProgress) != 0:
        # execute monitoring with requestId
        refreshMonitorStatus(session, groupId, dataflowId, 'RESUMED TASK', timeoutProcess, period, resumed=True)
        session.log('Previous transaction completed. Beginning intended refresh...')
    # get current timestamp
    monitorStartTime = datetime.datetime.now(tzlocal()).replace(microsecond=0)
    # start the dataset refresh
    session.log('Executing refresh on dataflow with ID '+dataflowId+' within group with ID '+groupId)
    body = {
        'notifyOption': session.scriptConfig['notifyOption']
    }
    refreshResponse = session.dataFlowRefreshStart(groupId, dataflowId, body)
    if '"error"' in str(refreshResponse.content):
        raise ValueError(refreshResponse.json()['error']['message'])
    else:
        #requestId = refreshResponse.headers['RequestId']
        return refreshMonitorStatus(session, groupId, dataflowId, monitorStartTime, timeoutProcess, period)

# main script logic
def dataflowRefresh(session, groupName, dataflowName, timeoutProcess, period=60):
    # acquire group by name
    retryCounter = 1
    retryLimit = session.scriptConfig['retryCounter'] if session.scriptConfig['retryEnabled'] else 1
    warningSent = False
    # wrap GET Workspaces in retry logic - TEMP
    while retryCounter <= retryLimit:
        session.log(text='INFO : GET Workspaces attempt '+str(retryCounter)+'/'+str(retryLimit))
        success = False
        groupsResponseJson = {'oops': 'no JSON response captured'} # default value placed in scope above try-catch
        try:
            groupsResponseJson = session.groupsGet()
            groupsList = groupsResponseJson['value']
            success = True
        except Exception as e:
            session.createJsonFile('json/'+session.logFileName.stem+'_GetWorkspaceKeyError_'+str(retryCounter), groupsResponseJson)
            if retryCounter == retryLimit:
                raise e
            else:
                session.error(e, exit=False)
                if not warningSent:
                    session.powerBiEmail(
                        body='GET Workspaces API return failed! Please see log file for JSON file path, and follow up with Power BI Support case to diagnose.',
                        color='yellow',
                        recipients=session.scriptConfig['emailRecipients']['error']
                    )
                    warningSent = True
                session.timer(period) # wait period before retrying 
        if success:
            break
        retryCounter+=1

    # check both provided name and name with spaces
    groupIds = [g['id'] for g in groupsList if g['name'] == groupName]
    # if no groups are found, the name is wrong
    if len(groupIds) != 1:
        raise ValueError('Group '+groupName+' not found! Terminating script...')
    # if exactly one group is found, continue as normal
    else:
        groupId = groupIds[0]
        session.log(text='Group '+groupName+' resolved to ID '+str(groupId))
        # acquire dataset by name
        dataflowsResponse = session.dataflowsGroupGet(groupId)
        dataflowsList = dataflowsResponse['value']
        # check both provided name and name with spaces
        dataflowIds = [d['objectId'] for d in dataflowsList if d['name'] == dataflowName]
        # if no datasets are found, the name is wrong
        if len(dataflowIds) != 1:
            raise ValueError('Dataflow '+dataflowName+' not found in group '+groupName+'! Terminating script...')
        # if exactly one dataset is found, continue as normal
        else:
            dataflowId = dataflowIds[0]
            retryCounter= 1
            retryLimit = session.scriptConfig['retryCounter'] if session.scriptConfig['retryEnabled'] else 1 
            session.log(text='Dataset '+dataflowName+' in group '+groupName+' resolved to ID '+str(dataflowId))
            # start monitoring dataflow refresh status
            while retryCounter <= retryLimit:
                session.log(text='INFO : Refresh attempt '+str(retryCounter)+'/'+str(retryLimit))
                success = refreshRequestCheck(session, groupId, dataflowId, timeoutProcess, period)
                # handle success or failure
                if success:
                    session.log(text='Refresh completed successfully.')
                    break
                else:
                    if retryCounter==retryLimit:
                        session.log(text='WARN: Max retry limit reached. Exiting..')   
                        raise ValueError("Refresh Failed")
                    else:
                        session.log(text='Refresh failed!, Retrying...')
                retryCounter+=1
        # kill timeout if running
        if timeoutProcess.is_alive():
            session.log(text='Timeout process terminated')
            timeoutProcess.terminate()

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['powerbi'] = powerBiSession(Path(__file__).stem, taskName=('_'.join(sys.argv[1:3])).replace(' ', '_'))
    try:
        loginPrincipal = {
            'type': 'ServicePrincipal',
            'label': 'ACE'
        }
        if not sessionContainer['powerbi'].login(loginPrincipal):
            sessionContainer['powerbi'].log(text='Login error - aborted')
        else:
            # set timeout as secondary thread using second argument
            timeoutLimit = 300 if int(sys.argv[3]) < 5 else int(sys.argv[3])*60 # at least 5 minutes
            timeoutProcess = multiprocessing.Process(target=sessionContainer['powerbi'].timer, args=[timeoutLimit])
            timeoutProcess.start()
            # handle command line args
            period = 60 if int(sys.argv[4]) < 1 else int(sys.argv[4])*60 # at least one minute]
            sessionContainer['powerbi'].log(text='Dataflow refresh started from group '+sys.argv[1])
            dataflowRefresh(sessionContainer['powerbi'], sys.argv[1], sys.argv[2], timeoutProcess, period)
            sessionContainer['powerbi'].logout()
            sessionContainer['powerbi'].log(text='Script execution complete')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        sessionContainer['powerbi'].logout() # kills loginTimeoutProcess
        sessionContainer['powerbi'].powerBiError(e, email=sessionContainer['powerbi'].scriptConfig['errorNotification'])