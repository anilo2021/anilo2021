####################################################################################################
# Name:                 pipelineassignadmin.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/powerbi/pipelineassignadmin.vsdx
# Command line usage:   python start.py pipelineassignadmin
# Purpose:              TESTING SCRIPT ONLY - Searches all PBI Pipelines and assigns PBI Admin as Admin to any that do not have it
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2022-03-18 Jesse Rominske (jesr114@kellyservices.com)    Original Author
####################################################################################################

# library imports
import json
from pathlib import Path
import sys

# local imports
from powerbi.powerbisession import powerBiSession


# main script logic
def pipelineAssignAdmin(session, adminGroup):
    # get all pipelines (as admin)
    if not Path(session.directory/'json'/'pipelines.json').exists():
        print('get')
        pipelines = session.pipelinesGetAsAdmin(expand='stages,users')['value']
        session.createJsonFile('json/pipelines.json', pipelines)
    else:
        print('load')
        pipelines = json.load(open(Path(session.directory/'json'/'pipelines.json')))
    
    #session.createJsonFile('json/'+session.logFileName.stem+'_pipelines.json', pipelines)
    # for each pipeline
    for pipeline in pipelines:
        # extract stages (remove later after testing)
        # get users
        adminGroupFound=False
        for user in pipeline['users']:
        # if users does not contain specified admin group, add it
            if user['identifier'] == session.scriptConfig['adminGroup'][adminGroup]:
                adminGroupFound=True
                break
        if adminGroupFound:
            continue
        else:
            session.log(text='Assigning admin group '+adminGroup+' to pipeline '+pipeline['displayName'])
            input('paused')
            updateResponse = session.pipelineUsersUpdateAsAdmin(
                pipelineId=pipeline['id'],
                body={
                    'identifier': session.scriptConfig['adminGroup'][adminGroup],
                    'principalType': 'Group',
                    'accessRight': 'Admin'
                }
            )
            if updateResponse.status_code == 200:
                session.log(text='Admin group assigned')
            else:
                session.log(text=str(updateResponse))
    return

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['powerbi'] = powerBiSession(Path(__file__).stem, taskName=sys.argv[1])
    try:
        loginPrincipal = {
            'type': 'ServicePrincipal',
            'label': 'Monitoring'
        }
        if not sessionContainer['powerbi'].login(loginPrincipal):
            sessionContainer['powerbi'].log(text='Login error - aborted')
        else:
            pipelineAssignAdmin(session=sessionContainer['powerbi'], adminGroup=sys.argv[1])
            sessionContainer['powerbi'].logout()
            sessionContainer['powerbi'].log(text='Script execution complete')
    except Exception as e:
        sessionContainer['powerbi'].logout() # kills loginTimeoutProcess
        sessionContainer['powerbi'].powerBiError(e, email=sessionContainer['powerbi'].scriptConfig['errorNotification'])