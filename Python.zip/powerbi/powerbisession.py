####################################################################################################
# Name:                 powerbisession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/36/powerbisession
# Command line usage:   N/A
# Purpose:              Class contains methods for Power BI API automation
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-10-28 J. Rominske (jesr114@kellyservices.com)      Original Author
# 2020-10-05 Sanju Joseph (sanj827@kellyservices.com)     added dataflow related methods
# 2021-03-30 Jesse Rominske (jesr114@kellyservices.com)   Updated Group-related methods
####################################################################################################

# library imports
from copy import deepcopy as deepCopy
from json import load as jsonLoad
from multiprocessing import Process as multiProcess
from pathlib import Path
from re import findall as regexFindall
from requests import Session as reqSession
from sqlalchemy import create_engine as createDbEngine
from sys import exit as sysExit
# local module imports
from common.session import session

# session subclass with methods relevant to IICS Automation
class powerBiSession(session):
    # overloaded setup method
    def _setup(self):
        self.directory = self.repoDirectory/'powerbi'
        # load session-level config
        self.config = jsonLoad(open(self.configDirectory/(self.env+'_powerbiconfig.json')))
        # load stored credentials from JSON file
        self.azureCreds = jsonLoad(open(self.secureDirectory/(self.env+'_azurecreds.json')))
        self.pbiCreds = jsonLoad(open(self.secureDirectory/(self.env+'_pbicreds.json')))
        # session variables for IICS API interface
        self.resourceUrl = 'https://analysis.windows.net/powerbi/api' # resource URL for the Power BI REST API
        self.serverUrl = 'https://api.powerbi.com/' # API version is controlled within the methods
        self.loginUrl = 'https://login.microsoftonline.com/{}/oauth2/token'.format(self.azureCreds['tenantId'])
        self.basehdrs = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        self.req = reqSession()
    
    # method for logging into Azure Portal
    def login(self, principal=None):
        # set session-level login principal for refresh
        if principal is None:
            self.loginPrincipal = {
                'type': 'ServicePrincipal',
                'label': 'ACE'
            }
        else:
            self.loginPrincipal = principal
        creds = self.azureCreds[self.loginPrincipal['type']][self.loginPrincipal['label']+'_'+self.env]
        self.hdrs =  self.basehdrs.copy() # reset headers on each login
        # option to authenticate with service principal (PREFERRED)
        # https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-client-creds-grant-flow#get-a-token
        if principal['type'] == 'ServicePrincipal':
            loginData = {
                'grant_type': 'client_credentials',
                'client_id': creds['clientId'],
                'client_secret': creds['clientSecret'],
                'resource': self.resourceUrl
            }
            self.log(text='Logging in as serivce pricipal with ID '+creds['clientId']+'...')
        # option to log in with user
        # https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth-ropc
        elif principal['type'] == 'UserAccount':
            loginData = {
                'grant_type': 'password',
                'client_id': creds['clientId'],
                'client_secret': creds['clientSecret'],
                'username': creds['username'],
                'password': creds['password'],
                'resource': self.resourceUrl
            }
            self.log(text='Logging in as '+creds['username']+'...')
        response = self.req.post(self.loginUrl, headers=self.hdrs, data=loginData)
        if response.status_code == 200 : 
            self.log(text='Login Success')
            # add token to headers
            self.hdrs['Authorization'] = "Bearer "+response.json()['access_token']
            self.hdrs['Content-Type'] = 'application/json; charset=utf-8'
            # initiate timeout subprocess
            loginTimeoutLimit = self.scriptConfig['loginTimeout']*60 # config value is in minutes
            self.loginTimeoutProcess = multiProcess(target=self.timer, args=[loginTimeoutLimit])
            self.loginTimeoutProcess.start()
            return True
        else:
            self.log(text='Login Failed')
            self.log(text=response.text)
            return False

    def logout(self):
    # kill login timeout if running
        if self.loginTimeoutProcess.is_alive():
            self.log(text='Login timeout process terminated')
            self.loginTimeoutProcess.terminate()
        return

    # logs user in and adds an authenticated session id to header (SQLAlchemy login)           
    def dbLogin(self, connName):
        self.log(text='Logging into '+connName+' via SQLAlchemy...')
        creds = self.pbiCreds['Database'][connName]
        # retry as configured
        succeeded = False
        loginConfig = self.config['dbLogin']
        retryCount = 0
        while not succeeded:
            try:
                # switch object structure based on given dbType
                if creds['dbType'] == 'Microsoft':
                    if 'dsn' in creds:
                        engine = createDbEngine(
                            'mssql+pyodbc://{user}:{password}@{dsn}'.format(
                                user=creds['userId'],
                                password=creds['passwd'],
                                dsn=creds['dsn']))
                    else:
                        engine = createDbEngine(
                            'mssql+pyodbc://{user}:{password}@{server}/{dbName}?driver={driver}'.format(
                                user=creds['userId'],
                                password=creds['passwd'],
                                server=creds['server'],
                                dbName=creds['dbName'],
                                driver=creds['driver'].replace(' ', '+')))
                elif creds['dbType'] == 'Teradata':
                    engine = createDbEngine(
                        'teradatasql://{user}:{password}@{dbcName}'.format(
                            user=creds['userId'],
                            password=creds['passwd'],
                            dbcName=creds['dbName']))
                elif creds['dbType'] == 'Oracle':
                    engine = createDbEngine(
                        'oracle+cx_oracle://{user}:{password}@{dbq}'.format(
                            user=creds['userId'],
                            password=creds['passwd'],
                            dbq=creds['dbq']))
                elif creds['dbType'] == 'Snowflake':
                    engine = createDbEngine(
                        'snowflake://{user}:{password}@{account}'.format(
                            user=creds['userId'],
                            password=creds['passwd'],
                            account=creds['dbName']))
                succeeded = True
                self.log(text='Login Success')
            except Exception as e:
                retryCount += 1
                # if still within retryMax, log error, wait, and continue
                if retryCount <= loginConfig['retryMax']:
                    self.error(e, exit=False)
                    self.log(text='Login failure! Retrying in '+str(loginConfig['retryWait'])+' seconds...')
                    self.timer(loginConfig['retryWait'])
                # if retryMax reached, simply raise error again for default error handling
                else:
                    raise e
        # if main session login, store connection, cursor in session instance
        if connName == 'DWAUDIT':
            self.engine = engine
            self.connection = self.engine.raw_connection()
            self.cursor = self.connection.cursor()
        # for normal login, return connection
        else:
            return engine

    # method to run query defined in a given file provided with appropriate params
    def executeSqlFile(self, fileName, cursor=None, params=(), commit=False):
        # use session cursor by default
        if not cursor:
            cursor = self.cursor
        # open file from sql directory and execute contents on cursor
        with open(self.directory/'sql'/fileName) as q:
            # fill in param markers with values, unpacking lists if needed
            query = q.read().format(*params) if isinstance(params, (list, tuple)) else q.read().format(params)
            try: 
                self.log(text='Executing SQL from '+fileName+':\n'+query+'\n')
                cursor.execute(query)
            except Exception as e:
                self.error(e)
        # commit to the db if specified
        if commit:
            cursor.commit()

    # method for sending emails specific to IICS
    def powerBiEmail(self, body, color, attachment=None, recipients=None):
        # by default, attach log file
        if attachment is None:
            attachment = self.logFileName
        # send email with generic method
        with open(self.secureDirectory/'config'/'emailTemplates'/'emailbody_powerbi.html') as template:
            self.email(body=template.read().format(body), # replace "{}" in template file with values
                       color=color,
                       attachment=attachment,
                       recipients=recipients) # call basic email function

    # method for send error report email for IICS
    def powerBiError(self, error, email=True):
        errorCode = self.error(error, exit=False)
        if email:
            self.log(text='Sending error notification email...')
            self.powerBiEmail(body='An error occurred with code: '+str(errorCode)+'<br>Please check the logs.',
                              color='red',
                              recipients=self.scriptConfig['emailRecipients']['error'])
        sysExit(errorCode)

    # generic method for using Azure resource methods
    def _doAPI(self, reqType, uri, apiVersion, jsonData={}, headers=None, paramDict=None):
        # preliminary check for login timeout
        if not self.loginTimeoutProcess.is_alive():
            self.log(text='\tLogin timeout expired. Refreshing authentication...')
            # reuse session-level login principal to refresh login
            if not self.login(self.loginPrincipal):
                raise ValueError('Login refresh failed!')
        #instantiate response for error-checking case
        response = None 
        try:
            if not headers:
                    headers = self.hdrs
            # prepare to access API resource
            url = self.serverUrl+apiVersion+'/'+uri
            # extract params from dict if provided
            if paramDict is not None and any([paramDict[p] for p in paramDict]):
                # parse paramDict into equality statements
                paramList = []
                for param in paramDict:
                    # append only if value of the param is not None
                    if paramDict[param] is not None:
                        paramList.append('$'+param+'='+str(paramDict[param]))
                # append params to URL
                url += '?'+('&'.join(paramList))
            # switch method use based on request type
            if reqType == 'GET':
                if paramDict is not None and 'top' in paramDict:
                    # GET initial groups list
                    self.log(text='\tAccessing API resource at '+url)
                    response = self.req.get(url, headers=headers)
                    # retrieve total number of groups
                    responseJson = response.json()
                    if '@odata.count' in responseJson:
                        totalCount = responseJson['@odata.count']
                        # if there are more groups to GET, loop until finished
                        if paramDict['top'] < totalCount:
                            # set aside the getList for future reassignment
                            getList = deepCopy(responseJson['value'])
                            url += '&$skip='
                            # pagination logic
                            while len(getList) < totalCount:
                                # append skip param to url
                                url = '='.join(url.split('=')[:-1])+'='+str(len(getList))
                                self.log(text='\tAccessing API resource at '+url)
                                response = self.req.get(url, headers=headers)
                                responseContentString = str(response.content)
                                # check if API wait time is initiated
                                if self.apiWaitTimeHandle(responseContentString):
                                    continue
                                responseJson = response.json()
                                getList = getList + deepCopy(responseJson['value'])
                            responseJson['value'] = getList
                else:
                    self.log(text='\tAccessing API resource at '+url)
                    response = self.req.get(url, headers=headers)
                    responseContentString = str(response.content)
                    # check if API wait time is initiated
                    if self.apiWaitTimeHandle(responseContentString):
                        self._doAPI(reqType, uri, apiVersion, jsonData=jsonData, headers=headers, paramDict=paramDict)
                    else:
                        responseJson = response.json()
                return responseJson
            # handle all types other than GET
            else:
                self.log(text='\tAccessing API resource at '+url)
                # perform POST request
                if reqType == 'POST':
                    return self.req.post(url, headers=headers, json=jsonData)
                # perform PATCH request
                elif reqType == 'PATCH':
                    return self.req.patch(url, headers=headers, json=jsonData)
                # perform PUT request
                elif reqType == 'PUT':
                    return self.req.put(url, headers=headers, json=jsonData)
                # perform DELETE request
                elif reqType == 'DELETE':
                    return self.req.delete(url, headers=headers)
        # if API call failed, make note of that specifically
        except Exception as e:
            # if the requestid is included in response headers, include it in error message
            if response is not None and response.status_code is not 200 and 'requestid' in response.headers:
                errorMessage = self.config['apiErrorMessage'].format(str(response))+' - Request ID: '+response.headers['requestid']
            elif response is not None and response.status_code is not 200:
                errorMessage = self.config['apiErrorMessage'].format(str(response))
            else:
                raise e
            raise ValueError(errorMessage)
    # method to handle wait times for stability
    def apiWaitTimeHandle(self, responseContentString):
        # if the API calls per hour is exceeded, wait until it allows calls again
        if 'requestAllowanceErrorMessage' in self.scriptConfig and self.scriptConfig['requestAllowanceErrorMessage'] in responseContentString:
            self.log(text='Number of requests per hour exceeded, executing wait time...')
            # get the number of seconds needed to wait for new API calls to be made
            waitTime = int(regexFindall(self.scriptConfig['requestAllowanceErrorFormat'], responseContentString)[0])
            # wait until API will allow request again
            self.timer(waitTime)
            return True
        else:
            return False

    # app methods
    # method to get an app in the org
    # https://docs.microsoft.com/en-us/rest/api/power-bi/apps/getapp
    def appGet(self, appId):
        return self._doAPI('GET', 'myorg/apps/'+appId, 'v1.0')
    # method to get all apps in the org
    # https://docs.microsoft.com/en-us/rest/api/power-bi/apps/getapps
    def appsGet(self):
        return self._doAPI('GET', 'myorg/apps', 'v1.0')
    # method to get all apps in the org as admin
    # https://docs.microsoft.com/en-us/rest/api/power-bi/admin/apps_getappsasadmin
    def appsGetAsAdmin(self, top, filter=None):
        return self._doAPI('GET', 'myorg/admin/apps', 'v1.0', paramDict={'top':top, 'filter':filter})
    # method to get reports in an app
    # https://docs.microsoft.com/en-us/rest/api/power-bi/apps/getreports
    def appReportsGet(self, appId):
        return self._doAPI('GET', 'myorg/apps/'+appId+'/reports', 'v1.0')
    # method to get all users in an app as admin
    # https://docs.microsoft.com/en-us/rest/api/power-bi/admin/apps_getappusersasadmin
    def appUsersGetAsAdmin(self, appId, top=None, filter=None):
        return self._doAPI('GET', 'myorg/admin/apps/'+appId+'/users', 'v1.0', paramDict={'top':top, 'filter':filter})

    # dataflows methods
    # method to get all dataflows in the group
    def dataflowsGroupGet(self, groupId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/dataflows', 'v1.0')
    # method to get all dataflows in the group as admin
    def dataflowsGroupGetAsAdmin(self, groupId, top):
        return self._doAPI('GET', 'myorg/admin/groups/'+groupId+'/dataflows', 'v1.0', paramDict={'top':top})
    # method to get dataset in group
    def dataflowGroupGet(self, groupId, dataflowId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/dataflows/'+dataflowId, 'v1.0')
    # method to refresh dataflow
    def dataFlowRefreshStart(self, groupId, dataflowId, body):
        return self._doAPI('POST', 'myorg/groups/'+groupId+'/dataflows/'+dataflowId+'/refreshes', 'v1.0', jsonData=body)
    # method to get dataflow's transaction list in group
    def dataflowTransactionsGroupGet(self, groupId, dataflowId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/dataflows/'+dataflowId+'/transactions', 'v1.0')
    # method to get dataflow in group
    def dataflowTransactionsDetailGroupGet(self, groupId, transactionId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/dataflows/transactions/'+transactionId, 'v1.0')
    
    # datasets methods
    # method to get all datasets in the org
    def datasetsGet(self):
        return self._doAPI('GET', 'myorg/datasets', 'v1.0')
    # method to get all datasets in the org as admin
    def datasetsGetAsAdmin(self, top):
        return self._doAPI('GET', 'myorg/admin/datasets', 'v1.0', paramDict={'top':top})
    # method to get all datasets in a group
    def datasetsGroupGet(self, groupId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/datasets', 'v1.0')
    # method to get all datasets in a group as admin
    def datasetsGroupGetAsAdmin(self, groupId, top):
        return self._doAPI('GET', 'myorg/admin/groups/'+groupId+'/datasets', 'v1.0', paramDict={'top':top})
    # method to get a dataset in the org
    def datasetGet(self, datasetId):
        return self._doAPI('GET', 'myorg/datasets/'+datasetId, 'v1.0')
    # method to get dataset in group
    def datasetGroupGet(self, groupId, datasetId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/datasets/'+datasetId, 'v1.0')
    # method to get history of dataset refreshes
    def datasetRefreshHistoryGet(self, datasetId):
        return self._doAPI('GET', 'myorg/datasets/'+datasetId+'/refreshes', 'v1.0')
    # method to get history of dataset refreshes
    def datasetRefreshHistoryGroupGet(self, groupId, datasetId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/datasets/'+datasetId+'/refreshes', 'v1.0')
    # method to refresh dataset
    def datasetRefreshStart(self, datasetId):
        return self._doAPI('POST', 'myorg/datasets/'+datasetId+'/refreshes', 'v1.0')
    # method to refresh dataset
    def datasetRefreshGroupStart(self, groupId, datasetId, body):
        return self._doAPI('POST', 'myorg/groups/'+groupId+'/datasets/'+datasetId+'/refreshes', 'v1.0', jsonData=body)
    
    # groups (workspaces) methods
    # method to get all groups in the org
    def groupsGet(self):
        return self._doAPI('GET', 'myorg/groups', 'v1.0')
    # method to get all groups in the org as admin
    def groupsGetAsAdmin(self, top, expand=None, filter=None):
        return self._doAPI('GET', 'myorg/admin/groups', 'v1.0', paramDict={'top':top, 'expand':expand, 'filter':filter})
    # method to get a workspace with given id
    def groupGet(self, groupId):
        return self._doAPI('GET', "myorg/groups?$filter=id eq '"+groupId+"'", 'v1.0')
    # method to get a workspace with given id as admin
    def groupGetAsAdmin(self, groupId):
        return self._doAPI('GET', "myorg/admin/groups?$filter=id eq '"+groupId+"'", 'v1.0')
    # method to get a workspace with given id
    def groupGetByName(self, groupName):
        return self._doAPI('GET', "myorg/groups?$filter=name eq '"+groupName+"'", 'v1.0')
    # method to get a workspace with given id as admin
    def groupGetByNameAsAdmin(self, groupName):
        return self._doAPI('GET', "myorg/admin/groups?$filter=name eq '"+groupName+"'", 'v1.0')
    # method to get a workspace with given id
    def groupUsersGet(self, groupId, top):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/users', 'v1.0', paramDict={'top':top})

    # admin-specific workspace methods
    # get workspaces modified since a certain time
    def workspaceModifiedGet(self, timestamp):
        return self._doAPI('GET', 'myorg/admin/workspaces/modified?modifiedSince='+timestamp, 'v1.0')
    # post workspace asset info for later retrieval
    def workspaceScanPost(self, body):
        return self._doAPI('POST', 'myorg/admin/workspaces/getInfo', 'v1.0', jsonData=body)
    # get current status of a workspace scan
    def workspaceScanStatusGet(self, scanId):
        return self._doAPI('GET', 'myorg/admin/workspaces/scanStatus/'+scanId, 'v1.0')
    # get results of a completed workspace scan
    def workspaceScanResultGet(self, scanId):
        return self._doAPI('GET', 'myorg/admin/workspaces/scanResult/'+scanId, 'v1.0')
    
    # reports methods
    # method to get all reports in the org
    def reportsGet(self, top):
        return self._doAPI('GET', 'myorg/reports', 'v1.0', paramDict={'top':top})
    # method to get all reports in the org as admin
    def reportsGetAsAdmin(self, top):
        return self._doAPI('GET', 'myorg/admin/reports', 'v1.0', paramDict={'top':top})
    # method to get all reports in a group
    def reportsGroupGet(self, groupId, top):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/reports', 'v1.0', paramDict={'top':top})
    # method to get all reports in a group as admin
    def reportsGroupGetAsAdmin(self, groupId, top):
        return self._doAPI('GET', 'myorg/admin/groups/'+groupId+'/reports', 'v1.0', paramDict={'top':top})
    # method to get a report in the org
    def reportGet(self, reportId):
        return self._doAPI('GET', 'myorg/datasets/'+reportId, 'v1.0')
    # method to get report in group
    def reportGroupGet(self, groupId, reportId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/reports/'+reportId, 'v1.0')
    # method to get report pages in group
    def reportPagesGroupGet(self, groupId, reportId):
        return self._doAPI('GET', 'myorg/groups/'+groupId+'/reports/'+reportId+'/pages', 'v1.0')

    # pipeline methods
    # method to get all pipelines in the org
    # https://docs.microsoft.com/en-us/rest/api/power-bi/pipelines/get-pipelines
    def pipelinesGet(self, top=None):
        return self._doAPI('GET', 'myorg/pipelines', 'v1.0', paramDict={'top':top})
    # method to get all pipelines in the org as admin
    # https://docs.microsoft.com/en-us/rest/api/power-bi/admin/pipelines-get-pipelines-as-admin
    def pipelinesGetAsAdmin(self, top=None, expand=None, filter=None):
        return self._doAPI('GET', 'myorg/admin/pipelines', 'v1.0', paramDict={'top':top, 'expand':expand, 'filter':filter})
    # method to get stages of a pipeline
    # https://docs.microsoft.com/en-us/rest/api/power-bi/pipelines/get-pipeline-stages
    def pipelineStageGet(self, pipelineId, top=None):
        return self._doAPI('GET', 'myorg/pipelines/'+pipelineId+'/stages', 'v1.0', paramDict={'top':top})
    # method to get users of a pipeline
    # https://docs.microsoft.com/en-us/rest/api/power-bi/pipelines/get-pipeline-users
    def pipelineUsersGet(self, pipelineId, top=None):
        return self._doAPI('GET', 'myorg/pipelines/'+pipelineId+'/users', 'v1.0', paramDict={'top':top})
    # method to get users of a pipeline as admin
    # https://docs.microsoft.com/en-us/rest/api/power-bi/admin/pipelines-get-pipeline-users-as-admin
    def pipelineUsersGetAsAdmin(self, pipelineId, top=None):
        return self._doAPI('GET', 'myorg/admin/pipelines/'+pipelineId+'/users', 'v1.0', paramDict={'top':top})
    # method to update users of a pipeline
    # https://docs.microsoft.com/en-us/rest/api/power-bi/pipelines/update-pipeline-user
    def pipelineUsersUpdate(self, pipelineId, body=None):
        return self._doAPI('POST', 'myorg/pipelines/'+pipelineId+'/users', 'v1.0', jsonData=body)
    # method to update users of a pipeline as admin
    # https://docs.microsoft.com/en-us/rest/api/power-bi/admin/pipelines-update-user-as-admin
    def pipelineUsersUpdateAsAdmin(self, pipelineId, body=None):
        return self._doAPI('POST', 'myorg/admin/pipelines/'+pipelineId+'/users', 'v1.0', jsonData=body)

    # tertiary methods
    # method to scan the details of the assets withing a workspace
    def workspacesScan(self, workspacesList, timeoutProcess, period):
        workspaceListChunked = self.chunkList(workspacesList['workspaces'], chunkSize=100)
        # iterate through each chunk of workspaces and return the full result
        workspaceScanResultJson = {
            'workspaces': []
        }
        for workspaceListChunk in workspaceListChunked:
            # format for GET request
            workspacesToScan = {
                'workspaces': workspaceListChunk
            }
            # initiate scan
            self.log(text='\tInitiating scan of chunk of workspaces...')
            scanPostResponseJson = self.workspaceScanPost(workspacesToScan).json()
            scanId = scanPostResponseJson['id']
            # poll scan until complete
            while timeoutProcess.is_alive():
                scanStatusResponseJson = self.workspaceScanStatusGet(scanId)
                self.log(text=str(scanStatusResponseJson))
                # end loop if status is Succeeded
                if 'status' not in scanStatusResponseJson:
                    raise ValueError(scanStatusResponseJson['error']['details'][0]['message'])
                else:
                    if scanStatusResponseJson['status'] not in ('Succeeded', 'Failed'):
                        self.log(text='Scan unfinished...')
                        self.timer(period, logging=True)
                        continue
                    else:
                        if scanStatusResponseJson['status'] == 'Succeeded':
                            self.log(text='Scan complete')
                            break
                        else:
                            self.log(text='Scan failed')
                            break
            # get scan results
            scanResultResponseJson = self.workspaceScanResultGet(scanId)
            workspaceScanResultJson['workspaces'] = workspaceScanResultJson['workspaces']+scanResultResponseJson['workspaces']
        return workspaceScanResultJson

        
# main method
if __name__ == '__main__': 
    print('Running...')
    # perform unit test
    try:
        P = powerBiSession(Path(__file__).stem, 'test') # remove ".py" from script name
        if not P.login():
            print('Login error - aborted')
        else:
            print('Script execution complete')
    except Exception as e:
        P.powerBiError(e)