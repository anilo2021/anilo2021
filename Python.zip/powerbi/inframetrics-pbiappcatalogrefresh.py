####################################################################################################
# Name:                 inframetrics-pbiappcatalogrefresh.py
# Python version:       Python 3.6.4
# Diagram path:         ACE/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/powerbi/inframetrics-pbiappcatalogrefresh.vsdx
# Command line usage:   python start.py inframetrics-pbiappcatalogrefresh
# Purpose:              Query DevOpsDb for Power BI apps and workspaces and export query results as Excel
#                       that is uploaded to SharePoint
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-06-15 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2022-11-17 H. Maddipati(harm344@kellyservices.com)       Dumps excel file into DevopsDb as sp_appCatalogDump
####################################################################################################

# library imports
import json
import pandas
from pathlib import Path
import openpyxl
import sys
# local module imports
from powerbi.powerbisession import powerBiSession
from fileops.fileopssession import fileopsSession
from mssharepoint.sharepointsession import sharepointSession

# function to determine workspace environment based on name prefix to enforce naming conventions
def workspaceEnvByPrefix(session, workspaceName):
    prefixEnvMap = session.scriptConfig['workspaceEnvSuffixMap']
    for prefix in prefixEnvMap:
        if prefix is not 'Default' and workspaceName.endswith(prefix):
            return prefixEnvMap[prefix]
    return prefixEnvMap['Default']

# function to load result of a SQL query into a Pandas dataframe
# NOTE: This was a method of powerbiSession but was removed due to some incompatibility with multiprocessing.Process()
def readSqlFileToDf(session, fileName, connection, params=()):
    # open file from sql directory and execute contents on cursor
    with open(session.directory/'sql'/fileName) as q:
        # fill in param markers with values, unpacking lists if needed
        query = q.read().format(*params) if isinstance(params, (list, tuple)) else q.read().format(params)
        try: 
            session.log(text='Executing SQL from '+fileName+':\n'+query+'\n')
            return pandas.read_sql_query(sql=query, con=connection)
        except Exception as e:
            session.error(e)

def pbiAppCatalogRefresh(session):
    # disable script run according to config
    if session['powerbi'].scriptConfig['disabled']:
        return False
    # establish admin DB engine for retrieval
    session['powerbi'].log(text='Establishing User connection to DevOpsDb...')
    devopsConn = session['powerbi'].dbLogin('aimInfra_admin')
    # open file from sql directory and read SQL query for Excel sheet
    appCatalogGetResult = readSqlFileToDf(
        session=session['powerbi'],
        fileName='appCatalogGet.sql', 
        connection=devopsConn
    )
    sharepointPath = session['powerbi'].scriptConfig['appCatalogSharepointPath']
    currentCatalogPath = session['mssharepoint'].fileDownload(sharepointPath) # defaults to 'download' subfolder
    # read Excel as dataframe for manipulation (dropping empty rows)
    currentCatalogDf = pandas.read_excel(currentCatalogPath, engine='openpyxl')
    currentCatalogDf.dropna(axis='index', how='all', inplace=True)
    currentCols = currentCatalogDf.columns
    
    # insert to DB for reporting on human-maintained properties
    session['powerbi'].log(text='\nInserting catalog into DevOpsDb as new table sp_appCatalogDump...\n')
    currentCatalogDf.to_sql(
        name='sp_appCatalogDump',
        con=devopsConn,
        schema=session['powerbi'].pbiCreds['Database']['aimInfra_admin']['schema'],
        if_exists='replace'
    )

    # extract users for the given app to concatenate into comma-separated string list
    session['powerbi'].log(text='Extracting App users...')
    appPrincipalsGetResult = readSqlFileToDf(
        session=session['powerbi'],
        fileName='appPrincipalsGet.sql',
        connection=devopsConn
    )
    # extract workspaces containing source datasets of the reports included in the given app to concatenate into comma-separated string list
    session['powerbi'].log(text='Extracting App source datasets...') 
    appDatasetsGetResult = readSqlFileToDf(
        session=session['powerbi'],
        fileName='appGetSourceDatasets.sql',
        connection=devopsConn
    )
    # process current dataframe and update data where necessary
    for _, row in appCatalogGetResult.iterrows(): # throw away index due to lack of use
        session['powerbi'].log(text='Processing database reuslts for App '+row['AppName']+' (ID '+row['Id']+')')
        # use slices based on AppId
        appPrincipalsGetSlice = appPrincipalsGetResult.loc[appPrincipalsGetResult['AppId'] == row['Id']]
        appDatasetsGetSlice = appDatasetsGetResult.loc[appDatasetsGetResult['AppId'] == row['Id']]
        # concatenate relevant columns into comma separated lists
        appPrincipalsListString = ', '.join(s for s in set(appPrincipalsGetSlice['DisplayName'].to_list()) if s is not None)
        datasetsString = '\n'.join(s for s in set(appDatasetsGetSlice['DatasetName'].to_list()) if s is not None)
        datasetsWorkspacesString = '\n'.join(s for s in set(appDatasetsGetSlice['DatasetWorkspaceName'].to_list()) if s is not None)
        # fill out map dict to handle possibly-changing spreadsheet column names
        # NOTE: contains only data the script can provide
        session['powerbi'].log(text='Mapping DB data to Excel columns...')
        rowData = {
            'AppId': row['Id'],
            'AppName': row['AppName'],
            'Environment': workspaceEnvByPrefix(session['powerbi'], row['WorkspaceName']), 
            'AppDescription': row['AppDescription'],
            'AppPublishedBy': row['PublishedByPrincipalId'],
            'AppPermissions': appPrincipalsListString,
            'CapcacityId': row['WorkspaceCapcacityId'],
            'WorkspaceId': row['WorkspaceId'],
            'WorkspaceName': row['WorkspaceName'],
            'DatasetSource': datasetsWorkspacesString,
            'DatasetNames': datasetsString,
            'AppPublished': 'Yes' if row['IsDeleted'] == 1 else 'No',
            'Decommissioned': row['IsDeleted']
        }
        excelMap = session['powerbi'].scriptConfig['excelSheetMap']
        # map rowData to excel column names based on contents of config file, empty string if not included in config
        mappedData = dict([(col, rowData[excelMap[col]]) for col in currentCols if col in excelMap])
        unmappedData = dict([(col, '') for col in currentCols if col not in excelMap])
        # NOTE: contains only data the config has listed
        newData = {**mappedData, **unmappedData}
        # if a row is found for the given AppId, fill out with DB info
        if row['Id'] in currentCatalogDf[session['powerbi'].scriptConfig['excelSheetIndex']].values:
            # populate row with updated DB data (ignoring columns not provided by DB)
            for colName in mappedData:
                currentCatalogDf.loc[currentCatalogDf['App ID'] == row['Id'], colName] = mappedData[colName]
        # if a row is not found, create a new entry
        else:
            currentCatalogDf = currentCatalogDf.append(newData, ignore_index=True)
    # soft dataframe for readability as an Excel sheet
    currentCatalogDf.sort_values(by=[session['powerbi'].scriptConfig['excelSheetSortBy']], inplace=True)
    # copy from original file
    session['powerbi'].log(text='Copying updated catalog to Excel file...')
    excelFilePath = session['mssharepoint'].directory/'upload'/(sharepointPath.split('/')[-1])
    sessionContainer['fileops'].fileCopy(currentCatalogPath, excelFilePath)
    # read existing sheets to prevent the default overwriting behavior
    currentCatalogBook = openpyxl.load_workbook(excelFilePath)
    currentCatalogWriter = pandas.ExcelWriter(excelFilePath, engine='openpyxl')
    currentCatalogWriter.book = currentCatalogBook # load existing data into writer so it does not throw it away
    currentCatalogWriter.sheets = dict((ws.title, ws) for ws in currentCatalogBook.worksheets) # must set this so pandas sees the sheets
    # write resulting DataFrame to file
    currentCatalogDf.to_excel(currentCatalogWriter, index=False, sheet_name=session['powerbi'].scriptConfig['excelSheetName'])
    currentCatalogWriter.save()
    # upload to SharePoint
    session['powerbi'].log(text='Uploading Excel file to SharePoint...')
    session['mssharepoint'].fileUpload(sharepointPath, excelFilePath)
    return True

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['powerbi'] = powerBiSession(Path(__file__).stem, 'refresh')
    sessionContainer['mssharepoint'] = sharepointSession(Path(__file__).stem, '', args=['aim'], logFileName=sessionContainer['powerbi'].logFileName)
    sessionContainer['fileops'] = fileopsSession(Path(__file__).stem, '', logFileName=sessionContainer['powerbi'].logFileName)
    loginPrincipal = {
        'type': 'ServicePrincipal',
        'label': 'ACE'
    }
    try:
        if not (sessionContainer['powerbi'].login(loginPrincipal) and sessionContainer['mssharepoint'].login()):
            sessionContainer['powerbi'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            pbiAppCatalogRefresh(sessionContainer)
            if sessionContainer['powerbi'].loginTimeoutProcess.is_alive():
                sessionContainer['powerbi'].loginTimeoutProcess.terminate()
    except Exception as e:
        if sessionContainer['powerbi'].loginTimeoutProcess.is_alive():
            sessionContainer['powerbi'].loginTimeoutProcess.terminate()
        sessionContainer['powerbi'].powerBiError(e, email=sessionContainer['powerbi'].scriptConfig['errorNotification'])