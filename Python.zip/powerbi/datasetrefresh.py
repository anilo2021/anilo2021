####################################################################################################
# Name:                 datasetrefresh.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/powerbi/datasetrefresh.vsdx
# Command line usage:   python start.py datasetrefresh <groupName> <datasetName> <timeout> <period> <recipients>
# Purpose:              Refreshes a Power BI dataset within a given group (workspace), checking status
#                       until a timeout, using a given period as a polling interval
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-10-28 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2021-08-04 H. Maddipati (harm344@kellyservices.com)      Feature- Auto refresh dataset upon failure based on config
####################################################################################################

# library imports
import json
from msilib.schema import Error
import multiprocessing
from pathlib import Path
import sys
import time

# local imports
from powerbi.powerbisession import powerBiSession

# monitors taskflow status until complete, with specified interval, and returns success status
def refreshMonitorStatus(session, groupId, datasetId, requestId, timeoutProcess, period):
    session.log(text='Monitoring refresh with Request ID '+str(requestId)+' and checking every '+str(period/60)+' minutes')
    # loop as long as timeout process has not finished
    success = False # default to failure
    errorCounter = 0
    while timeoutProcess.is_alive():
        try:
            session.log(text='Checking refresh status for request '+str(requestId))
            # get refresh history and save latest one for debugging
            refreshes = session.datasetRefreshHistoryGroupGet(groupId, datasetId)['value']
            session.createJsonFile('json/'+session.logFileName.stem+'.json', refreshes)
            # grab the refresh from the history response
            refreshList = [r for r in refreshes if r['requestId'] == requestId]
            # if not in refresh history immediately, give a bit to show up because Microsoft
            if len(refreshList) == 0:
                session.log('Script-initiated transaction not found - waiting for service to catch up...')
                session.timer(period) 
            # handle returned status if finished, otherwise wait before checking again
            else:
                statusJson = refreshList[0]
                session.log(text=statusJson['status'])
                if statusJson['status'] == 'Completed':
                    success = True # indicated success
                    break
                elif statusJson['status'] == 'Failed':
                    break
                else:
                    session.log(text='Request unfinished, waiting '+str(period/60)+' minutes before retrying...')
                    # check timeout process while waiting
                    session.timer(period)
        except Exception as e:
            # handle if error limit not yet reached
            if errorCounter < session.scriptConfig['errorCounterLimit']:
                errorCounter += 1
                session.error(e, exit=False)
                session.log('Exception handled. Attempting to resume monitoring in '+str(period/60)+' minute(s)..')
                session.timer(period) #wait period before retrying            
            # fail if limit exceeded
            else:
                raise e
    return success

# main script logic
def datasetRefresh(session, groupName, datasetName, timeoutProcess, period=60): # may not need groupId in the future
    # acquire group by name
    retryCounter = 1
    retryLimit = session.scriptConfig['retryCounter'] if session.scriptConfig['retryEnabled'] else 1
    warningSent = False
    # wrap GET Workspaces in retry logic - TEMP
    while retryCounter <= retryLimit:
        session.log(text='INFO : GET Workspaces attempt '+str(retryCounter)+'/'+str(retryLimit))
        success = False
        try:
            groupsResponseJson = session.groupsGet()
            groupsList = groupsResponseJson['value']
            success = True
        except Exception as e:
            session.createJsonFile('json/'+session.logFileName.stem+'_GetWorkspaceKeyError_'+str(retryCounter), groupsResponseJson)
            if retryCounter == retryLimit:
                raise e
            else:
                session.error(e, exit=False)
                if not warningSent:
                    session.powerBiEmail(
                        body='GET Workspaces API return failed! Please see log file for JSON file path, and follow up with Power BI Support case to diagnose.',
                        color='yellow',
                        recipients=session.scriptConfig['emailRecipients']['error']
                    )
                    warningSent = True
                session.timer(period) # wait period before retrying 
        if success:
            break
        retryCounter+=1

    # check both provided name and name with spaces
    groupIds = [g['id'] for g in groupsList if g['name'] == groupName]
    # if no groups are found, the name is wrong
    if len(groupIds) != 1:
        raise ValueError('Group '+groupName+' not found! Terminating script...')
    # if exactly one group is found, continue as normal
    else:
        groupId = groupIds[0]
        session.log(text='Group '+groupName+' resolved to ID '+str(groupId))
        # acquire dataset by name
        datasetsResponse = session.datasetsGroupGet(groupId)
        datasetsList = datasetsResponse['value']
        # check both provided name and name with spaces
        datasetIds = [d['id'] for d in datasetsList if d['name'] == datasetName]
        # if no datasets are found, the name is wrong
        if len(datasetIds) != 1:
            raise ValueError('Dataset '+datasetName+' not found in group '+groupName+'! Terminating script...')
        # if exactly one dataset is found, continue as normal
        else:
            datasetId = datasetIds[0]
            retryCounter=1
            retryLimit= session.scriptConfig['retryCounter'] if session.scriptConfig['retryEnabled'] else 1
            session.log(text='Dataset '+datasetName+' in group '+groupName+' resolved to ID '+str(datasetId))
            # start the dataset refresh
            session.log('Executing refresh on dataset with ID '+datasetId+' within group with ID '+groupId)
            body = {
                'notifyOption': session.scriptConfig['notifyOption']
            }
            while retryCounter <= retryLimit:
                session.log(text='INFO : Refresh attempt '+str(retryCounter)+'/'+str(retryLimit))
                refreshResponse = session.datasetRefreshGroupStart(groupId, datasetId, body)
                if '"error"' in str(refreshResponse.content) or 'RequestId' not in refreshResponse.headers:
                    raise ValueError(refreshResponse.json()['error']['message'] if '"error"' in str(refreshResponse.content) else "Request ID not found")
                else:
                    requestId = refreshResponse.headers['RequestId']
                    # monitor the resulting request
                    success = refreshMonitorStatus(session, groupId, datasetId, requestId, timeoutProcess, period)
                    # handle success or failure
                    if success:
                        session.log(text='Refresh completed successfully.')
                        break
                    else:
                        if retryCounter==retryLimit:
                            session.log(text='WARN: Max retry limit reached. Exiting..')   
                            raise ValueError("Refresh Failed")
                        else:
                            session.log(text='Refresh failed! Retrying..')
                retryCounter+=1
        # Kill timeout process if refresh succeeded
        if timeoutProcess.is_alive():
            session.log(text='Timeout process terminated')
            timeoutProcess.terminate()
    
# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['powerbi'] = powerBiSession(Path(__file__).stem, taskName=('_'.join(sys.argv[1:3])).replace(' ', '_'))
    try:
        loginPrincipal = {
            'type': 'ServicePrincipal',
            'label': 'ACE'
        }
        if not sessionContainer['powerbi'].login(loginPrincipal):
            sessionContainer['powerbi'].log(text='Login error - aborted')
        else:
            # set timeout as secondary thread using second argument
            timeoutLimit = 300 if int(sys.argv[3]) < 5 else int(sys.argv[3])*60 # at least 5 minutes
            timeoutProcess = multiprocessing.Process(target=sessionContainer['powerbi'].timer, args=[timeoutLimit])
            timeoutProcess.start()
            # handle command line args
            period = 60 if int(sys.argv[4]) < 1 else int(sys.argv[4])*60 # at least one minute]
            sessionContainer['powerbi'].log(text='Dataset refresh started from group '+sys.argv[1])
            datasetRefresh(sessionContainer['powerbi'], sys.argv[1], sys.argv[2], timeoutProcess, period)
            sessionContainer['powerbi'].logout()
            sessionContainer['powerbi'].log(text='Script execution complete')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        sessionContainer['powerbi'].logout() # kills loginTimeoutProcess
        sessionContainer['powerbi'].powerBiError(e, email=sessionContainer['powerbi'].scriptConfig['errorNotification'])