####################################################################################################
# Name:                 pbicatalogrefresh.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/powerbi/pbicatalogrefresh.vsdx
# Command line usage:   python start.py pbicatalogrefresh timeout period -jsondump -jsonuse
# Purpose:              Refreshes the Power BI Auto-Catalog with current Workspace, App, and Group
#                       Owner data from the Power BI REST API
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2021-03-30 Jesse Rominske (jesr114@kellyservices.com)    Original Author
####################################################################################################

# library imports
import fnmatch
import json
import multiprocessing
import pandas
from pathlib import Path
import sys

# local imports
from powerbi.powerbisession import powerBiSession
from msgraph.graphsession import graphSession

# function to process an asset and add it to the list (so code is only in one place)
def addAssetsToDataList(session, assetRows, workspace, assetList, assetType):
    session.log(text='\t\tPopulating '+assetType+' asset staging data for workspace '+workspace['name']+'...')
    for asset in assetList:
        session.log(text='\t\t\tAdding '+assetType+' '+asset['name']+' (ID '+asset['id']+')')
        # check for sensitivity and/or endorsement and add if included, else null
        sensitivity = asset['sensitivityLabel']['labelId'] if 'sensitivityLabel' in asset else None
        if 'endorsementDetails' in asset:
            endorsementStatus = asset['endorsementDetails']['endorsement']
            endorsedBy = asset['endorsementDetails']['certifiedBy'] if 'certifiedBy' in asset['endorsementDetails'] else None
        else:
            endorsementStatus, endorsedBy = None, None
        # append dataset row to asset list
        if assetType == 'dataset':
            assetRows.append({
                'Id': asset['id'],
                'DatasetName': asset['name'],
                'WorkspaceId': workspace['id'],
                'Sensitivity': sensitivity,
                'EndorsementStatus': endorsementStatus,
                'EndorsedByPrincipalId': endorsedBy
            })
        # append report row to asset list
        elif assetType == 'report':
            # check for appId if included, else null
            appId = asset['appId'] if 'appId' in asset else None
            datasetId = asset['datasetId'] if 'datasetId' in asset else None
            assetRows.append({
                'Id': asset['id'],
                'ReportName': asset['name'],
                'WorkspaceId': workspace['id'],
                'DatasetId': datasetId,
                'AppId': appId,
                'Sensitivity': sensitivity,
                'EndorsementStatus': endorsementStatus,
                'EndorsedByPrincipalId': endorsedBy
            })
    return assetRows

# function to populate principals from either a workspace or an app (so code is only in one place)
def addPrincipalToDataList(session, principal, principalData, principalHeirarchyData, principalshipData, invalidPrincipals, workspaceId=None, appId=None):
# catch if members not present
    principalEmailAddress = principal['emailAddress'] if 'emailAddress' in principal else None
    principalDisplayName = principal['displayName'] if 'displayName' in principal else None
    # add row to principalship upsert data
    if workspaceId is not None:
        # based on workspacePrincipal model
        principalshipData.append({
            'Identifier': principal['identifier'],
            'WorkspaceId': workspaceId,
            'AccessRight': principal['groupUserAccessRight']
        })
    elif appId is not None:
        # based on appPrincipal model
        principalshipData.append({
            'Identifier': principal['identifier'],
            'AppId': appId,
            'AccessRight': principal['appUserAccessRight']
        })
    else:
        raise ValueError('addPrincipalToDataList: Must provide either workspaceId or appId')
    # check if principal already in principal upsert data
    if not any([True for p in principalData if principal['identifier'].upper() == p['Identifier'].upper()]):
        # add row to principal upsert data
        principalData.append({
            'Identifier': principal['identifier'],
            'PrincipalType': principal['principalType'],
            'DisplayName': principalDisplayName,
            'Email': principalEmailAddress
        })
        # if group, add member details as well
        if principal['principalType'] == 'Group':
            membersResult = session['msgraph'].graphGroupMembersList(principal['identifier'])
            # check for returned error
            if 'error' in membersResult and 'message' in membersResult['error']:
                # if "resource not found" error, skip adding the member
                if fnmatch.fnmatch(membersResult['error']['message'], session['powerbi'].scriptConfig['errorTemplateString']['resourceNotFound']):
                    session['powerbi'].log(text='WARNING: Member ID '+principal['identifier']+' is no longer valid. This is usually caused by an Azure resource being deleted after an App is published. Skipping...')
                    # append dict with relevant IDs to invalidPrincipals data list
                    invalidPrincipals.append({
                            'workspaceId': workspaceId,
                            'appId': appId,
                            'principalId': principal['identifier']
                    })
                # for other errors, fail the script
                else:
                    raise ValueError(membersResult['error']['message'])
            # if no error, proceed normally
            else:
                # add members to to principal lists
                for member in membersResult:
                    # set identifier property if not included
                    if 'identifier' not in member:
                        member['identifier'] = member['id']
                    # add relationship to principalHeirarchy upsert data
                    principalHeirarchyData.append({
                        'ChildIdentifier': member['identifier'],
                        'ParentIdentifier': principal['identifier']
                    })
                    # add principal if not in principal list already
                    if not any([True for p in principalData if principal['identifier'].upper() == p['Identifier'].upper()]):
                        # select principal type based on odata type
                        if member['@odata.type'] == '#microsoft.graph.group':
                            memberType = 'Group'
                        elif member['@odata.type'] == '#microsoft.graph.user':
                            memberType = 'User'
                        elif member['@odata.type'] == '#microsoft.graph.application':
                            memberType = 'App'
                        # catch if members not present
                        memberEmailAddress = member['mail'] if 'mail' in member else None
                        memberDisplayName = member['displayName'] if 'displayName' in member else None
                        # add entry to principal upsert data
                        session['powerbi'].log(text='\t\t\tAdding principal '+memberType+' with ID '+principal['identifier'])
                        principalData.append({
                            'Identifier': member['identifier'],
                            'PrincipalType': memberType,
                            'DisplayName': memberDisplayName,
                            'Email': memberEmailAddress
                        })

# function to streamline extraction of values based on index columns of a dataframe
def extractDfElementByIndexValue(df, sourceIndexName, indexValue, column):
    return df.loc[df[sourceIndexName] == indexValue, column].values[0]
  

# main script logic
def pbiCatalogRefresh(session, timeoutProcess, period, toggles=[]):
    # disable script run according to config
    if session['powerbi'].scriptConfig['disabled']:
        return False
    # handle toggles
    jsonDump = True if '-jsondump' in toggles else False
    session['powerbi'].log(text='-jsondump: '+str(jsonDump))
    jsonUse = True if '-jsonuse' in toggles else False
    session['powerbi'].log(text='-jsonuse: '+str(jsonUse))
    onlyExtract = True if '-onlyextract' in toggles else False
    session['powerbi'].log(text='-onlyextract: '+str(onlyExtract))
    csvDump = True if '-csvdump' in toggles else False
    session['powerbi'].log(text='-csvdump: '+str(csvDump))
    noLoad = True if '-noload' in toggles else False
    session['powerbi'].log(text='-noload: '+str(noLoad))
    invalidParams = [p for p in toggles if p not in [
        '-jsondump',
        '-jsonuse',
        '-onlyextract',
        '-csvdump',
        '-noload'
        ]]
    if len(invalidParams) > 0:
        invalidParamMsgString = 'Invalid parameters '+', '.join(invalidParams)+' provided!'
        print(invalidParamMsgString)
        raise ValueError(invalidParamMsgString+' Terminating script...')
    
    # === 
    # === WORKSPACE/APP API QUERIES === 
    # ===

    # if JSON use toggled off, retrieve data from API
    if not jsonUse or (jsonUse and jsonDump):
        # WORKSPACES QUERY
        session['powerbi'].log(text='Retrieving workspace data from Power BI REST API...')
        # get list of workspaces available
        workspacesGetResult = session['powerbi'].groupsGetAsAdmin(top=session['powerbi'].scriptConfig['getTopResultLimit'], expand='users')['value']
        session['powerbi'].log(text='Workspace data retrieved')
        # filter out non-Premium workspaces and sort by workspace ID
        workspacesGetResultFiltered = sorted(
            [
                w for w in workspacesGetResult 
                    if w['isOnDedicatedCapacity'] is True 
                    and w['capacityId'] in session['powerbi'].scriptConfig['premiumCapacityIds']
                    and w['state'] == 'Active'
            ], 
            key = lambda w: w['id'].upper())
        # get list of workspace IDs from those on the specified dedicated capacities
        workspaceIds = {
            'workspaces': [w['id'] for w in workspacesGetResultFiltered]
        }
        # scan workspaces for assets
        session['powerbi'].log(text='Initiating workspace scan...')
        workspacesScanResult = sorted(
            session['powerbi'].workspacesScan(workspaceIds, timeoutProcess, period)['workspaces'],
            key = lambda w: w['id']) # sort retrieved workspace scan by workspace ID
        session['powerbi'].log(text='Workspace scan completed')
        # match workspaces from GET to workspaces from POST scan to combine data (compensates for API limitation)
        # this is why they are sorted - so they iterate in tandem without having to search for matches
        workspaces = []
        session['powerbi'].log(text='Appending workspaces to data list...')
        for getWS, scanWS in zip(workspacesGetResultFiltered, workspacesScanResult):
            # merge two workspaces, replacing values of getWS with those of scanWS where applicable
            workspaces.append({**getWS, **scanWS})
            session['powerbi'].log(text='Workspace '+scanWS['name']+' appended')

        # APPS QUERY
        session['powerbi'].log(text='Retrieving app data from Power BI REST API...')
        # get list of apps available
        apps = session['powerbi'].appsGetAsAdmin(top=session['powerbi'].scriptConfig['getTopResultLimit'])['value']
        session['powerbi'].log(text='App data retrieved')
        # retrieve permissions data for each app
        for app in apps:
            app['users'] = session['powerbi'].appUsersGetAsAdmin(app['id'])['value']
        session['powerbi'].log(text='App permissions data retrieved')
        # save data to JSON if testing
        if jsonDump:
            session['powerbi'].createJsonFile('testJson/workspaces.json', workspaces)
            session['powerbi'].createJsonFile('testJson/apps.json', apps)        
    
    # if JSON use toggled on, use JSON if available, fail if not available
    if jsonUse:
        # if workspaces JSON exists, use it
        workspacesJsonPath = session['powerbi'].directory/'testJson'/'workspaces.json'
        if workspacesJsonPath.exists():
            workspaces = json.load(open(workspacesJsonPath))
            session['powerbi'].log(text='Workspaces JSON data loaded')
        else:
            raise OSError('Workspaces JSON not found! Temrinating script...')
        # if apps JSON exists, use it
        appsJsonPath = session['powerbi'].directory/'testJson'/'apps.json'
        if appsJsonPath.exists():
            apps = json.load(open(appsJsonPath))
            session['powerbi'].log(text='Apps JSON data loaded')
        else:
            raise OSError('Apps JSON not found! Temrinating script...')
    
    # if -onlyextract is toggled off, continue
    if not onlyExtract:


        # === 
        # === WORKSPACE/PRINCIPAL/ASSET/APP TRANSFORMATION === 
        # ===

        # dataset, principal, report, workspace, workspacePrincipal data transformation
        datasetUpsertData, principalUpsertData, principalHeirarchyUpsertData, reportUpsertData, workspaceUpsertData, workspacePrincipalUpsertData, invalidPrincipals = [], [], [], [], [], [], []
        appWorkspaceIds = {}
        # iterate through catalog to populate data lists
        session['powerbi'].log(text='\n\nPopulating workspace, asset, and workspace principal staging data...')
        for workspace in workspaces:
            session['powerbi'].log(text='\tProcessing workspace '+workspace['name']+' (ID '+workspace['id']+')...')
            # catch if members not present
            workspaceDescription = workspace['description'] if 'description' in workspace else None
            # add workspace row to list
            workspaceUpsertData.append({
                'Id': workspace['id'],
                'WorkspaceName': workspace['name'],
                'WorkspaceDescription': workspaceDescription,
                'DedicatedCapacity': workspace['capacityId']
            })
            # add dataset rows to asset list
            datasetUpsertData = addAssetsToDataList(
                session=session['powerbi'], 
                assetRows=datasetUpsertData,
                workspace=workspace,
                assetList=workspace['datasets'],
                assetType='dataset'
            )
            # add report rows to asset list
            reportUpsertData = addAssetsToDataList(
                session=session['powerbi'], 
                assetRows=reportUpsertData,
                workspace=workspace,
                assetList=workspace['reports'],
                assetType='report'
            )
            # extract App IDs from Reports
            for report in workspace['reports']:
                if 'appId' in report:
                    appWorkspaceIds[report['appId']] = workspace['id']
            # add principal data to lists
            session['powerbi'].log(text='\t\tPopulating workspacePrincipal staging data for workspace '+workspace['name']+'...')
            # prepare list of principal identifiers for uniqueness reference
            for principal in workspace['users']:
                if 'identifier' not in principal:
                    session['powerbi'].createJsonFile('testJson/workspacePrincipalWithNoId.json', workspace)
                    raise ValueError('addPrincipalToDataList: principal identifer must be present. Principal data provided:\n'+str(principal))
                addPrincipalToDataList(
                    session=session, 
                    principal=principal,
                    principalData=principalUpsertData,
                    principalHeirarchyData=principalHeirarchyUpsertData,
                    principalshipData=workspacePrincipalUpsertData,
                    invalidPrincipals=invalidPrincipals,
                    workspaceId=workspace['id']
                )
        
        # app, appPrincipal data transformation
        appUpsertData, appPrincipalUpsertData, = [], []
        # iterate through catalog to populate data lists
        session['powerbi'].log(text='\n\nPopulating app and app principal staging data...')
        for app in apps:
            session['powerbi'].log(text='\tProcessing app '+app['name']+' (ID '+app['id']+')...')
            # catch if members not present
            appDescription = app['description'] if 'description' in app else None
            workspaceId = appWorkspaceIds[app['id']] if app['id'] in appWorkspaceIds else None
            # add app row to list
            appUpsertData.append({
                'Id': app['id'],
                'WorkspaceId': workspaceId,
                'AppName': app['name'],
                'AppDescription': appDescription,
                'PublishedByPrincipalId': app['publishedBy']
            })
            # add principal data to lists
            session['powerbi'].log(text='\t\tPopulating appPrincipal staging data for app '+app['name']+'...')
            # prepare list of principal identifiers for uniqueness reference
            for principal in app['users']:
                addPrincipalToDataList(
                    session=session, 
                    principal=principal,
                    principalData=principalUpsertData,
                    principalHeirarchyData=principalHeirarchyUpsertData,
                    principalshipData=appPrincipalUpsertData,
                    invalidPrincipals=invalidPrincipals,
                    appId=app['id']
                )
        # generate dataframes from data lists
        stgData = {
            'stg_api_app': pandas.DataFrame(appUpsertData),
            'stg_api_appPrincipal': pandas.DataFrame(appPrincipalUpsertData),
            'stg_api_dataset': pandas.DataFrame(datasetUpsertData),
            'stg_api_principal': pandas.DataFrame(principalUpsertData),
            'stg_api_principalHierarchy': pandas.DataFrame(principalHeirarchyUpsertData),
            'stg_api_report': pandas.DataFrame(reportUpsertData),
            'stg_api_workspace': pandas.DataFrame(workspaceUpsertData),
            'stg_api_workspacePrincipal': pandas.DataFrame(workspacePrincipalUpsertData),
        }
        # if specified, dump CSVs of the dataframes
        if csvDump:
            # create testCsv folder if it does not already exist
            csvDirectory = session['powerbi'].directory/'testCsv'
            csvDirectory.mkdir(parents=True, exist_ok=True)
            # iterate through staging data and dump CSVs by name
            for df in stgData:
                csvFilename = session['powerbi'].logFileName.stem+'_'+df+'.csv'
                stgData[df].to_csv(csvDirectory/csvFilename)
                session['powerbi'].log(text='CSV written to file '+str(csvFilename))

        # if -noload is toggled off, continue
        if not noLoad:
            
            
            # === 
            # === APP/ASSET/PRINCIPAL/WORKSPACE INSERT === 
            # ===

            # establish admin DB engine for loads
            session['powerbi'].log(text='Establishing Admin connection to DevOpsDb...')
            devopsEngineAdmin = session['powerbi'].dbLogin('aimInfra_admin')
            
            # insert stage dataframes into stg tables
            for stgTableName in stgData:
                session['powerbi'].log(text='Inserting '+str(len(stgData[stgTableName].index))+' rows of staging data into '+stgTableName+'...')
                stgData[stgTableName].to_sql(
                    name=stgTableName,
                    con=devopsEngineAdmin,
                    schema=session['powerbi'].pbiCreds['Database']['aimInfra_admin']['schema'],
                    if_exists='replace'
                )
            session['powerbi'].log(text='Insert completed')

            
            # === 
            # === MARK DELETE/UPSERT STORED PROCEDURES === 
            # ===

            
            # establish raw DB connection for stored procedure execution
            session['powerbi'].log(text='Establishing raw connection to DevOpsDb...')
            devopsRawConn = session['powerbi'].dbLogin('aimInfra_user').raw_connection()
            devopsCursor = devopsRawConn.cursor()
            # shorten procedure reference with variable
            procedures = session['powerbi'].scriptConfig['dbProcedures']
            # execute stored procedures for marking deleted members
            for tableName in procedures['markDelete']:
                # NOTE: keys are strings, same as each base table name
                session['powerbi'].log(text='Marking '+tableName+' rows as deleted where not in stg_'+tableName+'...')
                session['powerbi'].executeSqlFile(
                    fileName='storedProcedureExec.sql', 
                    cursor=devopsCursor, 
                    params=[procedures['markDelete'][tableName]]
                )
            # execute stored procedures for upserting from stage tables
            for tableName in procedures['upsert']:
                # NOTE: keys are strings, same as each base table name
                session['powerbi'].log(text='Upserting '+tableName+' from stg_'+tableName+'...')
                session['powerbi'].executeSqlFile(
                    fileName='storedProcedureExec.sql', 
                    cursor=devopsCursor, 
                    params=[procedures['upsert'][tableName]]
                )
            # commit stored procedure transactions and close connection
            devopsCursor.commit()
            devopsRawConn.close()

            # handle notification for invalid principals if applicable
            try:
                if len(invalidPrincipals) != 0:
                    emailBodyList = []
                    # iterate through provided list of dicts to find necessary names for email list
                    for principal in invalidPrincipals:
                        # extract workspace name if applicable
                        if principal['workspaceId'] is not None:
                            contextName = extractDfElementByIndexValue(
                                df=stgData['stg_api_workspace'], 
                                sourceIndexName='Id', 
                                indexValue=principal['workspaceId'], 
                                column='WorkspaceName'
                            )
                        # extract app name if applicable
                        elif principal['appId'] is not None:
                            contextName = extractDfElementByIndexValue(
                                df=stgData['stg_api_app'], 
                                sourceIndexName='Id', 
                                indexValue=principal['appId'], 
                                column='AppName'
                            )
                        # raise error if principal in invaid state
                        else:
                            raise ValueError('No ID found for context of invalid principal '+principal['principalId'])
                        # extract principal name
                        principalName = extractDfElementByIndexValue(
                            df=stgData['stg_api_principal'], 
                            sourceIndexName='Identifier', 
                            indexValue=principal['principalId'], 
                            column='DisplayName'
                        )
                        # add list item
                        emailBodyList.append(' - '+principalName+' ('+contextName+')')
                    # concatenate list items into body
                    emailBody = 'The following invalid principals (with respective contexts) were found while processing the catalog refresh:<br>'+'<br>'.join(emailBodyList)
                    # send email with warning status
                    session['powerbi'].powerBiEmail(emailBody, 'yellow')
            except Exception as e:
                session['powerbi'].error(e, exit=False)
                session['powerbi'].log(text='Exception regarding invalid principal extraction handled. Finishing script...')
    
    # end timeout and finish script
    if timeoutProcess.is_alive():
        timeoutProcess.terminate()
    session['powerbi'].log(text='\nCatalog refresh completed')
    

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['powerbi'] = powerBiSession(Path(__file__).stem, taskName=('_'.join(sys.argv[1:3])).replace(' ', '_'))
    sessionContainer['msgraph'] = graphSession('', '', logFileName=sessionContainer['powerbi'].logFileName)
    try:
        loginPrincipal = {
            'type': 'ServicePrincipal',
            'label': 'Monitoring'
        }
        if (
            not sessionContainer['powerbi'].login(loginPrincipal)
            or not sessionContainer['msgraph'].login(loginPrincipal)
        ):
            sessionContainer['powerbi'].log(text='Login error - aborted')
            sys.exit(1)
        else:
            # set timeout as secondary thread using second argument
            timeoutLimit = 300 if int(sys.argv[1]) < 5 else int(sys.argv[1])*60 # at least 5 minutes
            timeoutProcess = multiprocessing.Process(target=sessionContainer['powerbi'].timer, args=[timeoutLimit])
            timeoutProcess.start()
            # handle command line args
            period = 60 if int(sys.argv[2]) < 1 else int(sys.argv[2])*60 # at least one minute
            #testToggle = True if any([a for a in sys.argv if a.startswith('-t')]) else False
            toggleList = [a for a in sys.argv if a.startswith('-')]
            sessionContainer['powerbi'].log(text='\nPower BI Catalog refresh starting...\n')
            pbiCatalogRefresh(sessionContainer, timeoutProcess, period, toggles=toggleList)
            sessionContainer['powerbi'].logout()
            sessionContainer['powerbi'].log(text='Script execution complete')
    except Exception as e:
        if timeoutProcess.is_alive():
            timeoutProcess.terminate()
        if sessionContainer['powerbi'].loginTimeoutProcess.is_alive():
            sessionContainer['powerbi'].loginTimeoutProcess.terminate()
        sessionContainer['powerbi'].powerBiError(e, email=sessionContainer['powerbi'].scriptConfig['errorNotification'])