-- Selects the list of apps from the App catalog that belong to one of our Premium capacities
SELECT *
  FROM [pbi].[vw_excel_appCatalog];