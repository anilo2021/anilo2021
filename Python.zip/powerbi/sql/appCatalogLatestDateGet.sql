-- Selects most recent modified date in the App table to checking
SELECT TOP (1) [LastModifiedDate]
  FROM [pbi].[vw_api_app]
  WHERE [WorkspaceId] IS NOT NULL
  ORDER BY [LastModifiedDate] DESC;