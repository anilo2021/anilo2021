-- Selects principals with access to a given app
SELECT * 
  FROM pbi.vw_excel_appCatalogPrincipals
  ORDER BY [AppId], [DisplayName], [AzureAdIdentifier];