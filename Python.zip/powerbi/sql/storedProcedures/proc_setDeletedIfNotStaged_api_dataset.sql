-- stored procedure setDeletedIfNotStaged_api_dataset
UPDATE pbi.api_dataset
SET 
    pbi.api_dataset.IsDeleted = 1
    ,pbi.api_dataset.LastModifiedDate = GetDate()
WHERE
    pbi.api_dataset.Id NOT IN (
        SELECT Id
        FROM pbi.stg_api_dataset
    )
AND pbi.api_dataset.IsDeleted <> 1;