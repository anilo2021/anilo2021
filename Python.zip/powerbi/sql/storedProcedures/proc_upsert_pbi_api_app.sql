-- stored procedure upsert_pbi_api_app
MERGE pbi.api_app AS [Target]
USING (SELECT * from pbi.stg_api_app) AS [Source] 
    ON [Target].Id = [Source].Id
WHEN MATCHED THEN
    UPDATE SET
        [Target].WorkspaceId = [Source].WorkspaceId
        ,[Target].AppName = [Source].AppName
        ,[Target].AppDescription = [Source].AppDescription
        ,[Target].PublishedByPrincipalId = [Source].PublishedByPrincipalId
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Id
        ,WorkspaceId
        ,AppName
        ,AppDescription
        ,PublishedByPrincipalId
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Id
        ,[Source].WorkspaceId
        ,[Source].AppName
        ,[Source].AppDescription
        ,[Source].PublishedByPrincipalId
        ,0
        ,GetDate());