-- stored procedure upsert_pbi_api_workspace
MERGE pbi.api_workspace AS [Target]
USING (SELECT * from pbi.stg_api_workspace) AS [Source] 
    ON [Target].Id = [Source].Id
WHEN MATCHED THEN
    UPDATE SET
        [Target].WorkspaceName = [Source].WorkspaceName
        ,[Target].WorkspaceDescription = [Source].WorkspaceDescription
        ,[Target].DedicatedCapacity = [Source].DedicatedCapacity
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Id
        ,WorkspaceName
        ,WorkspaceDescription
        ,DedicatedCapacity
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Id
        ,[Source].WorkspaceName
        ,[Source].WorkspaceDescription
        ,[Source].DedicatedCapacity
        ,0
        ,GetDate());