-- stored procedure setDeletedIfNotStaged_api_principalHierarchy
UPDATE pbi.api_principalHierarchy
SET 
    pbi.api_principalHierarchy.IsDeleted = 1
    ,pbi.api_principalHierarchy.LastModifiedDate = GetDate()
WHERE
    pbi.api_principalHierarchy.ChildIdentifier+'_'+pbi.api_principalHierarchy.ParentIdentifier NOT IN (
        SELECT ChildIdentifier+'_'+ParentIdentifier
        FROM pbi.stg_api_principalHierarchy
    )
    AND pbi.api_principalHierarchy.IsDeleted <> 1;