-- stored procedure setDeletedIfNotStaged_api_app
UPDATE pbi.api_app
SET 
    pbi.api_app.IsDeleted = 1
    ,pbi.api_app.LastModifiedDate = GetDate()
WHERE
    pbi.api_app.Id NOT IN (
        SELECT Id
        FROM pbi.stg_api_app
    )
AND pbi.api_app.IsDeleted <> 1;