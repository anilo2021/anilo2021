-- stored procedure upsert_pbi_api_workspacePrincipal
MERGE pbi.api_workspacePrincipal AS [Target]
USING (SELECT * from pbi.stg_api_workspacePrincipal) AS [Source] 
    ON [Target].Identifier = [Source].Identifier
    AND [Target].WorkspaceId = [Source].WorkspaceId
WHEN MATCHED THEN
    UPDATE SET
        [Target].WorkspaceId = [Source].WorkspaceId
        ,[Target].AccessRight = [Source].AccessRight
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Identifier
        ,WorkspaceId
        ,AccessRight
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Identifier
        ,[Source].WorkspaceId
        ,[Source].AccessRight
        ,0
        ,GetDate());