-- stored procedure upsert_pbi_api_principal
MERGE pbi.api_principal AS [Target]
USING (SELECT * from pbi.stg_api_principal) AS [Source] 
    ON [Target].Identifier = [Source].Identifier
WHEN MATCHED THEN
    UPDATE SET
        [Target].PrincipalType = [Source].PrincipalType
        ,[Target].DisplayName = [Source].DisplayName
        ,[Target].Email = [Source].Email
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Identifier
        ,PrincipalType
        ,DisplayName
        ,Email
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Identifier
        ,[Source].PrincipalType
        ,[Source].DisplayName
        ,[Source].Email
        ,0
        ,GetDate());