-- stored procedure setDeletedIfNotStaged_api_workspacePrincipal
UPDATE pbi.api_workspacePrincipal
SET 
    pbi.api_workspacePrincipal.IsDeleted = 1
    ,pbi.api_workspacePrincipal.LastModifiedDate = GetDate()
WHERE
    pbi.api_workspacePrincipal.Identifier+'_'+pbi.api_workspacePrincipal.WorkspaceId NOT IN (
        SELECT Identifier+'_'+WorkspaceId
        FROM pbi.stg_api_workspacePrincipal
    )
AND pbi.api_workspacePrincipal.IsDeleted <> 1;