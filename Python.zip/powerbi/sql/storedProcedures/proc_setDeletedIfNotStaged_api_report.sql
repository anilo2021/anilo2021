-- stored procedure setDeletedIfNotStaged_api_report
UPDATE pbi.api_report
SET 
    pbi.api_report.IsDeleted = 1
    ,pbi.api_report.LastModifiedDate = GetDate()
WHERE
    pbi.api_report.Id NOT IN (
        SELECT Id
        FROM pbi.stg_api_report
    )
AND pbi.api_report.IsDeleted <> 1;