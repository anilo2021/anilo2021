-- stored procedure upsert_pbi_api_report
MERGE pbi.api_report AS [Target]
USING (SELECT * from pbi.stg_api_report) AS [Source] 
    ON [Target].Id = [Source].Id
WHEN MATCHED THEN
    UPDATE SET
        [Target].ReportName = [Source].ReportName
        ,[Target].WorkspaceId = [Source].WorkspaceId
        ,[Target].DatasetId = [Source].DatasetId
        ,[Target].AppId = [Source].AppId
        ,[Target].Sensitivity = [Source].Sensitivity
        ,[Target].EndorsementStatus = [Source].EndorsementStatus
        ,[Target].EndorsedByPrincipalId = [Source].EndorsedByPrincipalId
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Id
        ,ReportName
        ,WorkspaceId
        ,DatasetId
        ,AppId
        ,Sensitivity
        ,EndorsementStatus
        ,EndorsedByPrincipalId
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Id
        ,[Source].ReportName
        ,[Source].WorkspaceId
        ,[Source].DatasetId
        ,[Source].AppId
        ,[Source].Sensitivity
        ,[Source].EndorsementStatus
        ,[Source].EndorsedByPrincipalId
        ,0
        ,GetDate());