-- stored procedure upsert_pbi_api_principalHierarchy
MERGE pbi.api_principalHierarchy AS [Target]
USING (SELECT * from pbi.stg_api_principalHierarchy) AS [Source] 
    ON [Target].ChildIdentifier = [Source].ChildIdentifier
    AND [Target].ParentIdentifier = [Source].ParentIdentifier
WHEN MATCHED THEN
    UPDATE SET
        [Target].ChildIdentifier = [Source].ChildIdentifier
        ,[Target].ParentIdentifier = [Source].ParentIdentifier
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        ChildIdentifier
        ,ParentIdentifier
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].ChildIdentifier
        ,[Source].ParentIdentifier
        ,0
        ,GetDate());