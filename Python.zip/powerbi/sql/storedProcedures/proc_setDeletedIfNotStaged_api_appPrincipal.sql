-- stored procedure setDeletedIfNotStaged_api_appPrincipal
UPDATE pbi.api_appPrincipal
SET 
    pbi.api_appPrincipal.IsDeleted = 1
    ,pbi.api_appPrincipal.LastModifiedDate = GetDate()
WHERE
    pbi.api_appPrincipal.Identifier+'_'+pbi.api_appPrincipal.AppId NOT IN (
        SELECT Identifier+'_'+AppId
        FROM pbi.stg_api_appPrincipal
    )
AND pbi.api_appPrincipal.IsDeleted <> 1;