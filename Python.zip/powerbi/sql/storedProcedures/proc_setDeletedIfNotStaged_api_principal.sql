-- stored procedure setDeletedIfNotStaged_api_principal
UPDATE pbi.api_principal
SET 
    pbi.api_principal.IsDeleted = 1
    ,pbi.api_principal.LastModifiedDate = GetDate()
WHERE
    pbi.api_principal.Identifier NOT IN (
        SELECT Identifier
        FROM pbi.stg_api_principal
    )
AND pbi.api_principal.IsDeleted <> 1;