-- stored procedure setDeletedIfNotStaged_api_workspace
UPDATE pbi.api_workspace
SET 
    pbi.api_workspace.IsDeleted = 1
    ,pbi.api_workspace.LastModifiedDate = GetDate()
WHERE
    pbi.api_workspace.Id NOT IN (
        SELECT Id
        FROM pbi.stg_api_workspace
    )
AND pbi.api_workspace.IsDeleted <> 1;