-- stored procedure upsert_pbi_api_appPrincipal
MERGE pbi.api_appPrincipal AS [Target]
USING (SELECT * from pbi.stg_api_appPrincipal) AS [Source] 
    ON [Target].Identifier = [Source].Identifier
    AND [Target].AppId = [Source].AppId
WHEN MATCHED THEN
    UPDATE SET
        [Target].AppId = [Source].AppId
        ,[Target].AccessRight = [Source].AccessRight
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Identifier
        ,AppId
        ,AccessRight
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Identifier
        ,[Source].AppId
        ,[Source].AccessRight
        ,0
        ,GetDate());