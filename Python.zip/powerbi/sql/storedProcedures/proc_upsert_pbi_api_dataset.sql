-- stored procedure upsert_pbi_api_dataset
MERGE pbi.api_dataset AS [Target]
USING (SELECT * from pbi.stg_api_dataset) AS [Source] 
    ON [Target].Id = [Source].Id
WHEN MATCHED THEN
    UPDATE SET
        [Target].DatasetName = [Source].DatasetName
        ,[Target].WorkspaceId = [Source].WorkspaceId
        ,[Target].Sensitivity = [Source].Sensitivity
        ,[Target].EndorsementStatus = [Source].EndorsementStatus
        ,[Target].EndorsedByPrincipalId = [Source].EndorsedByPrincipalId
        ,[Target].IsDeleted = 0
        ,[Target].LastModifiedDate = GetDate()
WHEN NOT MATCHED THEN
    INSERT (
        Id
        ,DatasetName
        ,WorkspaceId
        ,Sensitivity
        ,EndorsementStatus
        ,EndorsedByPrincipalId
        ,IsDeleted
        ,LastModifiedDate
    ) VALUES (
        [Source].Id
        ,[Source].DatasetName
        ,[Source].WorkspaceId
        ,[Source].Sensitivity
        ,[Source].EndorsementStatus
        ,[Source].EndorsedByPrincipalId
        ,0
        ,GetDate());