-- Queries view that drills through from AppId to Report to Dataset to Workspace containing the source Dataset
SELECT * 
  FROM [pbi].[vw_excel_appCatalogSourceDatasets]
  ORDER BY [AppId];