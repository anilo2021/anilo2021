-- DDL to create the dbo.PrincipalshipId sequence
CREATE SEQUENCE WorkspacePrincipalshipId
    START WITH 0
    INCREMENT BY 1;

-- DDL to create the pbi.api_workspacePrincipal table
CREATE TABLE pbi.api_workspacePrincipal (
    PrincipalshipId INT PRIMARY KEY NOT NULL DEFAULT (NEXT VALUE FOR dbo.WorkspacePrincipalshipId),
    Identifier VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    AccessRight VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);