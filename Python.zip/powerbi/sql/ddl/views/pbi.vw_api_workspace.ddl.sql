-- DDL to create the pbi.vw_api_workspace view
CREATE VIEW pbi.vw_api_workspace AS
  SELECT
    Id,
    WorkspaceName,
    WorkspaceDescription,
    DedicatedCapacity,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_workspace;