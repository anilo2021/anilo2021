-- Selects the list of apps from the App catalog that belong to one of our Premium capacities
CREATE VIEW pbi.vw_excel_appCatalog AS
SELECT [vw_api_app].[Id] AS Id
	  ,[vw_api_workspace].[DedicatedCapacity] AS WorkspaceCapcacityId
      ,[vw_api_app].[WorkspaceId] AS WorkspaceId
	  ,[vw_api_workspace].[WorkspaceName] AS WorkspaceName
      ,[vw_api_app].[AppName] AS AppName
      ,[vw_api_app].[AppDescription] AS AppDescription
      ,[vw_api_app].[PublishedByPrincipalId] AS PublishedByPrincipalId
      ,[vw_api_app].[IsDeleted] AS IsDeleted
      ,[vw_api_app].[LastModifiedDate] AS LastModifiedDate
  FROM [pbi].[vw_api_app]
  LEFT OUTER JOIN [pbi].[vw_api_workspace]
  ON [vw_api_app].[WorkspaceId] = [vw_api_workspace].[Id]
  WHERE [WorkspaceId] IS NOT NULL;