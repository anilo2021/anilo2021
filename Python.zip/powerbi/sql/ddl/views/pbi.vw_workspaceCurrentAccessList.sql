-- DDL to create the pbi.vw_workspaceCurrentAccessList view
CREATE VIEW pbi.vw_workspaceCurrentAccessList AS
SELECT [api_workspace].[WorkspaceName] AS WorkspaceName
	,[api_workspace].[Id] AS WorkspaceId
	,COALESCE([api_workspace].[WorkspaceDescription], '-') AS WorkspaceDescription
	,[principalJoin].[MemberType]
	,[principalJoin].[MemberLevel]
	,[principalJoin].[Email]
	,[principalJoin].[DisplayName]
	,[principalJoin].[AzureAdIdentifier]
  FROM [pbi].[api_workspace]
RIGHT OUTER JOIN (
	SELECT [api_workspacePrincipal].[WorkspaceId] AS WorkspaceId
	  ,[api_principal].[PrincipalType] AS MemberType
	  ,[api_workspacePrincipal].[AccessRight] AS MemberLevel
	  ,COALESCE([api_principal].[Email], '-') AS Email
	  ,COALESCE([api_principal].[DisplayName], '-') AS DisplayName
	  ,[api_principal].[Identifier] AS AzureAdIdentifier
	  FROM [pbi].[api_workspacePrincipal]
	LEFT OUTER JOIN [pbi].[api_principal]
	ON [api_workspacePrincipal].[Identifier] = [api_principal].[Identifier]
	WHERE [api_principal].[IsDeleted] = 0 
      AND [api_workspacePrincipal].[IsDeleted] = 0
) as principalJoin
ON [api_workspace].[Id] = principalJoin.[WorkspaceId]
WHERE [api_workspace].[IsDeleted] = 0;