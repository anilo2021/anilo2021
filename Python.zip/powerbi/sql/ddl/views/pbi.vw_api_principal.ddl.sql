-- DDL to create the pbi.vw_api_principal view
CREATE VIEW pbi.vw_api_principal AS
  SELECT
    Identifier,
    PrincipalType,
    DisplayName,
    Email,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_principal;