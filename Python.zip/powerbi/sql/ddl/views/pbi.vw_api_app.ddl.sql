-- DDL to create the pbi.vw_api_app view
CREATE VIEW pbi.vw_api_app AS
  SELECT    
    Id,
    WorkspaceId,
    AppName,
    AppDescription,
    PublishedByPrincipalId,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_app;