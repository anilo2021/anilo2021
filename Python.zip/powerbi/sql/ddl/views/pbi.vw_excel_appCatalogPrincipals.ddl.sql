-- Selects principals with access to a given app
CREATE VIEW pbi.vw_excel_appCatalogPrincipals AS
SELECT [vw_api_app].[Id] AS AppId
	,[principalJoin].[DisplayName]
	,[principalJoin].[AzureAdIdentifier]
  FROM [pbi].[vw_api_app]
RIGHT OUTER JOIN (
	SELECT [vw_api_appPrincipal].[appId] AS AppId
	  ,COALESCE([vw_api_principal].[DisplayName], '-') AS DisplayName
	  ,[vw_api_principal].[Identifier] AS AzureAdIdentifier
	  FROM [pbi].[vw_api_appPrincipal]
	LEFT OUTER JOIN [pbi].[vw_api_principal]
	ON [vw_api_appPrincipal].[Identifier] = [vw_api_principal].[Identifier]
	WHERE [vw_api_principal].[IsDeleted] = 0 
      AND [vw_api_appPrincipal].[IsDeleted] = 0
) as principalJoin
ON [vw_api_app].[Id] = principalJoin.[appId]
WHERE [principalJoin].[DisplayName] IS NOT NULL;