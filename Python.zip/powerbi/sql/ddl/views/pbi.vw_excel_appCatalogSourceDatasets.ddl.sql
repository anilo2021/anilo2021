-- Drills through from AppId to Report to Dataset to Workspace containing the source Dataset
CREATE VIEW pbi.vw_excel_appCatalogSourceDatasets AS
SELECT [pbi].[vw_api_app].[Id] AS AppId
      ,[pbi].[vw_api_app].[AppName] AS AppName
	  ,ReportDatasetWorkspace.[ReportId] AS ReportId
	  ,ReportDatasetWorkspace.[ReportName] AS ReportName
      ,ReportDatasetWorkspace.[DatasetId] AS DatasetId
	  ,ReportDatasetWorkspace.[DatasetName] AS DatasetName
	  ,ReportDatasetWorkspace.[DatasetWorkspaceId] AS DatasetWorkspaceId
      ,ReportDatasetWorkspace.[DatasetWorkspaceName] AS DatasetWorkspaceName
FROM [pbi].[vw_api_app]
RIGHT OUTER JOIN (
  SELECT [pbi].[vw_api_report].[AppId] AS AppId
		,[pbi].[vw_api_report].[Id] AS ReportId
        ,[pbi].[vw_api_report].[ReportName] AS ReportName
		,DatasetWorkspace.[DatasetId] AS DatasetId
	    ,DatasetWorkspace.[DatasetName] AS DatasetName
	    ,DatasetWorkspace.[WorkspaceId] AS DatasetWorkspaceId
		,DatasetWorkspace.[WorkspaceName] AS DatasetWorkspaceName
  FROM [pbi].[vw_api_report]
  LEFT OUTER JOIN (
    SELECT [pbi].[vw_api_dataset].[Id] AS DatasetId
	      ,[pbi].[vw_api_dataset].[DatasetName] AS DatasetName
	      ,[pbi].[vw_api_workspace].[Id] AS WorkspaceId
		  ,[pbi].[vw_api_workspace].[WorkspaceName] AS WorkspaceName
    FROM [pbi].[vw_api_dataset]
    LEFT OUTER JOIN [pbi].[vw_api_workspace]
    ON [pbi].[vw_api_dataset].[WorkspaceId] = [pbi].[vw_api_workspace].[Id]
	WHERE [pbi].[vw_api_workspace].[IsDeleted] = 0
	  AND [pbi].[vw_api_dataset].[IsDeleted] = 0
	) AS DatasetWorkspace
  ON [pbi].[vw_api_report].[DatasetId] = DatasetWorkspace.[DatasetId]
  WHERE [pbi].[vw_api_report].[IsDeleted] = 0
) AS ReportDatasetWorkspace
ON [pbi].[vw_api_app].[Id] = ReportDatasetWorkspace.[AppId]
WHERE [pbi].[vw_api_app].[WorkspaceId] IS NOT NULL;