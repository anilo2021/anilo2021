-- DDL to create the pbi.vi_api_appPrincipal view
CREATE VIEW pbi.vw_api_appPrincipal AS
  SELECT
    PrincipalshipId,
    Identifier,
    AppId,
    AccessRight,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_appPrincipal;