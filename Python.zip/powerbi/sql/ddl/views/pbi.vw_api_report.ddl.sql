-- DDL to create the pbi.vw_api_report view
CREATE VIEW pbi.vw_api_report AS
  SELECT
    Id,
    ReportName,
    WorkspaceId,
    DatasetId,
    AppId,
    Sensitivity,
    EndorsementStatus,
    EndorsedByPrincipalId,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_report;