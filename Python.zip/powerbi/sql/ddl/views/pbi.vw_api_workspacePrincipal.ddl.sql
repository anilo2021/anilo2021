-- DDL to create the pbi.vw_api_workspacePrincipal view
CREATE VIEW pbi.vw_api_workspacePrincipal AS 
  SELECT
    PrincipalshipId,
    Identifier,
    WorkspaceId,
    AccessRight,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_workspacePrincipal;