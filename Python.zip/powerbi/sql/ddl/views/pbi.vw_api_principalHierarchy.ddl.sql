-- DDL to create the pbi.vw_api_principalHierarchy view
CREATE VIEW pbi.vw_api_principalHierarchy AS
  SELECT
    ChildIdentifier,
    ParentIdentifier,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_principalHierarchy;