-- DDL to create the pbi.vw_api_dataset view
CREATE VIEW pbi.vw_api_dataset AS
  SELECT
    Id,
    DatasetName,
    WorkspaceId,
    Sensitivity,
    EndorsementStatus,
    EndorsedByPrincipalId,
    IsDeleted,
    LastModifiedDate
  FROM pbi.api_dataset;