-- DDL to create the pbi.vw_appCurrentAccessList view
CREATE VIEW pbi.vw_appCurrentAccessList AS
  SELECT [api_app].[appName] AS appName
	,[api_app].[Id] AS AppId
	,COALESCE([api_app].[appDescription], '-') AS AppDescription
	,[principalJoin].[MemberType]
	,[principalJoin].[MemberLevel]
	,[principalJoin].[Email]
	,[principalJoin].[DisplayName]
	,[principalJoin].[AzureAdIdentifier]
    FROM [pbi].[api_app]
  RIGHT OUTER JOIN (
	SELECT [api_appPrincipal].[appId] AS AppId
	  ,[api_principal].[PrincipalType] AS MemberType
	  ,[api_appPrincipal].[AccessRight] AS MemberLevel
	  ,COALESCE([api_principal].[Email], '-') AS Email
	  ,COALESCE([api_principal].[DisplayName], '-') AS DisplayName
	  ,[api_principal].[Identifier] AS AzureAdIdentifier
	  FROM [pbi].[api_appPrincipal]
	LEFT OUTER JOIN [pbi].[api_principal]
	ON [api_appPrincipal].[Identifier] = [api_principal].[Identifier]
	WHERE [api_principal].[IsDeleted] = 0 
      AND [api_appPrincipal].[IsDeleted] = 0
  ) as principalJoin
  ON [api_app].[Id] = principalJoin.[appId]
  WHERE [api_app].[IsDeleted] = 0;