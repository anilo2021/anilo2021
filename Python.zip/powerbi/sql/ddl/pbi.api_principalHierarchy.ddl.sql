-- DDL to create the pbi.api_principalHierarchy table
CREATE TABLE pbi.api_principalHierarchy (
    ChildIdentifier VARCHAR(MAX) NOT NULL,
    ParentIdentifier VARCHAR(MAX) NOT NULL,
    IsDeleted INT,
    LastModifiedDate DATE
);