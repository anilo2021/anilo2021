-- DDL to create the dbo.PrincipalshipId sequence
CREATE SEQUENCE AppPrincipalshipId
    START WITH 0
    INCREMENT BY 1;

-- DDL to create the pbi.api_appPrincipal table
CREATE TABLE pbi.api_appPrincipal (
    PrincipalshipId INT PRIMARY KEY NOT NULL DEFAULT (NEXT VALUE FOR dbo.AppPrincipalshipId),
    Identifier VARCHAR(MAX),
    AppId VARCHAR(MAX),
    AccessRight VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);