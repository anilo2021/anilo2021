-- DDL to create the pbi.api_dataset table
CREATE TABLE pbi.api_dataset (
    Id VARCHAR(MAX) NOT NULL,
    DatasetName VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    Sensitivity VARCHAR(MAX),
    EndorsementStatus VARCHAR(MAX),
    EndorsedByPrincipalId VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);