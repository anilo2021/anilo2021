-- DDL to create the pbi.api_app table
CREATE TABLE pbi.api_app (
    Id VARCHAR(255) NOT NULL PRIMARY KEY,
    WorkspaceId VARCHAR(MAX),
    AppName VARCHAR(MAX),
    AppDescription VARCHAR(MAX),
    PublishedByPrincipalId VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);