-- DDL to create the pbi.stg_api_dataset table
CREATE TABLE pbi.stg_api_dataset (
    Id VARCHAR(MAX),
    DatasetName VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    Sensitivity VARCHAR(MAX),
    EndorsementStatus VARCHAR(MAX),
    EndorsedByPrincipalId VARCHAR(MAX)
);