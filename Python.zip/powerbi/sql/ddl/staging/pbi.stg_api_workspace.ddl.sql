-- DDL to create the pbi.stg_api_workspace table
CREATE TABLE pbi.stg_api_workspace (
    Id VARCHAR,
    WorkspaceName VARCHAR,
    WorkspaceDescription VARCHAR,
    DedicatedCapacity VARCHAR
);