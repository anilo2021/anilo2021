-- DDL to create the pbi.stg_api_appPrincipal table
CREATE TABLE pbi.stg_api_appPrincipal (
    Identifier VARCHAR(MAX),
    AppId VARCHAR(MAX),
    AccessRight VARCHAR(MAX)
);