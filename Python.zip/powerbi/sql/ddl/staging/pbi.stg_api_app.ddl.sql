-- DDL to create the pbi.stg_api_app table
CREATE TABLE pbi.stg_api_app (
    Id VARCHAR,
    WorkspaceId VARCHAR,
    AppName VARCHAR,
    AppDescription VARCHAR,
    PublishedByPrincipalId VARCHAR
);