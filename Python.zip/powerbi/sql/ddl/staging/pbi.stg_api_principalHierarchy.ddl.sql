-- DDL to create the pbi.stg_api_principalHierarchy table
CREATE TABLE pbi.stg_api_principalHierarchy (
    ChildIdentifier VARCHAR(MAX) NOT NULL,
    ParentIdentifier VARCHAR(MAX) NOT NULL
);