-- DDL to create the pbi.stg_api_workspacePrincipal table
CREATE TABLE pbi.stg_api_workspacePrincipal (
    Identifier VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    AccessRight VARCHAR(MAX)
);