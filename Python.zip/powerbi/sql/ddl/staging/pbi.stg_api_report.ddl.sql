-- DDL to create the pbi.stg_api_report table
CREATE TABLE pbi.stg_api_report (
    Id VARCHAR(MAX),
    ReportName VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    DatasetId VARCHAR(MAX),
    AppId VARCHAR(MAX),
    Sensitivity VARCHAR(MAX),
    EndorsementStatus VARCHAR(MAX),
    EndorsedByPrincipalId VARCHAR(MAX)
);