-- DDL to create the pbi.api_report table
CREATE TABLE pbi.api_report (
    Id VARCHAR(MAX) NOT NULL,
    ReportName VARCHAR(MAX),
    WorkspaceId VARCHAR(MAX),
    DatasetId VARCHAR(MAX),
    AppId VARCHAR(MAX),
    Sensitivity VARCHAR(MAX),
    EndorsementStatus VARCHAR(MAX),
    EndorsedByPrincipalId VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);