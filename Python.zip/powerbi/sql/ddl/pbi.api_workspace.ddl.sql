-- DDL to create the pbi.api_workspace table
CREATE TABLE pbi.api_workspace (
    Id VARCHAR(255) NOT NULL PRIMARY KEY,
    WorkspaceName VARCHAR(MAX),
    WorkspaceDescription VARCHAR(MAX),
    DedicatedCapacity VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);