-- DDL to create the pbi.api_principal table
CREATE TABLE pbi.api_principal (
    Identifier VARCHAR(MAX),
    PrincipalType VARCHAR(MAX),
    DisplayName VARCHAR(MAX),
    Email VARCHAR(MAX),
    IsDeleted INT,
    LastModifiedDate DATE
);