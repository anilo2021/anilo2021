####################################################################################################
# Name:                 fileopssession.py
# Python version:       Python 3.6.4
# Wiki path:            https://dev.azure.com/kellyservices/AIM/_wiki/wikis/AIM.wiki/19/fileopssession
# Command line usage:   N/A
# Purpose:              Class contains methods for Python file I/O operations
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-07-12 Sanju Joseph (sanj827@kellyservices.com)      Original Author
####################################################################################################

# library import
import datetime
import os
import pandas
from pathlib import Path
import shutil
from zipfile import ZipFile
# library import check
# TODO: REMOVE WITH PYTHON36 FOLDER UPDATE TO SECURE AGENT SERVERS
try:
    import openpyxl
    excelEngine = 'openpyxl'
except ModuleNotFoundError as e:
    excelEngine = 'xlrd'


# local module imports
from common.session import session

class fileopsSession(session):
    def _setup(self):
        self.directory = self.repoDirectory/'fileops'

    # method for archiving files given source path and archive path
    def fileArchive(self, fileName, archiveDirectory=None, zip=True, delete=False):
        filePath = Path(fileName)
        # if archive folder not specified, generate one
        archiveDirectoryPath = filePath.parent/'_archive' if archiveDirectory is None else Path(archiveDirectory)
        # create archive folder if it does not exist
        archiveDirectoryPath.mkdir(parents=True, exist_ok=True)
        # create timestamp
        timestamp = datetime.datetime.today().strftime('_%Y-%m-%d_%H-%M-%S')
        # append timestamp to archive filename
        archiveFileName = ''.join([filePath.stem+timestamp] + filePath.suffixes)
        # handle adding to zip archive if applicable
        if zip:
            archiveFilePath = archiveDirectoryPath/(archiveFileName+'.zip')
            with ZipFile(archiveFilePath, 'w') as zipFile:
                zipFile.write(filePath, arcname=archiveFileName)
        else:
            archiveFilePath = archiveDirectoryPath/archiveFileName
            # archive file using path passed in
            shutil.copyfile(filePath, archiveFilePath)
        if delete:
            filePath.unlink()
        self.log(text='Archived file '+str(filePath)+' to '+str(archiveFilePath))
        return archiveFilePath

    # function that converts a specific Excel file to CSV
    def fileExcelToCSV(self, excelFile, header=0, archive=None, zip=True, delete=False):
        excelFilePath = Path(excelFile)
        if excelFilePath.suffix not in ('.xlsx', '.xls'):
            raise ValueError(excelFile+' is not a valid Excel file!')
        # if CSV filename not specified, generate based on Excel filename
        csvFilePath = excelFilePath.parent/(excelFilePath.stem+''.join(excelFilePath.suffixes[:-1] + ['.csv']))
        self.log(text='Converting Excel file '+str(excelFilePath)+'\n to CSV '+str(csvFilePath))
        # read as Excel and save as CSV
        dataFrame = pandas.read_excel(
            excelFile,
            header,
            dtype='object',
            engine=excelEngine) # read excel as formatted, do not allow dtype interpretation
        dataFrame.to_csv(csvFilePath, index=False, quotechar="'", encoding='utf-8-sig')
        self.log('CSV file '+str(csvFilePath)+' successfully created')
        # archive Excel file
        archiveFilePath = self.fileArchive(excelFilePath, archiveDirectory=archive, zip=zip, delete=delete)
        return csvFilePath, archiveFilePath

    # list file generator function
    def fileList(self, directory, fileName=None, zipName=None, formats=[], prefixes=[], includeExts=[], excludeExts=[]):
        directoryPath = Path(directory)
        # unzip file if indicated
        if zipName is not None:
            with ZipFile(directoryPath/zipName, 'r') as zipFile:
                zipFile.extractall(directory)
        # perform initial file filter
        fileList = [Path(f) for f in directoryPath.glob('*') if Path(f).is_file()]
        if len(formats) > 0:
            # make list of prefixes and extensions from list of strings of format "prefix*.ext"
            formatPairs = [(x[:x.find('*')], x[x.find('*')+1:]) for x in formats]
            # filter out all files that do not match the formats
            fileList = [f for f in fileList if any([(f.name.startswith(fp[0]) and f.name.endswith(fp[1])) for fp in formatPairs])]
        # prefixes, includeExts, and excludeExts only work if formats not provided
        else:
            # filter out files with prefixes not in accepted list, if provided
            if len(prefixes) > 0:
                fileList = [f for f in fileList if any([f.name.startswith(p) for p in prefixes])]
            # filter out all but included extentions
            if len(includeExts) > 0:
                fileList = [f for f in fileList if f.suffix in includeExts]
            # filter out all excluded extentions
            if len(excludeExts) > 0:
                fileList = [f for f in fileList if f.suffix not in excludeExts]
        # generate list file if indicated
        if fileName is not None:
            with open(fileName, 'w') as listFile:
                listFile.write('\n'.join([str(f) for f in fileList]))
        return fileList

    # file copy function with optional archive and delete
    def fileCopy(self, sourcePath, targetPath, doArchive=False, archiveDirectory=None, delete=False):
        # create target folder if it does not exist
        targetPath.parent.mkdir(parents=True, exist_ok=True)
        # copy file first from source to target
        shutil.copyfile(sourcePath, targetPath)
        self.log(text='File '+str(sourcePath)+' copied to '+str(targetPath))
        # perform archive if specified
        if doArchive:
            self.fileArchive(sourcePath, archiveDirectory=archiveDirectory)
        # if specified, delete the original file
        if delete:
            sourcePath.unlink()
            self.log(text='File '+str(sourcePath)+' deleted')
    
    # file move wrapper for file copy method
    def fileMove(self, sourcePath, targetPath, doArchive=False, archiveDirectory=None):
        # pass all arguments, but mandate delete
        self.fileCopy(sourcePath, targetPath, doArchive=doArchive, archiveDirectory=archiveDirectory, delete=True)

    def is_dir_empty(self, dir_path):
        return [f for f in os.listdir(dir_path) if not f.startswith('.')] == []

    def delete_dir(self, dir_path):
        os.rmdir(dir_path)

    def delete_file(self, file_path):
        os.remove(str(file_path))
        
# main thread
if __name__ == "__main__":
    print('Running main function...')