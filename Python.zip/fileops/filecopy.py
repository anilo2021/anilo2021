####################################################################################################
# Name:                 filecopy.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/fileoperation/filecopy.vsdx
# Command line usage:   python start.py filecopy  <source> <target> <doArchive> <archiveLocation>
# Purpose:              Copy file (with optional archive) as a standalone action
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-11-18 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports
from pathlib import Path
import sys

# local imports
from fileops.fileopssession import fileopsSession

# main thread
if __name__ == "__main__":
    print('Running...')
    sessionContainer = {}
    sessionContainer['fileops'] = fileopsSession(Path(__file__).stem, taskName=Path(sys.argv[1]).stem.replace(' ', '_'))
    try:
        # format path arguments
        sourcePath = Path(sys.argv[1])
        targetPath = Path(sys.argv[2])
        # handle command line args
        if len(sys.argv) <= 3:
            sessionContainer['fileops'].fileCopy(sourcePath, targetPath)
        elif len(sys.argv) >= 4:
            doArchive = True if sys.argv[3].startswith('-a') else False
            if len(sys.argv) >= 5:
                archiveDirectory = Path(sys.argv[4])
                sessionContainer['fileops'].fileCopy(sourcePath, targetPath, doArchive, archiveDirectory)
            else:
                sessionContainer['fileops'].fileCopy(sourcePath, targetPath, doArchive)
        print('Script execution complete')
    except Exception as e:
        sessionContainer['fileops'].error(e)