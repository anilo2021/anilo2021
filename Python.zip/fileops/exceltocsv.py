####################################################################################################
# Name:                 exceltocsv.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/fileoperation/exceltocsv.vsdx
# Command line usage:   python start.py exceltocsv  <source> <archive> <head=[int]>
# Purpose:              Converts Excel files to CSV format
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-02-11 J. Rominske (jesr114@kellyservices.com)       Original Author
####################################################################################################

# library imports 
import datetime
import os
from pathlib import Path
import sys

# local module imports
from fileops.fileopssession import fileopsSession

# function that converts all files in folder to CSV
def folderToCSV(session, source, header=0, archive=None):
    sourcePath = Path(source)
    session.log(text='Converting folder '+str(sourcePath)+' contents...')
    # get list of files in source folder
    fileList = session.fileList(sourcePath, includeExts=['.xlsx', '.xls'])
    # convert to CSV, and archive (deleting originals)
    archive = archive if archive is not None else sourcePath/'_archive'
    for f in fileList:
        session.fileExcelToCSV(f, header=header, archive=archive, zip=False, delete=True)
    
# main decision logic
def excelToCSV(session, source, archive=None, header=0):
    # trigger folder iteration if necessary
    if os.path.isdir(source):
        folderToCSV(session, source, header=header, archive=archive)
    else:
        session.fileExcelToCSV(source, archive=archive, header=header)

# main method
if __name__ == '__main__': 
    print('Running...')
    sessionContainer = {}
    sessionContainer['fileops'] = fileopsSession(Path(__file__).stem, Path(sys.argv[1]).stem)
    # handle args
    header = next((int(a[5:]) for a in sys.argv if 'head=' in a), 0)
    try:
        if len(sys.argv) == 2:
            excelToCSV(sessionContainer['fileops'], source=sys.argv[1])
        elif len(sys.argv) == 3:
            excelToCSV(sessionContainer['fileops'], source=sys.argv[1], archive=sys.argv[2])
        elif len(sys.argv) >= 4:
            excelToCSV(sessionContainer['fileops'], source=sys.argv[1], archive=sys.argv[2], header=header)
        print('Script execution complete')
    except Exception as e:
        sessionContainer['fileops'].error(e)