####################################################################################################
# Name:                 deletefile.py
# Python version:       Python 3.6.4
# Diagram path:         AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/fileoperation/deletefile.vsdx
# Command line usage:   python start.py deletefile <prod|nonprod> <daily|weekly|monthly>
# Purpose:              delete old temp and log files
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-07-26 Sanju Joseph (sanj827@kellyservices.com)      Original Author
# 2020-08-21 Sanju Joseph (sanj827@kellyservices.com)      Added try catch block while deleting file/directory
# 2020-08-21 Sanju Joseph (sanj827@kellyservices.com)      log file email attachment is configurable
# 2021-03-15 Jesse Rominske (jesr114@kellysaervices.com)   evnrionment and config file standardized
####################################################################################################

import os, time, sys
import json
import datetime
import pathlib

# local module imports
from fileops.fileopssession import fileopsSession

def write_log(session, message):
    session.log(text=message)

def get_directories(path, allow_nested_search):
    dir_names = []
    if allow_nested_search:
        for root, dir_list, _ in os.walk(path, topdown=False):
            for each_dir in dir_list:
                dir_names.append(os.path.join(root, each_dir))
    
    dir_names.append(path)
    return dir_names

def filter_file_names(dir_path, file_name_format):
    file_list = []
    file_list = list(pathlib.Path(dir_path).glob(file_name_format))
    file_list = [s for s in file_list if os.path.isfile(os.path.join(dir_path, s))]
    file_list.sort(key=lambda s: os.path.getmtime(s), reverse=True)
    return file_list

def filter_file_names_and_modified_datetime(dir_path, file_name_format, retention_days):
    file_list = []
    file_list = list(pathlib.Path(dir_path).glob(file_name_format))
    file_list = [s for s in file_list if os.path.isfile(os.path.join(dir_path, s)) and os.stat(os.path.join(dir_path, s)).st_mtime < (time.time() - (retention_days * 86400))]
    return file_list

def retention_by_count(session, each_entry):
    name = each_entry['name']
    description = each_entry['description']
    path = each_entry['path']
    file_name_format = each_entry['file_name_format']
    retention_count = int(each_entry['retention_count'])
    allow_nested_search = each_entry['allow_nested_search']
    allow_delete_empty_nested_directory = each_entry['allow_delete_empty_nested_directory']

    write_log(session, 'Name                                : ' + str(name))
    write_log(session, 'Description                         : ' + str(description))
    write_log(session, 'Retention Count                     : ' + str(retention_count))
    write_log(session, 'File Name Format                    : ' + file_name_format)
    write_log(session, 'Allow Nested Search                 : ' + str(allow_nested_search))
    write_log(session, 'Delete Nested Directories If Empty  : ' + str(allow_delete_empty_nested_directory) + '\n')

    dir_names = get_directories(path, allow_nested_search)

    for each_dir in dir_names:
        write_log(session, 'Processing Path : ' + str(each_dir))
        file_list = filter_file_names(each_dir, file_name_format)

        if len(file_list) > 0:
            if retention_count == 0 or len(file_list) > retention_count:
                file_count = 1
                for each_file in file_list[retention_count:]:
                    write_log(session, '[' + str(file_count) + ']:: deleting file name: \n\t' + str(each_file))
                    
                    try:
                        session.delete_file(str(each_file))
                        write_log(session, '[' + str(file_count) + ']:: deleted successfully')
                    except Exception as file_delete_by_count_exception:
                        write_log(session, 'An exception occurred while deleting file in retention_by_count, hence could not able to delete file. \nException details: ' + str(file_delete_by_count_exception))

                    file_count = file_count + 1
                
                deleted_files_count = file_count - 1
                if deleted_files_count > 0:
                    write_log(session, str(deleted_files_count) + ' files were deleted successfully\n')
            else:
                write_log(session, 'files found but total files ' + str(len(file_list)) + ' are less than equals to file retention count ' + str(retention_count) + '. Hence ignored.\n')
        else:
            write_log(session, "either folder is empty or file name pattern didn't match\n")
    
        if allow_delete_empty_nested_directory:
            if session.is_dir_empty(each_dir):
                if str(each_dir).lower() != path.lower():
                    write_log(session, 'deleting directory name: \n' + str(each_dir))

                    try:
                        session.delete_dir(each_dir)
                        write_log(session, 'deleted successfully')
                    except Exception as dir_delete_by_count_exception:
                        write_log(session, 'An exception occurred while deleting directory in retention_by_count, hence could not able to delete directory. \nException details: ' + str(dir_delete_by_count_exception))
            else:
                write_log(session, "directory '" + str(each_dir) + "' is not empty, couldn't able to delete directory.\n")

    write_log(session, '-----------------------------------------------------------------\n')

def retention_by_day(session, each_entry):
    name = each_entry['name']
    description = each_entry['description']
    path = each_entry['path']
    file_name_format = each_entry['file_name_format']
    retention_days = int(each_entry['retention_days'])
    allow_nested_search = each_entry['allow_nested_search']
    allow_delete_empty_nested_directory = each_entry['allow_delete_empty_nested_directory']

    write_log(session, 'Name                                : ' + str(name))
    write_log(session, 'Description                         : ' + str(description))
    write_log(session, 'Retention Days                      : ' + str(retention_days))
    write_log(session, 'File Name Format                    : ' + file_name_format)
    write_log(session, 'Allow Nested Search                 : ' + str(allow_nested_search))
    write_log(session, 'Delete Nested Directories If Empty  : ' + str(allow_delete_empty_nested_directory) + '\n')

    dir_names = get_directories(path, allow_nested_search)

    for each_dir in dir_names:
        write_log(session, 'Processing Path : ' + str(each_dir))
        file_list = filter_file_names_and_modified_datetime(each_dir, file_name_format, retention_days)

        if len(file_list) > 0:
            file_count = 1
            for each_file in file_list:
                write_log(session, '[' + str(file_count) + ']:: deleting file name: \n\t' + str(each_file))
                try:
                    session.delete_file(str(each_file))
                    write_log(session, '[' + str(file_count) + ']:: deleted successfully')
                except Exception as file_delete_by_day_exception:
                    write_log(session, 'An exception occurred while deleting file in retention_by_day, hence could not able to delete file. \nException details: ' + str(file_delete_by_day_exception))
                file_count = file_count + 1
            
            deleted_files_count = file_count - 1
            if deleted_files_count > 0:
                write_log(session, str(deleted_files_count) + ' files were deleted successfully\n')
        else:
            write_log(session, "either folder is empty or file name pattern didn't match\n")
    
        if allow_delete_empty_nested_directory:
            if session.is_dir_empty(each_dir):
                if str(each_dir).lower() != path.lower():
                    write_log(session, 'deleting directory name: \n' + str(each_dir))
                    try:
                        session.delete_dir(each_dir)
                        write_log(session, 'deleted successfully')
                    except Exception as dir_delete_by_day_exception:
                        write_log(session, 'An exception occurred while deleting directory in retention_by_day, hence could not able to delete count. \nException details: ' + str(dir_delete_by_day_exception))
            else:
                write_log(session, "directory '" + str(each_dir) + "' is not empty, couldn't able to delete directory.\n")

    write_log(session, '-----------------------------------------------------------------\n')

# converts plain text to html format
def convert_plaintext_to_html(plain_text):
    plain_text = plain_text.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;')
    plain_text = '<br> \n'.join(plain_text.split('\n'))
    plain_text = '<br> \n'.join(plain_text.split('\r\n'))
    return plain_text

# sends email
def send_email(session, config_settings, subject, body, attachment=None):
    recipients = []
    for email in config_settings['emaildefaultrecipients'].split(','):
        if len(email) > 0:
            recipients.append(email.strip())   

    try:
        body = convert_plaintext_to_html(body)
        with open(session.repoDirectory/'common'/'emailTemplates'/'emailbody_iicsexport.html') as template:
            emailbody = template.read().format(body)

        session.email(subject, emailbody, attachment=attachment, recipients=recipients)
    except Exception as emailException:
        session.log(text="error occurred while sending email. Error details: " + str(emailException))

def is_path_valid(session, path, additional_msg):
    path = str(path).strip()
    if len(path) == 0:
        write_log(session, 'found path is empty' + additional_msg)
        return False
    elif not os.path.exists(path):
        write_log(session, "path '" + path + "' doesn't exist" + additional_msg)
        return False
    elif not os.path.isdir(path):
        write_log(session, "path '" + path + "' is not a directory" + additional_msg)
        return False
    
    return True

def is_config_entry_valid(session, each_entry, is_retention_by_count):
    if 'name' not in each_entry:
        write_log(session, '"name" attribute is missing, hence ignoring')
        return False
    elif len(str(each_entry['name']).strip()) == 0:
        write_log(session, '"name" value is empty, hence ignoring')
        return False
    
    additional_msg = ', hence ignoring config name: ' + str(each_entry['name'])

    if 'description' not in each_entry:
        write_log(session, '"description" attribute is missing' + additional_msg)
        return False
    elif len(str(each_entry['description']).strip()) == 0:
        write_log(session, '"description" value is empty' + additional_msg)
        return False

    if 'path' not in each_entry:
        write_log(session, '"path" attribute is missing' + additional_msg)
        return False
    elif not is_path_valid(session, each_entry['path'], additional_msg):
        return False

    if is_retention_by_count:
        if 'retention_count' not in each_entry:
            write_log(session, '"retention_count" attribute is missing' + additional_msg)
            return False
        elif type(each_entry['retention_count']) != int:
            write_log(session, '"retention_count" value ' + str(each_entry['retention_count']) + ' is not an integer' + additional_msg)
            return False
        elif int(each_entry['retention_count']) < 0:
            write_log(session, '"retention_count" value ' + str(each_entry['retention_count']) + ' is less than zero' + additional_msg)
            return False
    else:
        if 'retention_days' not in each_entry:
            write_log(session, '"retention_days" attribute is missing' + additional_msg)
            return False
        elif type(each_entry['retention_days']) != int:
            write_log(session, '"retention_days" value ' + str(each_entry['retention_days']) + ' is not an integer' + additional_msg)
            return False
        elif int(each_entry['retention_days']) < 0:
            write_log(session, '"retention_days" value ' + str(each_entry['retention_days']) + ' is less than zero' + additional_msg)
            return False

    if 'file_name_format' not in each_entry:
        write_log(session, '"file_name_format" attribute is missing' + additional_msg)
        return False
    elif len(str(each_entry['file_name_format']).strip()) == 0:
        write_log(session, '"file_name_format" value is empty, hence ignoring' + additional_msg)
        return False
    
    if 'allow_nested_search' not in each_entry:
        write_log(session, '"allow_nested_search" attribute is missing' + additional_msg)
        return False
    
    if 'allow_delete_empty_nested_directory' not in each_entry:
        write_log(session, '"allow_delete_empty_nested_directory" attribute is missing' + additional_msg)
        return False
    
    return True

def process(session, env_type, frequent_type):
    all_file_paths = []
    env_type = env_type.lower()
    frequent_type = frequent_type.lower()
    allow_email_notification = True
    timestamp = datetime.datetime.today().strftime('%Y-%m-%d_%H-%M-%S')
    
    try:    
        if env_type in session.scriptConfig['files']:
            if frequent_type in session.scriptConfig['files'][env_type]:
                if 'allow_email_notification' in session.scriptConfig['files'][env_type][frequent_type]:
                    try:
                        allow_email_notification = session.scriptConfig['files'][env_type][frequent_type]['allow_email_notification']
                    except Exception as allow_notification_exception:
                        write_log(session, 'exception occurred while getting "allow_email_notification" attribute: ' + str(allow_notification_exception))

                if 'retention_by_count' in session.scriptConfig['files'][env_type][frequent_type]:
                    write_log(session, '\n\n******************** RETENTION BY NO. OF FILES COUNT ******************\n')
                    for each_entry in session.scriptConfig['files'][env_type][frequent_type]['retention_by_count']:
                        if not is_config_entry_valid(session, each_entry, True):
                            continue

                        all_file_paths.append(str(each_entry['path']).lower())
                        try:
                            retention_by_count(session, each_entry)
                        except Exception as file_exception:
                            write_log(session, 'exception occurred: ' + str(file_exception))  
                else:
                    write_log(session, '"retention_by_count" section was not found in config file\n')
                
                if 'retention_by_day' in session.scriptConfig['files'][env_type][frequent_type]:
                    write_log(session, '\n\n******************** RETENTION BY NO. OF DAYS ********************\n')
                    for each_entry in session.scriptConfig['files'][env_type][frequent_type]['retention_by_day']:
                        if not is_config_entry_valid(session, each_entry, False):
                            continue

                        is_exist = False
                        for each_path in all_file_paths:
                            if each_path == str(each_entry['path']).lower():
                                is_exist = True
                                write_log(session, 'same path already exists in "retention_by_count" section, hence ignoring this path: ' + each_entry['path'])
                                break
                        
                        if not is_exist:
                            try:
                                retention_by_day(session, each_entry)
                            except Exception as file_exception:
                                write_log(session, 'exception occurred: ' + str(file_exception))
                        
                else:
                    write_log(session, '"retention_by_day" section was not found in config file\n')

            else:
                write_log(session, '"' + frequent_type + '" section was not found in config file\n')
        else:
            write_log(session, '"' + env_type + '" section was not found in config file\n')

    except Exception as process_exception:
        write_log(session, 'An exception occurred while processing: \nException details: ' + str(process_exception))
    
    if allow_email_notification:
        allow_email_attachment = True
        if 'allow_email_attachment' in session.scriptConfig['files'][env_type][frequent_type]:
            try:
                allow_email_attachment = session.scriptConfig['files'][env_type][frequent_type]['allow_email_attachment']
            except Exception as allow_email_attachment_exception:
                write_log(session, 'exception occurred while getting "allow_email_attachment" attribute: ' + str(allow_email_attachment_exception))
                
        email_subject = env_type +' | '+frequent_type+' | auto cleanup old files'
        email_body_message = 'Auto cleanup process for old files have been triggered at ' + timestamp.replace('_',' ')
        email_attachment = None

        if allow_email_attachment:
            email_body_message = email_body_message + '. Check attached log file for more details.'
            email_attachment = session.logFileName
        else:
            email_body_message = email_body_message + '. Check log file for more details. Log file path: ' + str(session.logFileName)

        send_email(session, session.scriptConfig['settings'], email_subject, email_body_message, attachment=email_attachment)
    else:
        write_log(session, 'email notification is disabled for environment type: ' + env_type + ' and frequent type: ' + frequent_type)

# main thread
if __name__ == "__main__":
    print('Running...')
    
    sessionContainer = {}
    sessionContainer['fileops'] = fileopsSession(os.path.basename(__file__)[:-3], taskName='')
    extraLogFilePath = str(sessionContainer['fileops'].logFileName)
    try:
        if os.path.exists(extraLogFilePath):
            os.remove(extraLogFilePath)
    except Exception as fileRemoveException:
        print("couldn't able to delete extra log file: "+ extraLogFilePath)

    if len(sys.argv)==1:
        write_log(sessionContainer['fileops'], "'environment type' and 'frequent type' arguments are missing, can't able to process further")
    elif len(sys.argv)==2:
        write_log(sessionContainer['fileops'], "'frequent type' argument is missing, can't able to process further")
    elif len(sys.argv)==3:
        env_type = sys.argv[1]
        frequent_type = sys.argv[2]
        process(sessionContainer['fileops'], env_type, frequent_type)
