####################################################################################################
# Name:                	scriptname.py
# Command line usage:  	python start.py scriptname required_param [optional_param]
# Flow diagram:        	AIM/Infrastructure/Apps/Python/Scripts_Documentation/Python_Repo/folder/scriptname.vsdx
# Python version:      	Python 3.6.4
# Purpose:             	Template for scripts of the AIM Python framework
# 						Illustrate file creation convention and header comment format
####################################################################################################
# REVISION HISTORY
# ---------- --------------------------------------------- -----------------------------------------
# DATE       EDITOR                                        DESCRIPTION 
# ---------- --------------------------------------------- -----------------------------------------
# 2019-01-21 J. Rominske (jesr114@kellyservices.com)       Original Author
# 2022-10-14 J. Rominske (jesr114@kellyservices.com)       Updated to new standards
####################################################################################################

# library imports
from pathlib import Path
import sys

# local imports
from common.session import session #TODO: replace common.session with some other session (common will be inherited from any other class)

# main logic function
def functionName(session, args=None):
    # disable script run according to config
    if session.scriptConfig['disabled']:
        return False

    # example logic
    print('Hello World!')
    session.log(text='Hello World!')
    if args is not None:
        session.log(text=str(args))

# main thread
if __name__ == "__main__":
    print('Running...')
	# instantiate dict of framework classes to pass all their capabilities into the entry point function
    sessionContainer = {} 
    sessionContainer['common'] = session(Path(__file__).stem, taskName='taskName') #NOTE: taskName is required for the log file name - should be identifying of what the script was doing
    try:
        if not sessionContainer['common'].login(): # this will execute the login method and immediately evaluate success/failure
            sessionContainer['common'].log(text='Login error - aborted')
            sys.exit(1)
        else: # proceed if login successful
            # handle different cases of command line arguments
            if len(sys.argv) == 1:
                functionName(sessionContainer['common']) #NOTE: entire dict can be passed, or only one member, but dict structure is standard regardless for consistency
            elif len(sys.argv) >= 2:
                functionName(sessionContainer['common'], sys.argv[1:]) #NOTE: sys.argv[0] is the name of the script - command line arguments start from 1 onward in the list
            sessionContainer['common'].log(text='Script execution complete') # for log completeness
            print('Script execution complete') # for ease of understanding while testing
	# pass all otherwise uncaught exceptions to error handler method
    except Exception as e:
        sessionContainer['common'].error(e, email=sessionContainer['common'].scriptConfig['errorNotification']) #TODO: replace with the specific error method from the actual classes that are used